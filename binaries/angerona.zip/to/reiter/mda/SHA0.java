package to.reiter.mda;
import com.ravnaandtines.crypt.mda.MDA;

/** Implementation of the SHA-0 Secure Hash Algorithm described in FIPS180
*  <P>
*  Class SHA0
*  <P>
*  Coded & copyright Oliver Reiter &lt;oliver@reiter.to&gt; 1998
*  All rights reserved.
* <p>
*  Modified Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 30-May-1999
*  to add self-test code.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
 *  @author Oliver Reiter, oliver@reiter.to, www.reiter.to
 *  @version 25 May 1999
 */
public final class SHA0
implements MDA
{
/*
	public static String OSI_OBJECT_IDENTIFIER
	= "iso(1) identified-organization(3) oiw(14) secsig(3) algorithms(2) 26";
*/
	private int state[] = new int[5];
	private long count;
	private int block[] = new int[16];
	private int full;

	/**
	 * default constructor
	 */
	public SHA0() {
		reset();
	}

	/**
	 * Feeds a  byte into the hash
	 * @param data the byte value
	 */
	public void update(byte input) {
		count++;
		int mask = (8 * (full & 0x3));
		block[full >> 2] &= ~(0xff << mask);
		block[full >> 2] |= (input & 0xff) << mask;
		if (full<63) {
			full++;
		} else {
			transform();
			full = 0;
		}
	}

	/**
	 * Feeds a batch of bytes into the hash
	 * @param data the byte values
	 * @param offset the first byte index to take
	 * @param length the number of bytes to take
	 */
	public void update(byte input[],int offset,int len) {
		int end = offset+len;
		for (;offset<end; offset++) update(input[offset]);
	}

	/**
	 * consolidates the input, and reinitialises the hash
	 * @return the hash value
	 */
	public byte[] digest() {
		byte digest[] = new byte[20];
		byte len[] = new byte[8];
		count <<= 3;
		for (int i=0; i<8; i++)
			len[i] = (byte)((count >>> (((7 - i) * 8))) & 0xff);
		update((byte)0x80);
		while (full != 56) update((byte)0x00);
		update(len,0,8);

		//return the digest
		for (int i=0; i<20; i++)
			digest[i] = (byte) ((state[i>>2] >> ((3-(i & 3)) * 8) ) & 0xff);
		reset();
		return digest;
	}

	private void reset() {
		state[0] = 0x67452301;
		state[1] = 0xEFCDAB89;
		state[2] = 0x98BADCFE;
		state[3] = 0x10325476;
		state[4] = 0xC3D2E1F0;
		full = 0;
		count = 0;
	}

	private void transform() {
		int v = state[0];
		int w = state[1];
		int x = state[2];
		int y = state[3];
		int z = state[4];

		for (int i=0; i<80; i++) {
			int b;
			if (i<16) {
				b = block[i];
				b = block[i]
				  = (((b << 24) | (b >>> 8)) & 0xff00ff00)
				  | (((b << 8) | (b >>> 24)) & 0x00ff00ff);
				z += ((w & (x ^ y)) ^ y) + 0x5A827999;
			} else {
				b = block[i & 0xf]
				  = block[(i+13) & 0xf] ^ block[(i+ 8) & 0xf]
				  ^ block[(i+ 2) & 0xf] ^ block[ i     & 0xf];
				if (i<20) {
					z += ((w & (x ^ y)) ^ y) + 0x5A827999;
				} else if (i<40) {
					z += (w ^ x ^ y) + 0x6ED9EBA1;
				} else if (i<60) {
					z += (((w | x) & y) | (w & x)) + 0x8F1BBCDC;
				} else {
					z += (w ^ x ^ y) + 0xCA62C1D6;
				}
			}
			z += b + ((v << 5) | (v >>> 27));
			w = (w << 30) | (w >>> 2);
			int t=z; z=y; y=x; x=w; w=v; v=t;
		}
		state[0] += v;
		state[1] += w;
		state[2] += x;
		state[3] += y;
		state[4] += z;
	}
   /**
    * test driver
    */
/*
    public static void main(String[] args)
    {
        SHAselfTest();
    }
*/
    /**
     * Print out the digest in a form that can be easily compared
     * to the test vectors.
     */
/*
    protected String digout(byte[] digestBits) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 20; i++) {
            char c1, c2;

            c1 = (char) ((digestBits[i] >>> 4) & 0xf);
            c2 = (char) (digestBits[i] & 0xf);
            c1 = (char) ((c1 > 9) ? 'A' + (c1 - 10) : '0' + c1);
            c2 = (char) ((c2 > 9) ? 'A' + (c2 - 10) : '0' + c2);
            sb.append(c1);
            sb.append(c2);
            if (((i+1) % 4) == 0)
                sb.append(' ');
        }
        return sb.toString();
    }
*/
	/**
	* perfoms a self-test - spits out the test vector outputs on System.out
	*/
/*
    public static void SHAselfTest()
    {
        int i, j;
        SHA0 s = new SHA0();
        // This line may be safely deleted, its to make it easy to see
        // the output of the program.

        System.out.println("SHA-0 Test PROGRAM.");
        System.out.println("This code runs the test vectors through the code.");

//      "abc"
//        0164b8a9 14cd2a5e 74c4f7ff 082c4d97 f1edf880

        System.out.println("First test is 'abc'");
        String z = "abc";
        s.reset();
        s.update((byte) 'a');
        s.update((byte) 'b');
        s.update((byte) 'c');
        byte[] dig = s.digest();
        System.out.println(s.digout(dig));
        System.out.println("0164b8a9 14cd2a5e 74c4f7ff 082c4d97 f1edf880");


//      "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
//        d2516ee1 acfa5baf 33dfc1c4 71e43844 9ef134c8

        System.out.println("Next Test is 'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'");
        z = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
        s.reset();
        for( i=0; i<z.length(); ++i)
        {
        	s.update((byte) z.charAt(i));
        }
        dig = s.digest();
        System.out.println(s.digout(dig));
        System.out.println("d2516ee1 acfa5baf 33dfc1c4 71e43844 9ef134c8");

//      A million repetitions of "a"
//        33232affa 48628a26 653b5aaa 44541fd9 0d690603
   	    long startTime = 0 - System.currentTimeMillis();

        System.out.println("Last test is 1 million 'a' characters.");
        s.reset();
        for (i = 0; i < 1000000; i++)
            s.update((byte) 'a');
        dig = s.digest();
        System.out.println(s.digout(dig));
        System.out.println("3232affa 48628a26 653b5aaa 44541fd9 0d690603");
        startTime += System.currentTimeMillis();
        double d = ((double)startTime)/1000.0;
        System.out.println(" done, elapsed time = "+d);
	}
*/
}