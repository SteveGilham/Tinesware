package to.reiter.mda;
import com.ravnaandtines.crypt.mda.MDA;

/** Implementation of the MD4 Message-Digest Algorithm described in RFC 1320
 *  by Ronald L. Rivest from RSA Data Security, Inc. on April 1992
*  <P>
*  Class MD4
*  <P>
*  Coded & copyright Oliver Reiter &lt;oliver@reiter.to&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
 *  @author Oliver Reiter, oliver@reiter.to, www.reiter.to
 *  @version 25 May 1999
 */
public final class MD4
implements MDA
{
/*
	public static String OSI_OBJECT_IDENTIFIER
	= "iso(1) member-body(2) US(840) rsadsi(113549) digestAlgorithm(2) 4";
*/
	private static final int permutations[][] = {
		{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},	//round 1
		{0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15},	//round 2
		{0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15},	//round 3
	};

	private static final int rotations[][] = {
		{ 3,  7, 11, 19},				//round 1
		{ 3,  5,  9, 13},				//round 2
		{ 3,  9, 11, 15},				//round 3
	};

	private int state[] = new int[4];
	private int mystate[] = new int[4];
	private byte block[] = new byte[64];
	private int myblock[] = new int[16];
	private int full;					//number of used bytes in buffer
	private long count;					//length of original message

	/**
	 * default constructor
	 */
	public MD4() {
		reset();
	};

	/**
	 * Feeds a  byte into the hash
	 * @param data the byte value
	 */
	public void update(byte input) {
		block[full] = input;
		count++;
		if (full<63) {
			full++;
		} else {
			transform();
			full = 0;
		}
	}

	/**
	 * Feeds a batch of bytes into the hash
	 * @param data the byte values
	 * @param offset the first byte index to take
	 * @param length the number of bytes to take
	 */
	public void update(byte input[],int offset,int len) {
		count += len;
		while (len>0) {
			int copy = Math.min(64-full,len);
			System.arraycopy(input,offset,block,full,copy);
			full += copy;
			if (full<64) break;			//too few input to fill a block
			transform();
			full = 0;
			offset += copy;
			len -= copy;
		}
	}

	/**
	 * consolidates the input, and reinitialises the hash
	 * @return the hash value
	 */
	public byte[] digest() {
		int padsize1 = 1 + (55+64-full) % 64;
		int padsize2 = padsize1+8;
		byte pad[] = new byte[padsize2];
		pad[0] = (byte) 0x80;			//stop bit
		count <<= 3;					//message length in bits
		while (padsize1<padsize2) {
			pad[padsize1++] = (byte) (count & 0xff);
			count >>>= 8;
		}
		update(pad,0,padsize2);

		//return the digest
		byte digest[] = new byte[16];
		{
			int i=0, j=0;
			while (i<4) {
				int x = state[i++];
				digest[j++] = (byte)( x         & 0xff);
				digest[j++] = (byte)((x >>>  8) & 0xff);
				digest[j++] = (byte)((x >>> 16) & 0xff);
				digest[j++] = (byte)((x >>> 24)       );
			}
		}
		reset();
		return digest;
	}

	private void reset() {
		state[0] = 0x67452301;			//A
		state[1] = 0xefcdab89;			//B
		state[2] = 0x98badcfe;			//C
		state[3] = 0x10325476;			//D
		full = 0;
		count = 0;
	}

	private void transform() {
		{
			int i=0, j=0;
			while (i<16) {
				myblock[i++]
				=   ((int)block[j++]) & 0xff
				| ((((int)block[j++]) & 0xff) <<  8)
				| ((((int)block[j++]) & 0xff) << 16)
				| ((((int)block[j++])       ) << 24);
			}
		}
		System.arraycopy(state,0,mystate,0,4);
		for (int round=0; round<3; round++) {
			for (int line=0; line<16; line++) {
				int b = mystate[(17-line) & 0x3];
				int c = mystate[(18-line) & 0x3];
				int d = mystate[(19-line) & 0x3];
				switch (round) {
				case  0: d = ((b&c) | ((~b) & d)); break;
				case  1: d = ((b&c) | (b&d) | (c&d)) + 0x5A827999; break;
				default: d = (b^c^d) + 0x6ED9EBA1;
				}
				b = (16-line) & 0x3;	//index of a
				c = rotations[round][line & 0x3];
				d += mystate[b] + myblock[permutations[round][line]];
				mystate[b] = (d << c) | (d >>> (32-c));
			}
		}
		for (int i=0; i<4; i++) state[i] += mystate[i];
	}
}