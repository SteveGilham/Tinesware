package com.ravnaandtines.angerona.gui;

import java.awt.*;
import javax.swing.*;
import com.ravnaandtines.util.event.StatusEvent;
import com.ravnaandtines.util.event.StatusListener;



/**
*  Class LogPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class LogPanel extends JPanel implements StatusListener
{
    private BorderLayout lay = new BorderLayout();
    private JList log = new JList();
    private class LogListModel extends AbstractListModel
    {
        String[] tags = new String[100];
        int entries = 0;
        public int getSize() { return entries;}
        public Object getElementAt(int index)
        {
            if(index < 0 || index >= entries) return null;
            return tags[index];
        }
        public void addTag(String tag)
        {
            if(entries==100)
            {
                System.arraycopy(tags, 10, tags, 0, 90);
                entries = 90;
            }
            tags[entries++] = tag;
        }
    }
    private LogListModel model = new LogListModel();

    public LogPanel()
    {
        try
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        com.ravnaandtines.openPGP.keyring.Keyring.addStatusListener(this);
    }

    private void jbInit() throws Exception
    {
        setLayout(lay);
        add("Center", new JScrollPane(log));
        log.setModel(model);
    }

    public void statusChanged(StatusEvent e)
    {
        StatusEvent.Level level = e.getLevel();
        final String tag = level.toString()+" : "+e.getMessage();

        SwingUtilities.invokeLater( new Runnable () {
            public void run () {
                model.addTag(tag);
                com.ravnaandtines.Angerona.getMainFrame().setBarText(tag);
        }});
        if(level == StatusEvent.STATUS) return;
    /*
    public static final int STATUS = 0;
    public static final int INFO = 1;
    public static final int WARN = 2;
    public static final int ERROR = 3;
    public static final int FATAL = 4;
    public static final int CRASH = 5;
    */
    }
}