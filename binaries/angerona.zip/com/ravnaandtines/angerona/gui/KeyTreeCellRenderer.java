package com.ravnaandtines.angerona.gui;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.Component;
import com.ravnaandtines.util.image.IconFoundry;

/**
*  Class WriteOutputStream
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class KeyTreeCellRenderer extends DefaultTreeCellRenderer
{
    protected static final Icon key = new ImageIcon(IconFoundry.getIcon(IconFoundry.KEY));
    protected static final Icon lock = new ImageIcon(IconFoundry.getIcon(IconFoundry.LOCK));
    protected static final Icon unlock = new ImageIcon(IconFoundry.getIcon(IconFoundry.UNLOCK));
    protected static final Icon user = new ImageIcon(IconFoundry.getIcon(IconFoundry.USER));
    protected static final Icon tick = new ImageIcon(IconFoundry.getIcon(IconFoundry.TICK));
    protected static final Icon cross = new ImageIcon(IconFoundry.getIcon(IconFoundry.CROSS));

    public KeyTreeCellRenderer()
    {
        super();
    }
    /**
      * Configures the renderer based on the passed in components.
      * The value is set from messaging value with toString().
      * The foreground color is set based on the selection and the icon
      * is set based on on leaf and expanded.
      */
    public Component getTreeCellRendererComponent(JTree tree, Object value,
						  boolean sel,
						  boolean expanded,
						  boolean leaf, int row,
						  boolean hasFocus) {
	String         stringValue = tree.convertValueToText(value, sel,
					  expanded, leaf, row, hasFocus);

	setText(stringValue);
	if(sel)
	    setForeground(getTextSelectionColor());
	else
	    setForeground(getTextNonSelectionColor());

    if(value instanceof PubKeyFolder)
    {
        setIcon(key);
    }
    else if(value instanceof SecKeyFolder)
    {
        setIcon(
            ((SecKeyFolder)value).toKey().isLocked() ?
            lock : unlock
        );
    }
    else if(value instanceof UserIDFolder)
    {
        setIcon(user);
    }
    else if(value instanceof SignatureFolder)
    {
        SignatureFolder sig = (SignatureFolder)value;
        if(!sig.isKnownSigner()) setIcon(null/*getClosedIcon()*/);
        else setIcon(sig.isGoodSignature() ? tick : cross);
    }
	else if(!leaf) {
	    setIcon(getClosedIcon());
	}
	else {
	    setIcon(null);
	}
	    
	selected = sel;

	return this;
    }
}
