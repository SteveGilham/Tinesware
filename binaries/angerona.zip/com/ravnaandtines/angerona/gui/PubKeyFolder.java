package com.ravnaandtines.angerona.gui;

import javax.swing.tree.DefaultMutableTreeNode;
import com.ravnaandtines.util.Sortable;
import com.ravnaandtines.openPGP.keyring.*;


/**
*  Class PubKeyFolder
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class PubKeyFolder extends DefaultMutableTreeNode implements Sortable
{
    private PublicKey key;
    boolean hasBeenExpanded;
    DefaultMutableTreeNode data = null;
    DefaultMutableTreeNode revoke = null;
    private UserID name = null;

    public PubKeyFolder(PublicKey keyIn)
    {
        key = keyIn;
        setUserObject(this);
        hasBeenExpanded = false;
    }

    public PubKeyFolder(PublicKey keyIn, UserID nameIn)
    {
        key = keyIn;
        name = nameIn;
        setUserObject(this);
        hasBeenExpanded = false;
    }

    public String toString()
    {
        if(name != null) return name.getName();
        return key.getName();
    }

    public int compareTo(Sortable b)
    {
        if(null == b) return 1;
        return toString().toUpperCase().compareTo(
            ((PubKeyFolder)b).toString().toUpperCase());
    }

    public PublicKey toKey()
    {
        return key;
    }

    public boolean setExpanded(boolean expanded)
    {
        if(!hasBeenExpanded)
        {
            data = new DefaultMutableTreeNode(key.data(), false);
            this.add(data);
            if(key.isRevoked())
            {
                 revoke = new DefaultMutableTreeNode("NOTE: This key has been revoked", false);
                 this.add(revoke);
            }

            for(Signature s = key.getSignature(); s != null;
                s = s.nextSignature())
            {
                SignatureFolder f = new SignatureFolder(s, key, null);
                this.add(f);
            }

            for(PublicKey k = key.getSubkey(); (k!=null);
                k = k.getSubkey())
            {
                PubKeyFolder f = new PubKeyFolder(k);
                this.add(f);
            }

            for(UserID u = key.getUsername(); u != null;
                u = u.nextUsername())
            {
                UserIDFolder f = new UserIDFolder(u, key);
                this.add(f);
                for(Signature s = u.getSignature(); s != null;
                    s = s.nextSignature())
                {
                    SignatureFolder f2 = new SignatureFolder(s, key, u);
                    f.add(f2);
                    f2.pubkey();
                }
            }

            hasBeenExpanded = true;
            return true;
        }
        return false;
    }

    public void able()
    {
        if(!hasBeenExpanded) return;
        data.setUserObject(key.data());
    }

    public void reset()
    {
        if(!hasBeenExpanded) return;
        removeAllChildren();
        hasBeenExpanded = false;
        data = null;
        revoke = null;
    }
}
