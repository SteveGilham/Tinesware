package com.ravnaandtines.angerona.gui;

import javax.swing.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.*;
import com.ravnaandtines.crypt.cea.Cypher;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.text.Mnemonic;

/**
*  Class AlgPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class AlgPanel extends JPanel
{
    private static final String CEAprop = "EncryptionAlgorithm";
    private static final String CEMprop = "EncryptionMode";
    private static final String MDAprop = "MessageDigestAlgorithm";
    private static final String CPAprop = "CompressionAlgorithm";
    private static final String ARMprop = "Armour";

    private GridBagLayout grid = new GridBagLayout();
    private GridBagConstraints c = new GridBagConstraints();

    private JLabel label1 = new JLabel();
    private JComboBox CEAbox = null;
    private JLabel label2 = new JLabel();
    private JComboBox CEMbox = null;
    private JLabel label3 = new JLabel();
    private JComboBox MDAbox = null;
    private JLabel label4 = new JLabel();
    private JComboBox CPAbox = null;
    private JLabel label5 = new JLabel();
    private JComboBox ARMbox = null;
    private int base = 0;
    private boolean loaded = false;

    private String[] algs = {"IDEA 128bit (2.6)", "CAST 128bit (5)",
                   "Blowfish 128bit (OpenPGP)", "Square 128bit",
                   "Safer-SK128 (EBP)", "TEA 128-bit", "TripleDES (5)"};
    private int []   algn = new int[algs.length];
    //{KeyConst.CEA_IDEA, KeyConst.CEA_CAST5,
    //               KeyConst.CEA_GPG_BLOW16, KeyConst.CEA_SQUARE,
    //               KeyConst.CEA_EBP_SAFER_MIN, KeyConst.CEA_TEA,
    //               KeyConst.CEA_3DES};

    private String[] mode = {"Cypher FeedBack (2.6)", "Cypher Block Chaining"};
    private int[]    modn = new int[mode.length];
    //{KeyConst.CEM_CFB, KeyConst.CEM_CBC};

    private String[] cpa  = {"None (2.6)", "Deflate (2.6)", "Splay tree"};
    private int[]    cpan = new int[cpa.length];
    //{KeyConst.CPA_NONE, KeyConst.CPA_DEFLATE,
    //               KeyConst.CPA_SPLAY};

    private String[] mda  = {"MD5 128-bit (2.6)", "SHA-1 160-bit (5)",
                   "RIPEM 160-bit", "Haval 256-bit (EBP)"};
    private int[]    mdan = new int[mda.length];
    //{KeyConst.MDA_MD5, KeyConst.MDA_PGP5_SHA1,
    //               KeyConst.MDA_PGP5_RIPEM160,KeyConst.MDA_EBP_HAVAL_MIN};

    private String[] arm  = {"None (2.6)", "PGP armour (2.6)", "UUencode"};
    private int[]    armn = new int[arm.length];
    //{KeyConst.ARM_NONE, KeyConst.ARM_PGP,
    //               KeyConst.ARM_UUENCODE};

    
    public AlgPanel()
    {
        try 
        {
            base = Cypher.isAlgorithmAvailable(Cypher.IDEA)? 0 : 1;
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    void jbInit() throws Exception
    {
        CEAbox = new JComboBox(algs);
        if(!Cypher.isAlgorithmAvailable(Cypher.IDEA))
        {
            CEAbox.removeItem(algs[0]);
        }
        CEMbox = new JComboBox(mode);
        MDAbox = new JComboBox(mda);
        CPAbox = new JComboBox(cpa);
        ARMbox = new JComboBox(arm);

        this.setLayout(grid);

        Mnemonic cea = new Mnemonic("&Conventional Encryption");
        Mnemonic cem = new Mnemonic("&Encryption Mode");
        Mnemonic mda = new Mnemonic("&Message Digest");
        Mnemonic cpa = new Mnemonic("C&ompression Scheme");
        Mnemonic arm = new Mnemonic("&Armour Style");

        label1.setText(cea.getLabel());
        label1.setLabelFor(CEAbox);
        label1.setDisplayedMnemonic(cea.getMnemonic());
        label1.setHorizontalTextPosition(SwingConstants.RIGHT);

        label2.setText(cem.getLabel());
        label2.setLabelFor(CEMbox);
        label2.setDisplayedMnemonic(cem.getMnemonic());
        label2.setHorizontalTextPosition(SwingConstants.RIGHT);

        label3.setText(mda.getLabel());
        label3.setLabelFor(MDAbox);
        label3.setDisplayedMnemonic(mda.getMnemonic());
        label3.setHorizontalTextPosition(SwingConstants.RIGHT);

        label4.setText(cpa.getLabel());
        label4.setLabelFor(CPAbox);
        label4.setDisplayedMnemonic(cpa.getMnemonic());
        label4.setHorizontalTextPosition(SwingConstants.RIGHT);

        label5.setText(arm.getLabel());
        label5.setLabelFor(ARMbox);
        label5.setDisplayedMnemonic(arm.getMnemonic());
        label5.setHorizontalTextPosition(SwingConstants.RIGHT);

        double lw = 0.0; // was 0.4

        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.weightx = lw;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.EAST;

        this.add(label1, c);

        c.gridx = 1;
        c.weightx = 0.6;
        this.add(CEAbox, c);

        ++c.gridy;
        c.gridx = 0;
        c.weightx = lw;
        this.add(label2, c);

        c.gridx = 1;
        c.weightx = 0.6;
        this.add(CEMbox, c);

        ++c.gridy;
        c.gridx = 0;
        c.weightx = lw;
        this.add(label3, c);

        c.gridx = 1;
        c.weightx = 0.6;
        this.add(MDAbox, c);

        ++c.gridy;
        c.gridx = 0;
        c.weightx = lw;
        this.add(label4, c);

        c.gridx = 1;
        c.weightx = 0.6;
        this.add(CPAbox, c);

        ++c.gridy;
        c.gridx = 0;
        c.weightx = lw;
        this.add(label5, c);

        c.gridx = 1;
        c.weightx = 0.6;
        this.add(ARMbox, c);

        CEAbox.addActionListener(new PutAction());
        CEMbox.addActionListener(new PutAction());
        MDAbox.addActionListener(new PutAction());
        CPAbox.addActionListener(new PutAction());
        ARMbox.addActionListener(new PutAction());
    }

    public void loadConfig()
    {
        String tmp;
        int index;

        tmp = Angerona.getSettings().getProperty(CEAprop,
            Integer.toString(base));
        index = base;
        try {
            index = Integer.decode(tmp).intValue();
            } catch (NumberFormatException e) {
            index = base;
        }
        index -= base;
        CEAbox.setSelectedIndex(index);

        tmp = Angerona.getSettings().getProperty(CEMprop, "0");
        index = 0;
        try {
            index = Integer.decode(tmp).intValue();
            } catch (NumberFormatException e) {
            index = 0;
        }
        CEMbox.setSelectedIndex(index);

        tmp = Angerona.getSettings().getProperty(MDAprop, "0");
        index = 0;
        try {
            index = Integer.decode(tmp).intValue();
            } catch (NumberFormatException e) {
            index = 0;
        }
        MDAbox.setSelectedIndex(index);

        tmp = Angerona.getSettings().getProperty(CPAprop, "1");
        index = 1;
        try {
            index = Integer.decode(tmp).intValue();
            } catch (NumberFormatException e) {
            index = 1;
        }
        CPAbox.setSelectedIndex(index);

        tmp = Angerona.getSettings().getProperty(ARMprop, "1");
        index = 1;
        try {
            index = Integer.decode(tmp).intValue();
            } catch (NumberFormatException e) {
            index = 1;
        }
        ARMbox.setSelectedIndex(index);

        loaded = true;
    }

    public void setAlgs()
    {
        //EncryptInsts.setAlgs(algn[CEAbox.getSelectedIndex()+base],
        //                     modn[CEMbox.getSelectedIndex()],
        //                     mdan[MDAbox.getSelectedIndex()],
        //                     cpan[CPAbox.getSelectedIndex()],
        //                     armn[ARMbox.getSelectedIndex()]);
    }

    public byte getMDA()
    {
        return (byte) mdan[MDAbox.getSelectedIndex()];
    }
    public byte getCPA()
    {
        return (byte) cpan[CPAbox.getSelectedIndex()];
    }
    public byte getARM()
    {
        return (byte) armn[ARMbox.getSelectedIndex()];
    }
    public boolean isArmoured()
    {
        return ARMbox.getSelectedIndex() > 0;
    }

    private class PutAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent parm1)
        {
            if(!AlgPanel.this.loaded) return;

            Angerona.getSettings().put(CEAprop,
                          Integer.toString(AlgPanel.this.CEAbox.getSelectedIndex()+base));
            Angerona.getSettings().put(CEMprop,
                          Integer.toString(AlgPanel.this.CEMbox.getSelectedIndex()));
            Angerona.getSettings().put(MDAprop,
                          Integer.toString(AlgPanel.this.MDAbox.getSelectedIndex()));
            Angerona.getSettings().put(CPAprop,
                          Integer.toString(AlgPanel.this.CPAbox.getSelectedIndex()));
            Angerona.getSettings().put(ARMprop,
                          Integer.toString(AlgPanel.this.ARMbox.getSelectedIndex()));
        }
    }
}

