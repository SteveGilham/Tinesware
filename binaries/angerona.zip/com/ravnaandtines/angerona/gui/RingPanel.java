package com.ravnaandtines.angerona.gui;

import java.awt.*;
import java.awt.FileDialog;
import java.awt.event.*;
import javax.swing.*;
import com.ravnaandtines.util.swing.GroupBox;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.io.IO;
import com.ravnaandtines.openPGP.keyring.Keyring;

/**
*  Class RingPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class RingPanel extends JPanel
{
    private static final String PKFprop = "PublicKeyring";
    private static final String PKDprop = "PublicKeyringDirectory";
    private static final String SKFprop = "SecretKeyring";
    private static final String SKDprop = "SecretKeyringDirectory";

    private GridLayout gridLayout1 = new GridLayout(2,1);
    private GroupBox pubBox = new GroupBox("Public Keyring File");
    private GroupBox secBox = new GroupBox("Secret Keyring File");
    private JTextField pubField = new JTextField();
    private JTextField secField = new JTextField();
    private JButton pubButton = new JButton();
    private JButton secButton = new JButton();
    private JLabel secLabel = new JLabel("Loaded");
    private JLabel pubLabel = new JLabel("Loaded");
    private FlowLayout flowLayout2 = new FlowLayout();
    private FlowLayout flowLayout3 = new FlowLayout();
    private FileDialog filer = null;
    private String pubfile, pubdir;
    private String secfile, secdir;
    private boolean pubValid = false;
    private boolean secValid = false;

    public RingPanel()
    {
        try 
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception
    {
        pubBox.setLayout(flowLayout2);
        secBox.setLayout(flowLayout3);

        pubField.setEditable(false);
        pubField.setColumns(20);
        secField.setEditable(false);
        secField.setColumns(20);
        pubButton.addActionListener(new pubBrowse());
        pubButton.setText("Browse...");

        secButton.addActionListener(new secBrowse());
        secButton.setText("Browse...");

        this.setLayout(gridLayout1);
        this.add(pubBox);
        pubBox.add(pubField);
        pubBox.add(pubButton);
        this.add(secBox);
        secBox.add(secField);
        secBox.add(secButton);

        // keyboard enabling 
        pubButton.registerKeyboardAction(new pubBrowse(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        secButton.registerKeyboardAction(new secBrowse(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    public boolean isSecValid()
    {
        return secValid;
    }

    public boolean isPubValid()
    {
        return pubValid;
    }

    public void loadConfig()
    {
        pubfile = Angerona.getSettings().getProperty(PKFprop, "");
        pubdir  = Angerona.getSettings().getProperty(PKDprop, "");
        pubField.setText(pubdir + pubfile);
        secfile = Angerona.getSettings().getProperty(SKFprop, "");
        secdir  = Angerona.getSettings().getProperty(SKDprop, "");
        secField.setText(secdir + secfile);
    }

    void pubButton_actionPerformed()
    {
        if (filer==null) filer = new FileDialog(Angerona.getMainFrame(),"Open keyring...",FileDialog.LOAD);
        filer.setDirectory(pubdir);
        filer.setFile(pubfile);
        filer.show();
        String pd = filer.getDirectory();
        String pf = filer.getFile();
        if(pd != null && pf != null)
        {
            if(!IO.ensureRWFile(pd+pf)) return;
            pubField.setText(pd+pf);
            Angerona.getSettings().put(PKDprop, pd);
            Angerona.getSettings().put(PKFprop, pf);
            pubdir = pd;
            pubfile = pf;
            invalidatePubkeys();
        }
    }

    void secButton_actionPerformed()
    {
        if (filer==null) filer = new FileDialog(Angerona.getMainFrame(),"Open keyring...",FileDialog.LOAD);
        filer.setDirectory(secdir);
        filer.setFile(secfile);
        filer.show();
        String sd = filer.getDirectory();
        String sf = filer.getFile();
        if(sd != null && sf != null)
        {
            if(!IO.ensureRWFile(sd+sf)) return;
            secField.setText(sd+sf);
            Angerona.getSettings().put(SKDprop, sd);
            Angerona.getSettings().put(SKFprop, sf);
            secdir = sd;
            secfile = sf;
            invalidateSeckeys();
        }
    }

    void loadPubkeys()
    {
        if(pubValid) return;
        if(0==pubdir.length() && 0==pubfile.length()) return;
        if(!IO.ensureRWFile(pubdir+pubfile)) return;
        // spawn into worker thread
        pubValid = Keyring.readPubring(pubdir+pubfile);
        if(pubValid)
        {
            pubBox.remove(pubButton);
            pubBox.add(pubLabel);
            validate();
        }
    }

    void invalidatePubkeys()
    {
        if(!Keyring.clear())
        {
            JOptionPane.showMessageDialog(
                Angerona.getMainFrame(), "Changes to keyrings could not be saved",
                "CTC Keyring shutdown" ,
                JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        if(pubValid)
        {
            pubBox.add(pubButton);
            pubBox.remove(pubLabel);
            pubValid = false;
            validate();
        }
        if(secValid)
        {
            secBox.add(secButton);
            secBox.remove(secLabel);
            secValid = false;
        }
    }

    void loadSeckeys()
    {
        if(secValid) return;
        if(0==secdir.length() && 0==secfile.length()) return;
        if(!IO.ensureRWFile(secdir+secfile)) return;
        loadPubkeys();
        if(pubValid)
        {
            secValid = Keyring.readSecring(secdir+secfile);
        }
        if(secValid)
        {
            secBox.remove(secButton);
            secBox.add(secLabel);
            validate();
        }
    }

    void invalidateSeckeys()
    {
        invalidatePubkeys();
        loadPubkeys();
    }

    private class pubBrowse extends AbstractAction {
        public void actionPerformed(ActionEvent e)
        {
            RingPanel.this.pubButton_actionPerformed();
        }
    }

    private class secBrowse extends AbstractAction {
        public void actionPerformed(ActionEvent e)
        {
            RingPanel.this.secButton_actionPerformed();
        }
    }
}

 