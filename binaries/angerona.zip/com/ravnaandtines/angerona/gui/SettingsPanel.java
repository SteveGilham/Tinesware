package com.ravnaandtines.angerona.gui;

import java.awt.event.*;
import java.awt.GridLayout;
import javax.swing.*;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.text.Mnemonic;

/**
*  Class SettingsPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class SettingsPanel extends JPanel implements ItemListener
{
    // Needs gridbagging and keyboard handling for checkbox - if there is such

    private static final String checkProp = "ShowChecksums";
    private static final String signProp = "DefaultSigner";
    private static final String quoteProp = "QuoteString";

    private GridLayout gridLayoutx = new GridLayout(7,1);

    private JPanel panel0 = new JPanel();
    private JCheckBox showChecksums = new JCheckBox("Show passphrase checksum");

    private JPanel panel1 = new JPanel();
    private JLabel label1 = new JLabel();
    private JTextField quoteField = new JTextField();
    private GridLayout gridLayout1 = new GridLayout(1,2,5,0);

    private JPanel panel2 = new JPanel();
    private GridLayout gridLayout2 = new GridLayout(1,2,5,0);
    private JLabel label2 = new JLabel();
    private JTextField idField = new JTextField();

    private boolean bshowChecksums = false;

    public SettingsPanel()
    {
        try
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception
    {
        this.setLayout(gridLayoutx);

        panel0.add(showChecksums);
        showChecksums.addItemListener(this);
        this.add(panel0);

        Mnemonic quote = new Mnemonic("&Quote string");
        Mnemonic did = new Mnemonic("&Default ID");

        panel1.setLayout(gridLayout1);
        label1.setText(quote.getLabel());
        label1.setLabelFor(quoteField);
        label1.setDisplayedMnemonic(quote.getMnemonic());
        label1.setHorizontalTextPosition(SwingConstants.RIGHT);
        panel1.add(label1);
        panel1.add(quoteField);
        this.add(panel1);

        panel2.setLayout(gridLayout2);
        label2.setText(did.getLabel());
        label2.setLabelFor(idField);
        label2.setDisplayedMnemonic(did.getMnemonic());
        label2.setHorizontalTextPosition(SwingConstants.RIGHT);
        panel2.add(label2);
        panel2.add(idField);
        this.add(panel2);
    }

    public void loadConfig()
    {
        String tmp = Angerona.getSettings().getProperty(checkProp, "");
        bshowChecksums = tmp.length() > 0;
        showChecksums.setSelected(bshowChecksums);

        tmp = Angerona.getSettings().getProperty(signProp, "");
        idField.setText(tmp);

        tmp = Angerona.getSettings().getProperty(quoteProp, "> ");
        quoteField.setText(tmp);
    }

    public void itemStateChanged(ItemEvent parm1)
    {
        bshowChecksums = showChecksums.isSelected();
        Angerona.getSettings().put(checkProp,
            (bshowChecksums?"yes":""));
    }
}

 