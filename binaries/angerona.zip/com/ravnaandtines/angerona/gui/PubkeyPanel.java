package com.ravnaandtines.angerona.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.tree.*;
import javax.swing.*;
import com.ravnaandtines.util.QSort;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import com.ravnaandtines.util.text.Mnemonic;
import com.ravnaandtines.openPGP.keyring.*;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.swing.SwingWorker;

/**
*  Class PubkeyPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

class Check
{
    public boolean b = false;
}

public class PubkeyPanel extends JPanel implements TreeExpansionListener, TreeSelectionListener
{
    private BorderLayout borderLayout1 = new BorderLayout();
    private DefaultMutableTreeNode root =
        new DefaultMutableTreeNode("Public_keys");
    private JTree tree = new JTree(root, true);

    private JMenuBar menuBar1 = new JMenuBar();
    private JMenu menuManage = new JMenu();
    private JMenuItem menuExtract = new JMenuItem();
    private JMenuItem menuSign = new JMenuItem();
    private JMenuItem menuAble = new JMenuItem();
    private JMenuItem menuDelete = new JMenuItem();

    public PubkeyPanel() {
        try {
            jbInit();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void jbInit() throws Exception
    {
        tree.addTreeExpansionListener(this);
        tree.addTreeSelectionListener(this);
        DefaultTreeSelectionModel model = new DefaultTreeSelectionModel();
        model.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setSelectionModel(model);
        tree.putClientProperty("JTree.lineStyle","Angled");
//        tree.setLargeModel(true);       // buggy
        tree.setCellRenderer(new KeyTreeCellRenderer());
        tree.setRowHeight(22); //can't do variable with large model

        Mnemonic ext = new Mnemonic("E&xtract");
        Mnemonic sig = new Mnemonic("&Sign");
        Mnemonic end = new Mnemonic("&En/Disable");
        Mnemonic del = new Mnemonic("&Delete");
        Mnemonic man = new Mnemonic("&Manage");


        menuExtract.setText(ext.getLabel());
        menuExtract.setMnemonic(ext.getMnemonic());
        menuExtract.addActionListener(new ExtractAction() );

        menuSign.setText(sig.getLabel());
        menuSign.setMnemonic(sig.getMnemonic());
        menuSign.addActionListener(new SignAction());

        menuAble.setText(end.getLabel());
        menuAble.setMnemonic(end.getMnemonic());
        menuAble.addActionListener(new AbleAction());

        menuDelete.setText(del.getLabel());
        menuDelete.setMnemonic(del.getMnemonic());
        menuDelete.addActionListener(new DeleteAction());

        menuManage.setText(man.getLabel());
        menuManage.setMnemonic(man.getMnemonic());

        menuBar1.add(menuManage);
        menuManage.add(menuExtract);
        menuManage.add(menuSign);
        menuManage.add(menuAble);
        menuManage.add(menuDelete);

        this.setLayout(borderLayout1);
        this.add("Center", new JScrollPane(tree));
        this.add("North", menuBar1);
        valueChanged(null);
    }

    public void valueChanged(TreeSelectionEvent e)
    {
        TreePath selP = e == null? null : e.getPath();

        boolean isPubkey = false;
        boolean isSeckey = false;
        boolean isUsername = false;

        if(null != selP)
        {
            DefaultMutableTreeNode sel =
                (DefaultMutableTreeNode)selP.getLastPathComponent();

            isPubkey = (null != sel) && (sel instanceof PubKeyFolder)
                && (sel.getParent() == sel.getRoot());

            isSeckey = isPubkey;
            if(isSeckey)
            {
                SecretKey s = ((PubKeyFolder)sel).toKey().getSeckey();
                isSeckey = s != null;
            }

            isUsername = (null != sel) && (sel instanceof UserIDFolder)
                && (sel.getParent().getParent() == sel.getRoot());
        }

        menuExtract.setEnabled(isPubkey);
        menuSign.setEnabled(isPubkey||isUsername);
        menuAble.setEnabled(isPubkey);
        menuDelete.setEnabled(isPubkey && !isSeckey);
    }

    public void treeExpanded(TreeExpansionEvent event)
    {
        //TODO: implement this com.sun.java.swing.event.TreeExpansionListener method;
        TreePath p = event.getPath();
        DefaultMutableTreeNode sel = (DefaultMutableTreeNode)p.getLastPathComponent();
        if(sel instanceof PubKeyFolder)
        {
            if(((PubKeyFolder)sel).setExpanded(true))
            {
                ((DefaultTreeModel)tree.getModel()).reload(((PubKeyFolder)sel));
            }
        }
    }

    public void treeCollapsed(TreeExpansionEvent event)
    {
        //TODO: implement this com.sun.java.swing.event.TreeExpansionListener method;
    }

    SwingWorker offload;
    
    static Check loaded = new Check();
    static Check loading = new Check();

    void loadPubkeys()
    {
        synchronized(loading)
        {
            if(loading.b) return;
            loading.b = true;
        }
        synchronized(loaded)
        {
            if(loaded.b) return;
        }
        final Vector v = new Vector(20);
        offload = new SwingWorker() {
            public Object construct() {
                // this sort of GUI stuff has to go into the worker thread
                Angerona.getMainFrame().setBusy(true);
                Angerona.getMainFrame().setBarText("Reading public keys");
                Angerona.getMainFrame().loadPubkeys();
                if(!Angerona.getMainFrame().pubValid()) return null;
                if(Keyring.isValid())
                {
                    Enumeration e = Keyring.publicKeys();
                    while(e.hasMoreElements())
                    {
                        PublicKey pk = (PublicKey)e.nextElement();
                        if(pk == null) break;
                        PubKeyFolder kf = new PubKeyFolder(pk);
                        v.addElement(kf);
                    }

                    Angerona.getMainFrame().setBarText("Sorting public keys");
                    QSort.sortables(v);
                    Angerona.getMainFrame().setBarText("Loading public keys");

                    // now we can post the components to the GUI and shake them up
                    SwingUtilities.invokeLater( new Runnable () {
                        public void run() {
                            for(int i=0; i<v.size(); ++i)
                            {
                                PubKeyFolder kf = (PubKeyFolder)(v.elementAt(i));
                                root.add(kf);
                            }
//System.out.println("Added "+v.size()+" folders - root has "+root.getChildCount()+" children");
                            ((DefaultTreeModel)tree.getModel()).reload();
                    }});
                    synchronized(loaded)
                    {
                        loaded.b = true;
                    }
                }
                return null;
            }
            public void finished() {
                Angerona.getMainFrame().setBarText("Public keys loaded");
                Angerona.getMainFrame().setBusy(false);
                System.gc();
            }
        }; // end class
    }

    void extract_actionPerformed()
    {
        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();
        if(null == sel) return;
        if(!(sel instanceof PubKeyFolder)) return;
        ((PubKeyFolder)sel).toKey().extract();
    }

    void sign_actionPerformed()
    {
        Angerona.getMainFrame().loadSeckeys();
        if(!Angerona.getMainFrame().secValid()) return;

        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();

        boolean isPubkey = (null != sel) && (sel instanceof PubKeyFolder)
            && (sel.getParent() == sel.getRoot());

        boolean isUsername = (null != sel) && (sel instanceof UserIDFolder)
            && (sel.getParent().getParent() == sel.getRoot());

        if(!isPubkey && !isUsername) return;

        JTextArea ta = new JTextArea(
            "READ CAREFULLY:  Based on your own direct first-hand knowledge, are you absolutely certain that you are prepared to solemnly certify that the above public key actually belongs to the user specified by the above user ID?"
        );
        ta.setEditable(false);

        if(JOptionPane.showConfirmDialog(
            Angerona.getMainFrame(), ta, "Key signature found",
            JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;

        // find the signing key...
        SecKeyFolder skf = null ;//EncryptInsts.getSignatory();
        if(null == skf) return;

        SecretKey key = skf.toKey();
        if(key.unlock())
        {
            if(isPubkey)
            {
                ((PubKeyFolder)sel).toKey().sign(key);
                ((PubKeyFolder)sel).reset();
            }
            else
            {
                ((UserIDFolder)sel).toName().sign(key,
                ((PubKeyFolder)(sel.getParent())).toKey() );
                ((PubKeyFolder)(sel.getParent())).reset();
            }
        }
    }

    void able_actionPerformed()
    {
        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();
        if(null == sel) return;
        if(!(sel instanceof PubKeyFolder)) return;
            ((PubKeyFolder)sel).toKey().able();
            ((PubKeyFolder)sel).able();
    }

    void delete_actionPerformed()
    {
        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();
        if(null == sel) return;
        if(!(sel instanceof PubKeyFolder)) return;
        ((PubKeyFolder)sel).toKey().delete();
        root.remove(((PubKeyFolder)sel));
    }


    private class ExtractAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            PubkeyPanel.this.extract_actionPerformed();
        }
    }

    private class SignAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            PubkeyPanel.this.sign_actionPerformed();
        }
    }

    private class AbleAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            PubkeyPanel.this.able_actionPerformed();
        }
    }

    private class DeleteAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            PubkeyPanel.this.delete_actionPerformed();
        }
    }

}

