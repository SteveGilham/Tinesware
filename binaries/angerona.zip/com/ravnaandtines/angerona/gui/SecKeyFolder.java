package com.ravnaandtines.angerona.gui;

import javax.swing.tree.DefaultMutableTreeNode;
import com.ravnaandtines.util.Sortable;
import com.ravnaandtines.openPGP.keyring.*;

/**
*  Class WriteOutputStream
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class SecKeyFolder extends DefaultMutableTreeNode implements Sortable
{
    private SecretKey key;
    private UserID name;

    public SecKeyFolder(SecretKey keyIn)
    {
        key = keyIn;
        setUserObject(this);
        PubKeyFolder f = new PubKeyFolder(key.getPubkey());
    }

    public SecKeyFolder(SecretKey keyIn, UserID nameIn)
    {
        key = keyIn;
        name = nameIn;
        setUserObject(this);
    }

    public void pubkey()
    {
        PubKeyFolder f = new PubKeyFolder(key.getPubkey());
        this.add(f);
    }

    public String toString()
    {
        if(name != null) return name.getName();
        return key.getPubkey().getName();
    }

    public int compareTo(Sortable b)
    {
        if(null == b) return 1;
        return toString().toUpperCase().compareTo(
            ((SecKeyFolder)b).toString().toUpperCase());
    }

    public SecretKey toKey()
    {
        return key;
    }
}

