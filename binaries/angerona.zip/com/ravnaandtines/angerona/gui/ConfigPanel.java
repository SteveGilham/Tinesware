package com.ravnaandtines.angerona.gui;

import java.awt.event.*;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.*;
import com.ravnaandtines.util.io.IO;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.text.Mnemonic;

/**
*  Class ConfigPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class ConfigPanel extends JPanel
{
    private JButton browse = new JButton();
    private BorderLayout borderLayout1 = new BorderLayout();
    private FlowLayout flowLayout1 = new FlowLayout();
    private JPanel holder = new JPanel();
    private FileDialog configFiler = null;
    private JPanel bevelPanel1 = new JPanel();
    private GridLayout gridLayout1 = new  GridLayout(6,1);
    private JLabel label1 = new JLabel();
    private JLabel label2 = new JLabel();
    private JLabel label3 = new JLabel();
    private JLabel label4 = new JLabel();
    private JLabel label5 = new JLabel();
    private JLabel label6 = new JLabel();

    public ConfigPanel()
    {
        try 
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    void forceFocus()
    {
        browse.requestFocus();
    }


    // GUI layout
    void jbInit() throws Exception
    {
        this.setLayout(borderLayout1);

        Mnemonic browser = new Mnemonic("&Browse");

        browse.setText(browser.getLabel());
        browse.setMnemonic(browser.getMnemonic());
        browse.addActionListener(new BrowseAction());

        bevelPanel1.setLayout(gridLayout1);
        bevelPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
        bevelPanel1.add(label1);
        bevelPanel1.add(label2);
        bevelPanel1.add(label3);
        bevelPanel1.add(label4);
        bevelPanel1.add(label5);
        bevelPanel1.add(label6);
        label5.setText("Please select your configuration file.");
        label6.setText("If the file does not exist, an empty one will be created.");
        updateText();
        this.add("Center", bevelPanel1);

        this.add("South", holder);
        holder.setLayout(flowLayout1);
        holder.add(browse);

        // keyboard enabling
        registerKeyboardAction(new BrowseAction(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    // Fill in reasons why we couldn't get a settings file
    private void updateText()
    {
        if(Angerona.getConfigFile().length() == 0)
        {
            label1.setText("This program expects a configuration file on the command line.");
            label3.setText("Syntax: jre com.ravnaandtines.Angerona <config file>");
        }
        else
        {
            label1.setText("Read/write access could not be gained to the supplied file:");
            label3.setText("Filename:"+" "+Angerona.getConfigFile());
        }
    }

    // Update in response to a selection
    void setConfigReaction()
    {
        if(IO.ensureRWFile(Angerona.getConfigFile()))
        {
            Angerona.getMainFrame().doUsualTabs();
        }
        else updateText();
    }

    // Selection action
    private class BrowseAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            if(null == ConfigPanel.this.configFiler)
            {
                ConfigPanel.this.configFiler =
                new FileDialog(Angerona.getMainFrame(),
                       "Load configuration file", FileDialog.LOAD);
            }
            ConfigPanel.this.configFiler.setFile(Angerona.getConfigFile());
            ConfigPanel.this.configFiler.show();
            String dir = ConfigPanel.this.configFiler.getDirectory();
            String file = ConfigPanel.this.configFiler.getFile();
            if(null == file || null == dir)
            {
                Angerona.setConfigFile("");
            }
            else
            {
                Angerona.setConfigFile(dir+file);
            }
            ConfigPanel.this.setConfigReaction();
        }
    }
}

 