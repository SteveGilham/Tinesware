package com.ravnaandtines.angerona.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.io.IO;
import com.ravnaandtines.util.image.IconFoundry;
import com.ravnaandtines.crypt.cea.Cypher;
import com.ravnaandtines.util.gui.LicenceDialog;
import java.util.Hashtable;
import com.ravnaandtines.util.text.Mnemonic;

//Title:      Angerona
//Version:
//Copyright:  Copyright (c) 1998
//Author:     Mr. Tines
//Company:    Ravna & Tines
//Description:A full OpenPGP compatible freeware cryptosystem.
//Development is incremental, so early issues will
//only have partial functionality
public class MainFrame extends JFrame
{
    private LicenceDialog dlg = null;

    //Above the content pane
    private JMenuBar menuBar1 = new JMenuBar();

    private JMenu menuFile = new JMenu();
    private JMenuItem menuFileNew = new JMenuItem();
    private JMenuItem menuFileOpen = new JMenuItem();
    private JMenuItem menuFileReadPOP3 = new JMenuItem();
    private JMenuItem menuFileSavePref = new JMenuItem();
    private JMenuItem menuFileExit = new JMenuItem();

    private JMenu menuKeys = new JMenu();
    private JMenuItem menuKeysGen = new JMenuItem();
    private JMenuItem menuKeysLock = new JMenuItem();

    private JMenu menuHelp = new JMenu();
    private JMenuItem menuHelpAbout = new JMenuItem();
    private JMenuItem menuHelpAboutIDEA = new JMenuItem();

    private BorderLayout borderLayout1 = new BorderLayout(); // for the content pane

    // top of content pane
    private JToolBar toolBar = new JToolBar();

    // centre of content panel
    private JTabbedPane mainTabset = new JTabbedPane();
    private boolean configNeeded = false;
    private ConfigPanel configPanel = new ConfigPanel();

    private AboutPanel aboutPanel = new AboutPanel();
    private PubkeyPanel pubkeyPanel = new PubkeyPanel();
    private SeckeyPanel seckeyPanel = new SeckeyPanel();
    private SettingsPanel settingsPanel = new SettingsPanel();
    private RingPanel ringPanel = new RingPanel();
    private AlgPanel algPanel = new AlgPanel();
    private LogPanel logPanel = new LogPanel();

    // bottom of content pane
    private JLabel statusBar = new JLabel();

    // non-graphic elements
    private Hashtable openFileList = new Hashtable();
    private FileDialog openDialog = new FileDialog(this, "Open...", FileDialog.LOAD);

    public MainFrame()
    {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try
        {
            jbInit();
            Component glass = getGlassPane();
            glass.setCursor(Cursor.getPredefinedCursor(
                Cursor.WAIT_CURSOR));
            // trap all user interaction and work around an AWT
            // but on Cursors.
            glass.addMouseListener( new MouseAdapter() {
                public void mousePressed(MouseEvent e) {}
            });
            checkConfiguration();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void setBusy(boolean busy)
    {   //Thread safe setting
        final boolean x = busy;
        com.ravnaandtines.util.swing.Utilities.invokeNow(new Runnable () {
            public void run() {
                MainFrame.this.getGlassPane().setVisible(x);
        }});
    }

    //Component initialization
    private void jbInit() throws Exception
    {
        // whole frame level
        this.setIconImage(IconFoundry.getIcon(IconFoundry.ICON));
        this.setSize(new Dimension(400, 300));
        if(Cypher.isAlgorithmAvailable(Cypher.IDEA))
        {
            this.setTitle("Angerona (IDEA enabled)");
        }
        else
        {
            this.setTitle("Angerona (IDEA free)");
        }
        this.getContentPane().setLayout(borderLayout1);

        //Mnemonics
        Mnemonic file = new Mnemonic("&File");
        Mnemonic mnew = new Mnemonic("&New");
        Mnemonic open = new Mnemonic("&Open...");
        Mnemonic read = new Mnemonic("&Read POP3 Mail...");
        Mnemonic save = new Mnemonic("&Save Preferences");
        Mnemonic exit = new Mnemonic("E&xit");
        Mnemonic help = new Mnemonic("&Help");
        Mnemonic about= new Mnemonic("&About...");
        Mnemonic idea = new Mnemonic("About &IDEA...");
        Mnemonic keys = new Mnemonic("&Keys");
        Mnemonic gen  = new Mnemonic("&Generate...");
        Mnemonic lock = new Mnemonic("&Lock All");

        // Menu bar
        menuFile.setText(file.getLabel());
        menuFile.setMnemonic(file.getMnemonic());

        menuFileNew.setText(mnew.getLabel());
        menuFileNew.setMnemonic(mnew.getMnemonic());
        menuFileNew.addActionListener(new menuFileNewAction());
        menuFile.add(menuFileNew);

        menuFileOpen.setText(open.getLabel());
        menuFileOpen.setMnemonic(open.getMnemonic());
        menuFileOpen.addActionListener(new menuFileOpenAction());
        menuFile.add(menuFileOpen);

        menuFileReadPOP3.setText(read.getLabel());
        menuFileReadPOP3.setMnemonic(read.getMnemonic());
        menuFileOpen.addActionListener(new menuFileReadPOP3Action());
        menuFile.add(menuFileReadPOP3);
        menuFile.addSeparator();

        menuFileSavePref.setText(save.getLabel());
        menuFileSavePref.setMnemonic(save.getMnemonic());
        menuFileSavePref.addActionListener(new menuFileSavePrefAction());
        menuFile.add(menuFileSavePref);
        menuFile.addSeparator();

        menuFileExit.setText(exit.getLabel());
        menuFileExit.setMnemonic(exit.getMnemonic());
        menuFileExit.addActionListener(new menuFileExitAction());
        menuFile.add(menuFileExit);


        menuHelp.setText(help.getLabel());
        menuHelp.setMnemonic(help.getMnemonic());

        menuHelpAbout.setText(about.getLabel());
        menuHelpAbout.setMnemonic(about.getMnemonic());
        menuHelpAbout.addActionListener(new menuHelpAboutAction());
        menuHelp.add(menuHelpAbout);
        if(Cypher.isAlgorithmAvailable(Cypher.IDEA))
        {
            menuHelp.addSeparator();
            menuHelpAboutIDEA.setText(idea.getLabel());
            menuHelpAboutIDEA.setMnemonic(idea.getMnemonic());
            menuHelp.add(menuHelpAboutIDEA);
            menuHelpAboutIDEA.addActionListener(new menuHelpAboutIDEAAction());
        }

        menuKeys.setText(keys.getLabel());
        menuKeys.setMnemonic(keys.getMnemonic());

        menuKeysGen.setText(gen.getLabel());
        menuKeysGen.setMnemonic(gen.getMnemonic());
        menuKeysGen.addActionListener(new menuKeysGenAction());
        menuKeys.add(menuKeysGen);

        menuKeysLock.setText(lock.getLabel());
        menuKeysLock.setMnemonic(lock.getMnemonic());
        menuKeysLock.addActionListener(new menuKeysLockAction());
        menuKeys.add(menuKeysLock);

        menuBar1.add(menuFile);
        menuBar1.add(menuKeys);
        menuBar1.add(menuHelp);
        this.setJMenuBar(menuBar1);

        // toolbar at top
        toolBar.add(new menuFileNewAction()).setToolTipText(mnew.getLabel());
        toolBar.add(new menuFileOpenAction()).setToolTipText(open.getLabel());
        toolBar.add(new menuFileReadPOP3Action()).setToolTipText(read.getLabel());
        toolBar.addSeparator();
        toolBar.add(new menuFileSavePrefAction()).setToolTipText(save.getLabel());
        toolBar.addSeparator();
        toolBar.add(new menuHelpAboutAction()).setToolTipText(about.getLabel());
        if(Cypher.isAlgorithmAvailable(Cypher.IDEA))
        {
            toolBar.add(new menuHelpAboutIDEAAction()).setToolTipText(idea.getLabel());
        }
        toolBar.addSeparator();
        toolBar.add(new menuBreakAction()).setToolTipText("Break");

        toolBar.setFloatable(false);
        toolBar.setBorder( BorderFactory.createRaisedBevelBorder() );
        this.getContentPane().add(toolBar, BorderLayout.NORTH);

        // tabbed pane in the middle
        mainTabset.addChangeListener(new javax.swing.event.ChangeListener()
        {
            public void stateChanged(javax.swing.event.ChangeEvent e)
            {
                tabsetItemChanged();
            }
        });
        this.getContentPane().add(mainTabset, BorderLayout.CENTER);

        // status bar at bottom
        statusBar.setBorder( BorderFactory.createLoweredBevelBorder() );
        statusBar.setHorizontalAlignment(SwingConstants.LEFT);
        statusBar.setText("Welcome to Angerona");
        this.getContentPane().add(statusBar, BorderLayout.SOUTH);
    }

    private void checkConfiguration()
    {

        if(!IO.ensureRWFile(Angerona.getConfigFile()))
        {
            configNeeded = true;
            mainTabset.addTab("Configuration", configPanel);
        }
        else doUsualTabs();
    }

    public void forceFocus()
    {
        if(configNeeded) configPanel.forceFocus();
        else aboutPanel.forceFocus();
    }

    void doUsualTabs()
    {
        try
        {
            Mnemonic abt = new Mnemonic("A&bout");
            Mnemonic pub = new Mnemonic("&Public Keys");
            Mnemonic sec = new Mnemonic("&Secret Keys");
            Mnemonic set = new Mnemonic("Se&ttings");
            Mnemonic key = new Mnemonic("Key&rings");
            Mnemonic alg = new Mnemonic("A&lgorithms");
            Mnemonic log = new Mnemonic("L&og");
            int condition = //JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT;
                          JComponent.WHEN_IN_FOCUSED_WINDOW;
/*

Ctl-Tab doesn't get this far - it's swallowed as a Tab to change focus.
However the left and right arrow keys automatically have this effect if the focus
is in the tab (rather than its content).

            mainTabset.registerKeyboardAction(
                new tabShiftAction(-1),
                KeyStroke.getKeyStroke(
                    KeyEvent.VK_TAB,
                    ActionEvent.SHIFT_MASK|ActionEvent.CTRL_MASK, false),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
            mainTabset.registerKeyboardAction(
                new tabShiftAction(1),
                KeyStroke.getKeyStroke(
                    KeyEvent.VK_TAB,
                    ActionEvent.CTRL_MASK, false),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
*/

            if(configNeeded) mainTabset.removeTabAt(0);
            Angerona.loadConfig();
            mainTabset.addTab(null, abt, aboutPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(0),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(abt.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            mainTabset.addTab(null, pub, pubkeyPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(1),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(pub.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            mainTabset.addTab(null, sec, seckeyPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(2),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(sec.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            settingsPanel.loadConfig();
            mainTabset.addTab(null, set, settingsPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(3),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(set.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            ringPanel.loadConfig();
            mainTabset.addTab(null, key, ringPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(4),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(key.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            algPanel.loadConfig();
            mainTabset.addTab(null, alg, algPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(5),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(alg.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            mainTabset.addTab(null, log, logPanel);
            mainTabset.registerKeyboardAction(
                new tabSelectAction(6),
                KeyStroke.getKeyStroke(
                    Character.toUpperCase(log.getMnemonic()),
                    ActionEvent.ALT_MASK, false),
                    condition);

            } catch (Exception e) {
            e.printStackTrace();
        }
        aboutPanel.forceFocus();
    }


    // Accessor methods
    public void setBarText(String s)
    { //Thread safe setting
        final String x = s;
        com.ravnaandtines.util.swing.Utilities.invokeNow(new Runnable () {
            public void run() {
                String local = x;
                if(null == local || local.equals("")) local = " ";
                MainFrame.this.statusBar.setText(local);
        }});
    }

    public String getBarText()
    {
        return statusBar.getText();
    }

    // intercession
    public void loadPubkeys()
    {
        ringPanel.loadPubkeys();
    }

    public boolean pubValid()
    {
        return ringPanel.isPubValid();
    }
    public void loadSeckeys()
    {
        ringPanel.loadSeckeys();
    }

    public boolean secValid()
    {
        return ringPanel.isSecValid();
    }

    // events


//File | Exit action performed
    
    public void menuFileExit_actionPerformed()
    {
        System.exit(0);
    }
//Help | About action performed
    
    public void menuHelpAbout_actionPerformed()
    {
        if(null==dlg) dlg = new LicenceDialog(this, "About Angerona...");
        else dlg.setTitle("About Angerona...");
        Dimension frmSize = getSize();
        Dimension dlgSize = new Dimension(frmSize.width,  (2*frmSize.height)/3);
        dlg.setSize(dlgSize);
        Point loc = getLocation();
        dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.setText(com.ravnaandtines.Angerona.getAngerona());
        dlg.show();
    }
    public void menuHelpAboutIDEA_actionPerformed()
    {
        if(null==dlg) dlg = new LicenceDialog(this, "About IDEA...");
        else dlg.setTitle("About IDEA...");
        Dimension frmSize = getSize();
        Dimension dlgSize = new Dimension(frmSize.width,  (2*frmSize.height)/3);
        dlg.setSize(dlgSize);
        Point loc = getLocation();
        dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.setText(Cypher.IDEA_licence());
        dlg.show();
    }

    public LicenceDialog getLicenceDialog()
    {
        if(null==dlg) dlg = new LicenceDialog(this, "");
        else dlg.setTitle("");
        return dlg;
    }
//Overriden so we can exit on System Close

    protected void processWindowEvent(WindowEvent e)
    {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
        {
            menuFileExit_actionPerformed();
        }
    }

    void tabsetItemChanged()
    {
        if(mainTabset.getSelectedComponent() == pubkeyPanel)
        {
            pubkeyPanel.loadPubkeys();
        }
        if(mainTabset.getSelectedComponent() == seckeyPanel)
        {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            seckeyPanel.loadSeckeys();
        }
    }



    // inner classes for Actions
    private class menuFileExitAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
                MainFrame.this.menuFileExit_actionPerformed();
        }
    }
    private class menuFileNewAction extends AbstractAction
    {
        public menuFileNewAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.FILENEW)));
        }
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuFileNew_actionPerformed();
        }
    }
    private class menuFileOpenAction extends AbstractAction
    {
        public menuFileOpenAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.FILEOPEN)));
        }
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuFileOpen_actionPerformed();
        }
    }
    private class menuFileReadPOP3Action extends AbstractAction
    {
        public menuFileReadPOP3Action()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.MAILIN)));
        }
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuFileReadPOP3_actionPerformed();
        }
    }
    private class menuFileSavePrefAction extends AbstractAction
    {
        public menuFileSavePrefAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.FILESAVE)));
        }
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuFileSavePref_actionPerformed();
        }
    }
    private class menuHelpAboutAction extends AbstractAction
    {
        public menuHelpAboutAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.HELP)));
        }
        public void actionPerformed(ActionEvent e)
        {
                MainFrame.this.menuHelpAbout_actionPerformed();
        }
    }
    private class menuHelpAboutIDEAAction extends AbstractAction
    {
        public menuHelpAboutIDEAAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.INFO)));
        }
        public void actionPerformed(ActionEvent e)
        {
                MainFrame.this.menuHelpAboutIDEA_actionPerformed();
        }
    }
    private class menuKeysGenAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuKeysGen_actionPerformed();
        }
    }
    private class menuKeysLockAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.menuKeysLock_actionPerformed();
        }
    }
    private class menuBreakAction extends AbstractAction
    {
        public menuBreakAction()
        {
            super();
            putValue(Action.SMALL_ICON, new ImageIcon(
                IconFoundry.getIcon(IconFoundry.WARN)));
        }
        public void actionPerformed(ActionEvent e)
        {
                //MainFrame.this.break_actionPerformed();
        }
    }
    private class tabSelectAction extends AbstractAction
    {
        private int index = 0;
        public tabSelectAction(int index)
        {
            this.index = index;
        }
        public void actionPerformed(ActionEvent e)
        {
            MainFrame.this.mainTabset.setSelectedIndex(index);
        }
    }
/*
    private class tabShiftAction extends AbstractAction
    {
        private int index = 0;
        public tabShiftAction(int index)
        {
            this.index = index;
        }
        public void actionPerformed(ActionEvent e)
        {
            int selindex =
            MainFrame.this.mainTabset.getSelectedIndex()+index;
            while(selindex < 0) selindex += MainFrame.this.mainTabset.getTabCount();
            selindex %= MainFrame.this.mainTabset.getTabCount();
            MainFrame.this.mainTabset.setSelectedIndex(selindex);
        }
    }
*/
}

 