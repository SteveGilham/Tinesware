package com.ravnaandtines.angerona.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.tree.*;
import javax.swing.*;
import com.ravnaandtines.util.QSort;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import com.ravnaandtines.util.text.Mnemonic;
import com.ravnaandtines.openPGP.keyring.*;
import com.ravnaandtines.Angerona;

/**
*  Class SeckeyPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class SeckeyPanel extends JPanel implements TreeExpansionListener, TreeSelectionListener{
    private BorderLayout borderLayout1 = new BorderLayout();
    private DefaultMutableTreeNode root = new DefaultMutableTreeNode("Secret keys");
    private JTree tree = new JTree(root, true);
    private JPanel stick = new JPanel();
    private JButton revoke = new JButton();
    private JButton lock = new JButton();
    private GridLayout col = new GridLayout(6,1,3,3);

    public SeckeyPanel() {
        try {
        jbInit();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void jbInit() throws Exception
    {
        tree.addTreeExpansionListener(this);
        tree.addTreeSelectionListener(this);

        this.setLayout(borderLayout1);
        this.add("Center", new JScrollPane(tree));
        stick.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(6,6,6,6))
        );
        stick.setLayout(col);
        stick.add(lock);
        stick.add(revoke);
        this.add("West", stick);

        Mnemonic rev = new Mnemonic("&Revoke...");
        Mnemonic loc = new Mnemonic("&Lock");

        revoke.setText(rev.getLabel());
        revoke.setMnemonic(rev.getMnemonic());
        revoke.addActionListener(new RevokeAction());
        revoke.registerKeyboardAction(new RevokeAction(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        lock.setText(loc.getLabel());
        lock.setMnemonic(loc.getMnemonic());
        lock.addActionListener(new LockAction());
        lock.registerKeyboardAction(new LockAction(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        valueChanged(null);
    }

    public void valueChanged(TreeSelectionEvent e)
    {
        TreePath selP = e == null? null : e.getPath();

        boolean isSeckey = false;

        if(null != selP)
        {
            DefaultMutableTreeNode sel =
                (DefaultMutableTreeNode)selP.getLastPathComponent();
            isSeckey = (null != sel) && (sel instanceof SecKeyFolder);
        }
        revoke.setEnabled(isSeckey);
        lock.setEnabled(isSeckey);
    }

    public void treeExpanded(TreeExpansionEvent event)
    {
        //TODO: implement this com.sun.java.swing.event.TreeExpansionListener method;
    }

    public void treeCollapsed(TreeExpansionEvent event)
    {
        //TODO: implement this com.sun.java.swing.event.TreeExpansionListener method;
    }

    void loadSeckeys()
    {
        Angerona.getMainFrame().loadSeckeys();

        if(!Angerona.getMainFrame().secValid()) return;
        if(Keyring.isValid())
        {
            Enumeration e = Keyring.secretKeys();
            Vector v = new Vector(20);
            while(e.hasMoreElements())
            {
                SecretKey sk = (SecretKey)e.nextElement();
                if(null == sk) break;
                SecKeyFolder kf = new SecKeyFolder(sk);
                v.addElement(kf);
            }

            QSort.sortables(v);
            for(int i=0; i<v.size(); ++i)
            {
                SecKeyFolder kf = (SecKeyFolder)(v.elementAt(i));
                root.add(kf);
                kf.pubkey();
            }
        }
    }

    void revoke_actionPerformed()
    {
        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();

        boolean isSeckey = (null != sel) && (sel instanceof SecKeyFolder)
            && (sel.getParent() == sel.getRoot());

        if(!isSeckey) return;

        SecretKey key = ((SecKeyFolder)sel).toKey();
        String [] mtext = new String[1];
        String message = "Revoke {0} permanently?";
        mtext[1] = key.getPubkey().toString();

        switch(JOptionPane.showConfirmDialog(
            Angerona.getMainFrame(), java.text.MessageFormat.format(message, mtext),
            "Revocation certificate type",
            JOptionPane.YES_NO_CANCEL_OPTION))
        {
            case JOptionPane.YES_OPTION:
            if(key.unlock())
            {
                key.revoke(true);
            }
            break;
            case JOptionPane.NO_OPTION:
            if(key.unlock())
            {
                key.revoke(false);
            }
            break;
            default:
            break;
        }
    }

    void lock_actionPerformed()
    {
        DefaultMutableTreeNode sel =
            (DefaultMutableTreeNode)tree.getSelectionPath().getLastPathComponent();

        boolean isSeckey = (null != sel) && (sel instanceof SecKeyFolder)
            && (sel.getParent() == sel.getRoot());

        if(!isSeckey) return;
        SecretKey key = ((SecKeyFolder)sel).toKey();
        key.lock();
    }

    private class RevokeAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            SeckeyPanel.this.revoke_actionPerformed();
        }
    }

    private class LockAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            SeckeyPanel.this.lock_actionPerformed();
        }
    }

}

