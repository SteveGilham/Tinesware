package com.ravnaandtines.angerona.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.ravnaandtines.util.image.Logo;
import com.ravnaandtines.Angerona;
import com.ravnaandtines.util.text.Mnemonic;
import com.ravnaandtines.util.gui.LicenceDialog;

/**
*  Class AboutPanel
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class AboutPanel extends JPanel
{
    private BorderLayout borderLayout1 = new BorderLayout();
    private JLabel imageControl1 = new JLabel();
    private JPanel bevelPanel1 = new JPanel();
    private GridLayout gridLayout1 = new GridLayout(8,1);
    private JLabel productLabel;
    private JButton copyrightLabel;
    private JLabel tinesLabel;
    private JLabel ianLabel;
    private JLabel spaceLabel, icon1, icon2, icon3;

    
    public AboutPanel()
    {
        try 
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
    void forceFocus()
    {
        copyrightLabel.requestFocus();
    }

    private void jbInit() throws Exception
    {
        this.setLayout(borderLayout1);

        // Image at left
        ImageIcon imageIcon =
            new ImageIcon(Toolkit.getDefaultToolkit().createImage(new Logo()));
        imageControl1.setIcon(imageIcon);
        imageControl1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e)
            {
                imageControl1_mouseEntered();
            }
            public void mouseExited(java.awt.event.MouseEvent e)
            {
                imageControl1_mouseExited();
            }
        });
        this.add("West", imageControl1);


        // bumf in rest of space
        productLabel =
            new JLabel("Angerona - Free World Freeware - v0.1", SwingConstants.LEFT);
        productLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e)
            {
                productLabel_mouseEntered();
            }
            public void mouseExited(java.awt.event.MouseEvent e)
            {
                productLabel_mouseExited();
            }
        });

        Mnemonic copy = new Mnemonic("&Copyright � 1998");
        copyrightLabel = new JButton(copy.getLabel());
        copyrightLabel.setHorizontalAlignment(JButton.LEFT);
        copyrightLabel.setMnemonic(copy.getMnemonic());
        copyrightLabel.addActionListener(new GPLAction());
        copyrightLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e)
            {
                copyrightLabel_mouseEntered();
            }
            public void mouseExited(java.awt.event.MouseEvent e)
            {
                copyrightLabel_mouseExited();
            }
        });

        tinesLabel = new JLabel("Mr. Tines <tines@windsong.demon.co.uk>", SwingConstants.LEFT);
        ianLabel = new JLabel("& Ian Miller <ian_miller@bifroest.demon.co.uk>", SwingConstants.LEFT);
        spaceLabel = new JLabel("");
        icon1 =
            new JLabel("20x20 icons Copyright � 1998", SwingConstants.LEFT);
        icon2 =
            new JLabel("Dean S. Jones <dean@gallant.com>", SwingConstants.LEFT);
        icon3 =
// www.gallant.com doesn't respond to me.
//            new JLabel("www.gallant.com/icons", SwingConstants.LEFT);
            new JLabel("www.javalobby.org/jfa/projects/icons/index.html", SwingConstants.LEFT);

        bevelPanel1.setLayout(gridLayout1);
        bevelPanel1.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        bevelPanel1.add(productLabel);
        bevelPanel1.add(copyrightLabel);
        bevelPanel1.add(tinesLabel);
        bevelPanel1.add(ianLabel);
        bevelPanel1.add(spaceLabel);
        bevelPanel1.add(icon1);
        bevelPanel1.add(icon2);
        bevelPanel1.add(icon3);
        this.add("Center", bevelPanel1);

        // keyboard enabling
        registerKeyboardAction(new GPLAction(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    void productLabel_mouseEntered()
    {
        Angerona.getMainFrame().setBarText("OpenPGP in Java");
    }

    void productLabel_mouseExited()
    {
        Angerona.getMainFrame().setBarText("");
    }

    void copyrightLabel_mouseEntered()
    {
        Angerona.getMainFrame().setBarText("Copyleft, actually");
    }

    void copyrightLabel_mouseExited()
    {
        Angerona.getMainFrame().setBarText("");
    }

    void imageControl1_mouseEntered()
    {
        Angerona.getMainFrame().setBarText(
            "A Tines pack (art by A. Taylor after V. Vinge)");
    }

    void imageControl1_mouseExited()
    {
        Angerona.getMainFrame().setBarText("");
    }

    private class GPLAction extends AbstractAction
    {
        public void actionPerformed(ActionEvent e)
        {
            LicenceDialog dlg = Angerona.getMainFrame().getLicenceDialog();
            dlg.setTitle("Freeware Licence Conditions");
            Dimension frmSize = Angerona.getMainFrame().getSize();
            Dimension dlgSize = new Dimension(frmSize.width,  (2*frmSize.height)/3);
            dlg.setSize(dlgSize);
            Point loc = Angerona.getMainFrame().getLocation();
            dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
            dlg.setModal(true);
            dlg.setText(com.ravnaandtines.util.Licence.GNU_General_Public_Licence());
            dlg.show();
        }
    }

}

 