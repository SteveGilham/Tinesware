package com.ravnaandtines;

import javax.swing.UIManager;
import javax.swing.plaf.metal.*;
import java.awt.*;
import com.ravnaandtines.angerona.gui.MainFrame;
import com.ravnaandtines.util.swing.LightBlackMetalTheme;
import com.ravnaandtines.util.text.Format;
import java.util.Properties;
import java.io.*;

/**
*  Class Angerona
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class Angerona
{
    /**
    * How to shuffle the main frame layout into place
    */
    boolean packFrame = false;

    /**
    * The unique instance of the application main frame;
    * the singleton pattern is not explicitly enforced
    */
    static MainFrame mainframe = null;

    /**
    * The properties file used to store settings e.g. key ring locations
    */
    static String configFileName = "";

    /**
    * Identification string - who or what exactly <em>is</em> Angerona
    */
    static final String about="Angerona was the Roman numen of secrecy,"
    +" and presumably the custodian of the secret name of Rome."
    +"  She is shown with her mouth bound and sealed, a finger "
    +"to her lips.  Little else is known about her or her cult : "
    +"the secret has been well kept.";

    /**
    * Repository for user settings
    */
    static Properties settings = null;

    /**
    * Construct an instance of the application
    */
    public Angerona()
    {
        MainFrame frame = new MainFrame();
        mainframe = frame;
        //Validate frames that have preset sizes
        //Pack frames that have useful preferred size info, e.g. from their layout
        if (packFrame)
            frame.pack();
        else
            frame.validate();
        //Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        if (frameSize.height > screenSize.height)
            frameSize.height = screenSize.height;
        if (frameSize.width > screenSize.width)
            frameSize.width = screenSize.width;
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);
        frame.forceFocus();
    }

    /**
    * main method of the application
    * @param args String[] tokenised command line (optional 1st argument is config file.
    */
    public static void main(String[] args)
    {
        MetalLookAndFeel.setCurrentTheme(new LightBlackMetalTheme());
        try
        {
            //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
            //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());
            UIManager.setLookAndFeel(new MetalLookAndFeel());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        if(args.length > 0)
        {
            configFileName = args[0];
        }
        System.runFinalizersOnExit(true);
        new Angerona();
    }

    /**
    * Accessor method for the single main frame
    * @return that frame
    */
    public static MainFrame getMainFrame()
    {
        return mainframe;
    }

    /**
    * Accessor method for the identification string
    * @return the tag string
    */
    public static String getAngerona()
    {
        return about;//Format.wrapText(about, 40);
    }
    /**
    * Accessor method for the configuration file name
    * @return the file name
    */
    public static String getConfigFile()
    {
        return configFileName;
    }
    /**
    * Accessor method for the configuration file name
    * @param name the file name
    */
    public static void setConfigFile(String name)
    {
        configFileName = name;
    }

    /**
    * Accessor method for the configuration file contents
    * @return the file name
    */
    public static Properties getSettings()
    {
        return settings;
    }

    /**
    * Loads the configuration file, assuming it exists
    */
    public static void loadConfig()
    {
       try{
           FileInputStream f = new FileInputStream(configFileName);
           Properties p = new Properties();
           p.load(f);
           settings = p;
       }
       catch(Exception e)
       {}
   }
}

