package com.ravnaandtines.openPGP.packet;
import com.ravnaandtines.util.io.*;

/**
*  Class LITPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class LITPacket extends Packet
{
    private int inset = 0;
    private int type = 0;
    private String filename = null;
    private long timestamp = 0;

    /**
    * Packets may only be publicly created through factory methods
    */
    protected LITPacket()
    {
    }
    /**
    * Takes the packet header, and absorbs the data from the stream
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected LITPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r, true);
        type = source.read();  // 't' or 'b'
        int fnl = source.read();   // counted string file name.  UTF8??
        inset = 6+fnl;
        byte[] fn = new byte[fnl];
        int l = source.read(fn, 0, fnl);
        long ts = source.read32();

        if((type != 0x62 && type != 0x74) ||
            (l != fnl) || ts < 0) throw
            new MalformedPacketException("Bad fixed packet body for literal packet");

        char[] fnc = new char[fnl];
        java.io.InputStreamReader is = null;
        java.io.ByteArrayInputStream bis = new java.io.ByteArrayInputStream(fn);
        try {
            is = new  java.io.InputStreamReader(bis, "UTF8");
            } catch ( java.io.UnsupportedEncodingException ex ) {
        }
        if(null == is) is = new  java.io.InputStreamReader(bis);
        l = is.read(fnc);
        filename = new String(fnc, 0, l);
        timestamp = 1000 * ts;
    }

    public boolean isBinary()
    {
        return type == 0x62;
    }
    public String getFilename()
    {
        return filename;
    }
    public long getTimestamp()
    {
        return timestamp;
    }
    // content access to do
}
