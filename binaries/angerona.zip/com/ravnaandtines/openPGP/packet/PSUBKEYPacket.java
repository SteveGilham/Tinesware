package com.ravnaandtines.openPGP.packet;
import com.ravnaandtines.util.io.*;

/**
*  Class PSUBKEYPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class PSUBKEYPacket extends PKEYPacket
{
    /**
    * Packets may only be publicly created through factory methods
    */
    protected PSUBKEYPacket()
    {
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can do
    * anything sane with it
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @exception IOException if an I/O error occurs.
    */
    protected PSUBKEYPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r);
    }

    public String getCommentString()
    {
        return commentString;
    }
}
