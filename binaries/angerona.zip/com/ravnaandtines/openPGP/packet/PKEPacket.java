package com.ravnaandtines.openPGP.packet;

import com.ravnaandtines.util.io.*;
import com.ravnaandtines.crypt.pka.PKCypher;
import java.math.BigInteger;

/**
*  Class PKEPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* Values derived from the OpenPGP internet draft section 5.1
* <p>
* @author Mr. Tines
* @version 1.0 08-Nov-1998
*
*/


public class PKEPacket extends Packet
{
    /**
    * packet structure version
    */
    byte version = 0;
    /**
    * keyID of intended recipient
    */
    long keyID = 0;
    /**
    * algorithm specifier
    */
    byte pka = 0;
    /**
    * cryptographic content of the packet
    */
    BigInteger[] payload = null;


    /**
    * Packets may only be publicly created through factory methods
    */
    protected PKEPacket()
    {
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can do
    * anything sane with it
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected PKEPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        // set the data, but we'll take over the reading
        super(hdr, r, false);

        // starts with the version byte
        int work = source.read();
        if(work < 0) throw new java.io.EOFException();
        // 2 = PGP2.6 and before; 3 = PGP5
        if(work < 2 || work > 3) throw new BadVersionException(work);
        version = (byte) work;

        // next is 8-octet keyID
        long frag = source.read32();
        if(frag < 0) throw new java.io.EOFException();
        keyID = frag << 32;
        frag = source.read32();
        if(frag < 0) throw new java.io.EOFException();
        keyID |= frag;

        // next is one byte Public key algorithm value
        work = source.read();
        if(work < 0) throw new java.io.EOFException();
        pka = (byte) work;

        // now we have read 10 bytes and have some number of
        // MPIs that depend on the public key algorithm.
        int nMPI = PKCypher.pkeMPIs(pka);

        int data = 10;

        if(nMPI < 0) // we don't know what to do, so skip
        {
             skip(source, data);
        }
        else
        {
            payload = new BigInteger[nMPI];
            for(int i = 0; i<nMPI; ++i)
            {
                byte[] mpi = source.readMPI();
                if(mpi == null) throw new java.io.EOFException();
                data += 2+mpi.length;
                payload[i] = new BigInteger(1, mpi);
                mpi = null;
            }
        }

        // consistency check.
        if(data != header.getLength())
            throw new MalformedPacketException("Incorrect explicit packet length");

    }
}