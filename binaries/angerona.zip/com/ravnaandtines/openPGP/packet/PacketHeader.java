package com.ravnaandtines.openPGP.packet;

import com.ravnaandtines.util.io.*;
import java.io.IOException;
import java.io.EOFException;

/**
*  Class PacketHeader
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
*  Implements section 4.2 of the OpenPGP internet draft
* <p>
* @author Mr. Tines
* @version 1.0 08-Nov-1998
*
*/

public class PacketHeader
{
    private int leadByte;
    private long length;
    private byte type;
    private boolean newStyle;
    private long partial;
    private long offset;

    private static String eof = "EOF found while reading packet length";

    /**
    * A packet may not have an explict length or position - if so use this value
    */
    public static final long INDETERMINATE = -1L;

    /**
    * Default constructor
    */
    PacketHeader()
    {
    }

    /**
    * Constructs a packet header from the octet stream argument.
    * Reads the lead byte and the immediately following length data
    * which may not give the whole story (partial length buffers or
    * rest of stream signals, depending on version)
    *
    * @param r Read object that supplies the byte stream
    * @exception IOException if an I/O error occurs.
    */
    PacketHeader (Read r) throws java.io.IOException
    {
        int lowBits = 0;
        int work;

        length = INDETERMINATE;
        partial = INDETERMINATE;
        offset = INDETERMINATE;

        leadByte = r.read();
        if(leadByte < 0) throw new EOFException();
        if((Packet.CTB_DESIGNATOR & leadByte) == 0)
        {
            throw new MalformedPacketException(leadByte);
        }

        // are we speaking PGP2.6 or a much later version??
        newStyle = (0x40 & leadByte) != 0;

        if(!newStyle)
        {
            // default format
            type = (byte)((leadByte>>2) & 0xF);
            lowBits = leadByte & 0x3;

            switch(lowBits)
            {
                case 3: break; // indeterminate
                case 0: // one byte
                {
                    work = r.read();
                    if(work < 0) throw new MalformedPacketException(eof);
                    length = (long)work;
                    break;
                }
                case 1:
                {
                    work = r.read16();
                    if(work < 0) throw new MalformedPacketException(eof);
                    length = (long)work;
                    break;
                }
                case 2:
                {
                    length = r.read32();
                    if(length < 0) throw new MalformedPacketException(eof);
                    break;
                }
            }
        }
        else
        {
            work = r.read();
            if(work < 0) throw new MalformedPacketException(eof);
            else if (work < 192) // One octet length
            {
                length = work;
            }
            else if (work < 224) // Two octet length
            {
                length = 192 + ((work-192)<<8);
                work = r.read();
                if(work < 0) throw new MalformedPacketException(eof);
                length += work;
            }
            else if (work < 255) // partial length
            {
                partial = 1 << (work-223);
                length = INDETERMINATE;
                if(partial < 512)
                {
                    mark(r);
                    throw new
                    MalformedPacketException ("Short partial length "+partial, true);
                }
                if(type != Packet.COMP && type != Packet.LIT &&
                    type != Packet.CKE)
                {
                    mark(r);
                    throw new
                    MalformedPacketException("Partial length with invalid packet type "+type, true);
                }
            }
            else // 5 octet length
            {
                length = r.read32();
                if(length < 0) throw new MalformedPacketException(eof);
            }
        }
        mark(r);
    } // end read constructor

    /**
    * Sets the position to the start of the packet data
    * @param r Read used to get the data
    */
    private void mark(Read r) throws java.io.IOException
    {
        if(r instanceof RandomAccessRead)
        {
            offset = ((RandomAccessRead)r).getFilePointer();
        }
    }


    /**
    * Reveals the type of the packet as read
    * @return byte value of the packet type (0 to 63 possible max)
    */
    byte getType()
    {
        return type;
    }

    /**
    * Reveals the syntaxt of the packet as read
    * @return true if new style packet
    */
    boolean getnewStyle()
    {
        return newStyle;
    }

    /**
    * Returns the current packet length value
    * @return long length value
    */
    long getLength()
    {
        return length;
    }

    /**
    * Returns the current packet partial length value
    * @return long length value
    */
    long getPartialLength()
    {
        return partial;
    }

    /**
    * Sets the length of the buffer
    * @param l byte value to overwrite (if length is indeterminate)
    */
    void setLength(long l)
    {
        if(length == INDETERMINATE)
        {
            length = l;
        }
    }
    /**
    * Returns the current packet offset
    * @return long length value
    */
    long getOffset()
    {
        return offset;
    }
}
