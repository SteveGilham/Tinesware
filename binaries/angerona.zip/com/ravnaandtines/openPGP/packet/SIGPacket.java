package com.ravnaandtines.openPGP.packet;

import com.ravnaandtines.util.io.*;
import com.ravnaandtines.crypt.pka.PKCypher;
import com.ravnaandtines.crypt.mda.Hash;
import java.util.Date;

/**
*  Class SIGPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* Values derived from the OpenPGP internet draft
*  <P>
* @author Mr. Tines
* @version 1.0 11-Nov-1998
*
*/

public class SIGPacket extends Packet
{
    private static final String badPKCypher = "Unknown Public key algorithm";
    private static final String badHash = "Unknown Message digest algorithm";

    // document sigantures
    public static final byte BINARY_DOC = 0x00;
    public static final byte TEXT_DOC = 0x01;

    // packet self-signature
    public static final byte STANDALONE = 0x02;
    public static final byte TIMESTAMP = 0x40;

    // key + user signature
    public static final byte GENERIC = 0x10;
    public static final byte PERSONA = 0x11;
    public static final byte CASUAL = 0x12;
    public static final byte POSITIVE = 0x13;
    public static final byte USERID_REVOKE = 0x30;

    // key signature
    public static final byte SUBKEY_BINDING = 0x18;
    public static final byte DIRECT_KEY = 0x1F;
    public static final byte KEY_REVOKE = 0x20;
    public static final byte SUBKEY_REVOKE = 0x28;

    protected byte version = 0;
    protected byte type = (byte)0xFF;
    protected int  timestamp = 0;
    protected long signerKeyID = 0;
    protected byte pka = 0;
    protected byte mda = 0;
    protected int  hashedLength = 0;
    protected int  unhashedLength = 0;
    protected short leadBytes = 0;
    protected byte[][] nums = null;

    /**
    * Packets may only be publicly created through factory methods
    */
    protected SIGPacket()
    {
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can do
    * anything sane with it
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected SIGPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r, true);
        try {
            readHeader();
        } finally {
            // get to end of packet - we know that the length is determinate
            source.seek(offset + header.getLength());
        }
    }

    private void readHeader() throws java.io.IOException
    {
        // read version info
        source.seek(offset);
        int temp = source.read();
        if(temp < 0)
        {
            throw new MalformedPacketException("Empty signature packet");
        }
        version = (byte)(temp & 0xFF);

        if((version < Packet.MIN_VERSION) || (version > Packet.VERSION_3))
        {
            throw new BadVersionException(version);
        }
        else if(Packet.VERSION_3 != version)
        {
            temp = source.read();
            if(temp != 5) throw new MalformedPacketException
                    ("Incorrect extra data length for version 3 signature packet");

            temp = source.read();
            type = (byte)(temp & 0xFF);

            // read timestamp and possible expiry value
            long tlong = source.read32();
            timestamp = (int)(tlong & 0xFFFFFFFFL);
            tlong = source.read32();
            signerKeyID = (tlong & 0xFFFFFFFFL) << 32;
            tlong = source.read32();
            signerKeyID |= (tlong & 0xFFFFFFFFL);

            temp = source.read();
            pka = (byte)(temp & 0xFF);
            if(!PKCypher.isRecognised(pka))
            {
                throw new MalformedPacketException(badPKCypher);
            }
            temp = source.read();
            mda = (byte)(temp & 0xFF);
            if(!Hash.isAvailable(mda))
            {
                throw new MalformedPacketException(badHash);
            }
        }
        else
        {
            temp = source.read();
            type = (byte)(temp & 0xFF);
            temp = source.read();
            pka = (byte)(temp & 0xFF);
            if(!PKCypher.isRecognised(pka))
            {
                throw new MalformedPacketException(badPKCypher);
            }
            temp = source.read();
            mda = (byte)(temp & 0xFF);
            if(!Hash.isAvailable(mda))
            {
                throw new MalformedPacketException(badHash);
            }

            // actually, I do need to parse some of this
            hashedLength = source.read16();
            source.skipBytes(hashedLength);
            unhashedLength = source.read16();
            source.skipBytes(unhashedLength);
        }

        // lead section of hash
        temp = source.read16();
        leadBytes = (short)(temp&0xFFFF);
    }

    public void load() throws java.io.IOException
    {
        readHeader();
        // which should now move us to the end of a pure public key packet
        // secret key subclass is now positioned to read the rest
        nums = PKCypher.read_mpn_signature(pka, source);
    }

    public long getKeyID()
    {
        return signerKeyID;
    }
    public int getTimestamp()
    {
        return timestamp;
    }
    public void incompleteSignature()
    {
        nums = null;
        System.gc();
    }
    public boolean isComplete()
    {
        return nums != null;
    }
    public byte getMDA()
    {
        return mda;
    }
    public byte getPKA()
    {
        return pka;
    }
    public byte getSigClass()
    {
        return type;
    }
    public byte getVersion()
    {
        return version;
    }

    public void digestExtras(com.ravnaandtines.crypt.mda.MDA context)
    {
        if(Packet.VERSION_3 != version)
        {
            byte[] bucket = new byte[7];
            try {
            source.seek(offset);
            source.read(bucket, 0, 7);
            } catch (java.io.IOException ex) {};
            context.update(bucket, 2, 5);
        }
        else throw new RuntimeException("TODO");
    }

    public byte[][] getSig()
    {
        return nums;
    }

    public byte[] decorate(byte[] digest)
    {
        switch(pka)
        {
            case PKCypher.RSA:
            case PKCypher.RSA_ENCRYPT_ONLY: // technically not allowed
            case PKCypher.RSA_SIGN_ONLY:
            case PKCypher.EBP_RSA:
                byte [] digplus = new byte[digest.length+1];
                System.arraycopy(digest, 0, digplus, 0, digest.length);
                digplus[digest.length] = mda;
                return digplus;
            default:
                return digest;
        }
    }
}
