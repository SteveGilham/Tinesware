package com.ravnaandtines.openPGP.packet;
import com.ravnaandtines.util.io.*;
import java.io.*;

/**
*  Class UIDPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 17-Nov-1998
*
*/


public class UIDPacket extends Packet
{
    private String name = null;

    /**
    * Packets may only be publicly created through factory methods
    */
    protected UIDPacket()
    {
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can do
    * anything sane with it
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @exception IOException if an I/O error occurs.
    */
    protected UIDPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r, true);
    }

    /**
    * returns the UTF8 encoded contents as a String, using
    * lazy evaluation.
    */
    public String toString()
    {
        // return if already present
        if(name != null) return name;

        // get from source if required
        try {
            if(lazy) load();
        } catch (java.io.IOException ex) {return null;}

        // interpret from local buffer
        WormBuffer w = (WormBuffer) source; // by construction
        Reader utfReader = w.getReader("UTF8");
        char[] bucket = new char[(int) w.length()];
        int l = 0;
        try {
            l = utfReader.read(bucket);
        } catch (java.io.IOException e) {} // bad encoding??
        name = new String(bucket, 0, l);
        bucket = null;
        return name;
    }

    public byte[] toByteArray()
    {
        return ((WormBuffer)source).toByteArray();
    }
}
