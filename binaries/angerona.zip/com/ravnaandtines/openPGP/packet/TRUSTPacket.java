package com.ravnaandtines.openPGP.packet;
import com.ravnaandtines.util.io.*;

/**
*  Class TRUSTPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class TRUSTPacket extends Packet
{
    private byte value = 0;

    /**
    * trust bits for key owner (when following key packet)
    */
    public static final int KEY_OWNERTRUST_MASK = 0x7;
    /**
    * undefined/uninitialised
    */
    public static final int KEY_OWNERTRUST_UNDEF = 0;
    /**
    * unknown - we don't know the owner of the key
    */
    public static final int KEY_OWNERTRUST_UNKNOWN = 1;
    /**
    * untrusted - we don't usually trust the owner of the key
    */
    public static final int KEY_OWNERTRUST_UNTRUSTED = 2;
    /**
    * trusted - we  usually trust the owner of the key
    */
    public static final int KEY_OWNERTRUST_TRUSTED = 5;
    /**
    * infallible - we always trust the owner of the key
    */
    public static final int KEY_OWNERTRUST_INFALLIBLE = 6;
    /**
    * ultimate - we are the owner of the key (it's on the secret ring)
    */
    public static final int KEY_OWNERTRUST_ULTIMTE = 7;
    /**
    * this key has been disabled
    */
    public static final int KEY_DISABLED = (1<<5);
    /**
    * this key is on the keyring
    */
    public static final int KEY_BUCKSTOP = (1<<7);

    /**
    * trust bits for preceding user ID packet
    */
    public static final int KEY_LEGIT_MASK = 0x3;
    /**
    * unknown - undefined or uninitialised
    */
    public static final int KEY_LEGIT_UNKNOWN = 0;
    /**
    * untrusted - owndership not trusted
    */
    public static final int KEY_LEGIT_UNTRUSTED = 1;
    /**
    * marginal - not for certification, possible for signatures
    */
    public static final int KEY_LEGIT_MARGINAL = 2;
    /**
    * trusted - ultimate or with enough introducer weight
    */
    public static final int KEY_LEGIT_TRUSTED = 3;
    /**
    * warning bit
    */
    public static final int KEY_LEGIT_WARN = (1<<7);

    /**
    * trust bits for preceding signature packet
    */
    public static final int SIGTRUST_MASK = 0x7;
    /**
    * undefined or uninitialised
    */
    public static final int SIGTRUST_UNDEFINED = 0;
    /**
    * unknown
    */
    public static final int SIGTRUST_UNKNOWN = 1;
    /**
    * untrusted
    */
    public static final int SIGTRUST_UNTRUSTED = 2;
    /**
    * trusted (usually)
    */
    public static final int SIGTRUST_TRUSTED = 5;
    /**
    * infallible (complete trust)
    */
    public static final int SIGTRUST_INFALLIBLE = 6;
    /**
    * ultimate - we signed it
    */
    public static final int SIGTRUST_ULTIMATE = 7;
    /**
    * checked
    */
    public static final int SIGTRUST_CHECKED = (1<<6);
    /**
    * has contiguous certification chain to an ultimate signature
    */
    public static final int SIGTRUST_CONTIGUOUS = (1<<7);



    /**
    * Packets may only be publicly created through factory methods
    */
    protected TRUSTPacket()
    {
    }
    /**
    * Takes the packet header, absorbs the data from the stream
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected TRUSTPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r, false);
        if(hdr.getLength() == 0) throw
            new MalformedPacketException("Empty trust packet");

        read(r);
        value = (byte)source.read();
        source = null; // done its thing

        if(hdr.getLength() != 1) throw
            new MalformedPacketException("Trust packet length > 1 byte");
    }

    /**
    * @return the trust byte value from the packet
    */
    public byte getTrust()
    {
        return value;
    }
    /**
    * @param the trust byte value to set into the packet
    */
    public void setTrust(byte trust)
    {
        value = (byte) (trust&0xFF);
    }
}
