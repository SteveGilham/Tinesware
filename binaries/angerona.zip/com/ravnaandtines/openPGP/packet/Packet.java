package com.ravnaandtines.openPGP.packet;

import com.ravnaandtines.util.io.*;

/**
*  Class Packet
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* Values derived from section 4.3 of the OpenPGP internet draft
* <p>
* Currently this and related classes are intolerant of partial length packet
* headers in non-data packets.  We could work around this, but since this is
* <UL><LI>not conformant and <LI>PGP5 doesn't generate these packets, it's not
* yet worth the effort</UL>
* <p>
* @author Mr. Tines
* @version 1.0 08-Nov-1998
*
*/

public class Packet
{
    /**
    * Indicates a packet
    */
    public static final int CTB_DESIGNATOR = 0x80;

    /**
    * A packet may not have this tag value
    */
    public static final int RESERVED = 0;

    /**
    * Public key encrypted session key packet
    */
    public static final int PKE = 1;

    /**
    * Signature packet
    */
    public static final int SIG = 2;

    /**
    * Symmetric key encrypted session key packet
    */
    public static final int SKE = 3;

    /**
    * One pass signature packet
    */
    public static final int OPS = 4;

    /**
    * Secret key packet
    */
    public static final int SKEY = 5;

    /**
    * Public key packet
    */
    public static final int PKEY = 6;

    /**
    * Secret subkey packet
    */
    public static final int SSUBKEY = 7;

    /**
    * Compressed packet
    */
    public static final int COMP = 8;

    /**
    * Conventional key encrypted data packet
    */
    public static final int CKE = 9;

    /**
    * Marker packet
    */
    public static final int PGP = 10;

    /**
    * Literal data packet
    */
    public static final int LIT = 11;

    /**
    * Trust packet
    */
    public static final int TRUST = 12;

    /**
    * UID packet
    */
    public static final int UID = 13;

    /**
    * Public subkey packet
    */
    public static final int PSUBKEY = 14;

    /**
    * Pre-PGP3 comment packet - overloads with PSUBKEY
    */
    public static final int COMMENT = 14;

    /**
    * Private/experimental packet
    */
    public static final int EXP1 = 60;

    /**
    * Private/experimental packet
    */
    public static final int EXP2 = 61;

    /**
    * Private/experimental packet
    */
    public static final int EXP3 = 62;

    /**
    * Private/experimental packet
    */
    public static final int EXP4 = 63;

    /**
    * PGP2 to 2.5 - Note that there is not global Maximum version; this may vary from packet type to packet type
    * according to what has been implemented
    */
    public static final int MIN_VERSION = 2;
    /**
    * PGP2.6
    */
    public static final int VERSION_2_6 = 3;
    /**
    * PGP3 to 5
    */
    public static final int VERSION_3 = 4;
    /**
    * What we issue by default
    */
    public static final int DEFAULT_VERSION = 3;

    /**
    * Packet header data (type/length)
    */
    protected PacketHeader header = null;

    /**
    * Have we left the packet body to be read (old style
    * indeterminate length packets only);
    */
    boolean unread = false;

    /**
    * Have we left the packet body to be read (old style
    * indeterminate length packets only);
    */
    boolean lazy = false;

    /**
    * Save the source with the packet
    */
    RandomAccessRead source = null;
    /**
    * Store the offset into this that we start (just after packet header)
    */
    long offset = PacketHeader.INDETERMINATE;

    /**
    * Packets may only be publicly created through factory methods
    */
    protected Packet()
    {
    }

    /**
    * Factory method for reading a packet.
    * If the input is a RandomAccessRead, creation will be lazy
    * for large packets (data and public key); or defaulted packets
    * @param r Read source of packet data
    */
    public static Packet getInstance(Read r) throws java.io.IOException
    {
        PacketHeader temp;

        // this will throw EOF exception only if the first byte fails to read
        // In that case return null to signal end of file; as opposed to
        // having to catch somthing we expect to hit as a termination condition
        try {
            temp = new PacketHeader(r);
        }
        catch (java.io.EOFException eof)
        {
            return null;
        }
        // let other exceptions pass through for signalling by caller classes

        switch(temp.getType())
        {
            case PKE:
                return new PKEPacket(temp, r);
            case SIG:
                return new SIGPacket(temp, r);
            case SKE:
                return new SKEPacket(temp, r);
            case OPS:
                return new OPSPacket(temp, r);
            case SKEY:
                return new SKEYPacket(temp, r);
            case PKEY:
                return new PKEYPacket(temp, r);
            case SSUBKEY:
                return new SSUBKEYPacket(temp, r);
            case COMP:
                return new COMPPacket(temp, r);
            case CKE:
                return new CKEPacket(temp, r);
            case PGP:
                return new PGPPacket(temp, r);
            case LIT:
                return new LITPacket(temp, r);
            case TRUST:
                return new TRUSTPacket(temp, r);
            case UID:
                return new UIDPacket(temp, r);
            case PSUBKEY: // also COMMENT
                return new PSUBKEYPacket(temp, r);

            // Unspecified packet contents and default
            case RESERVED:
            case EXP1:
            case EXP2:
            case EXP3:
            case EXP4:
            default:
                return new Packet(temp, r, true);
        }
    }

    /**
    * Factory method for creating a packet.
    * @param int Type of packet to create
    */
    public static Packet getInstance(int type)
    {
        switch(type)
        {
            case PKE:
                return new PKEPacket();
            case SIG:
                return new SIGPacket();
            case SKE:
                return new SKEPacket();
            case OPS:
                return new OPSPacket();
            case SKEY:
                return new SKEYPacket();
            case PKEY:
                return new PKEYPacket();
            case SSUBKEY:
                return new SSUBKEYPacket();
            case COMP:
                return new COMPPacket();
            case CKE:
                return new CKEPacket();
            case PGP:
                return new PGPPacket();
            case LIT:
                return new LITPacket();
            case TRUST:
                return new TRUSTPacket();
            case UID:
                return new UIDPacket();
            case PSUBKEY: // also COMMENT
                return new PSUBKEYPacket();

            // Unspecified packet contents and default
            case RESERVED:
            case EXP1:
            case EXP2:
            case EXP3:
            case EXP4:
            default:
                return null;
        }
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can go
    * back and re-read at our leisure
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected Packet(PacketHeader hdr, Read r, boolean doRead) throws java.io.IOException
    {
        header = hdr;
        if(!doRead) return;

        if(r instanceof RandomAccessRead)
        {
            lazy = true;
            lazyRead((RandomAccessRead)r); // just skip over this packet
            source = (RandomAccessRead)r;
        }
        else
        {
            read(r); // bring packet body into the data array
        }
    }

    /**
    * Loads the packet body, if necessary.
    * @exception IOException if an I/O error occurs.
    */
    public void load() throws java.io.IOException
    {
        if(lazy)
        {
            // get to start of packet body
            if(!unread) source.seek(header.getOffset());
            Read s = source;
            read(s);
            lazy = false;
        }
    }


    /**
    * Skips the packet body, reading bytes until length is past
    * if necessary.
    * @param r stream to continue to read packet body from
    * @exception IOException if an I/O error occurs.
    */
    protected void lazyRead(RandomAccessRead r) throws java.io.IOException
    {
        offset = header.getOffset();
        int chunk = 1<<30;
        long l = header.getLength();
        if(l != PacketHeader.INDETERMINATE)
        {
            // known length - just skip past what we know
            // or until exception takes us away
            while(l > 0)
            {
                if(l < chunk) chunk = (int)l;
                l -= chunk;
                r.skipBytes(chunk);
            }
        }
        else if((l = header.getPartialLength()) != PacketHeader.INDETERMINATE)
        {
            // new style partial-length packet, we can go forward
            // in chunks.
            boolean partial = true;
            for(;;)
            {
                // skip this partial
                while(l > 0)
                {
                    if(l < chunk) chunk = (int)l;
                    l -= chunk;
                    r.skipBytes(chunk);
                }
                if(!partial) break;
                // read next chunk
                int work = r.read();
                if(work < 0) throw new java.io.EOFException();
                else if (work < 192) // One octet length
                {
                    l = work;
                    partial = false;
                }
                else if (work < 224) // Two octet length
                {
                    l = 192 + ((work-192)<<8);
                    work = r.read();
                    if(work < 0) throw new java.io.EOFException();
                    l += work;
                    partial = false;
                }
                else if (work < 255) // partial length
                {
                    l = 1 << (work-223);
                    partial = true;
                }
                else // 5 octet length
                {
                    l = r.read32();
                    if(l < 0) throw new java.io.EOFException();
                    partial = false;
                }
            }
        }
        else
        {
            // otherwise, old-style indeterminate packet => rest of stream
            unread = true;
        }
    }

    /**
    * Reads the packet body, storing it into a local buffer if appropriate
    * @param r stream to continue to read packet body from
    * @exception IOException if an I/O error occurs.
    */
    protected void read(Read r) throws java.io.IOException
    {
        lazy = false;
        int chunk = 1<<16;
        long l = header.getLength();
        byte[] bucket = new byte[chunk];
        WormBuffer store = new WormBuffer();
        if(l != PacketHeader.INDETERMINATE)
        {
            // known length - just skip past what we know
            // or until exception takes us away
            while(l > 0)
            {
                if(l < chunk) chunk = (int)l;
                l -= chunk;
                int quantum = r.read(bucket, 0, chunk);
                if(quantum != chunk) throw new java.io.IOException();
                store.write(bucket, 0, chunk);
            }
            source = store;
            offset = 0;
        }
        else if((l = header.getPartialLength()) != PacketHeader.INDETERMINATE)
        {
            // new style partial-length packet, we can go forward
            // in chunks.
            boolean partial = true;
            for(;;)
            {
                // read this partial
                while(l > 0)
                {
                    if(l < chunk) chunk = (int)l;
                    l -= chunk;
                    int quantum = r.read(bucket, 0, chunk);
                    if(quantum != chunk) throw new java.io.IOException();
                    store.write(bucket, 0, chunk);
                }
                if(!partial) break;
                // read next chunk
                int work = r.read();
                if(work < 0) throw new java.io.EOFException();
                else if (work < 192) // One octet length
                {
                    l = work;
                    partial = false;
                }
                else if (work < 224) // Two octet length
                {
                    l = 192 + ((work-192)<<8);
                    work = r.read();
                    if(work < 0) throw new java.io.EOFException();
                    l += work;
                    partial = false;
                }
                else if (work < 255) // partial length
                {
                    l = 1 << (work-223);
                    partial = true;
                }
                else // 5 octet length
                {
                    l = r.read32();
                    if(l < 0) throw new java.io.EOFException();
                    partial = false;
                }
            }
            source = store;
            offset = 0;
        }
        else
        {
            // otherwise, old-style indeterminate packet => rest of stream
            // this is a de facto lazy-read option by doing nothing
            unread = true;
            offset = header.getOffset();
        }
    }

    /**
    * Skips the trailing part of packet body, reading bytes until length is past
    * if necessary.
    * @param r stream to continue to read packet body from
    * @param n bytes already read from the packet
    * @exception IOException if an I/O error occurs.
    */
    protected void skip(Read r, int n) throws java.io.IOException
    {
        int chunk = 1<<30;
        long l = header.getLength();
        // this is lazy, but we're faced with a non-compliant
        // packet if we're in this position
        if(l == PacketHeader.INDETERMINATE)
            throw new MalformedPacketException("Ihis indeterminate length non-data packet cannot be handled", false);
        l -= n;
        if(l < 0)
            throw new MalformedPacketException("Packet length shorter than specified", false);
        // known length - just skip past what we know
        // or until exception takes us away
        while(l > 0)
        {
            if(l < chunk) chunk = (int)l;
            l -= chunk;
            r.skipBytes(chunk);
        }
    }

    /**
    * Returns the packet type info from the packet header.
    * @return integer type value.
    */
    public int getType()
    {
        return header.getType();
    }

    /**
    * Returns the packet offset info from the packet header.
    * @return long offset.
    */
    public long getOffset()
    {
        return header.getOffset();
    }
}