package com.ravnaandtines.openPGP.packet;
import java.io.*;
import com.ravnaandtines.crypt.pka.PKCypher;
import com.ravnaandtines.crypt.mda.*;
import com.ravnaandtines.util.io.*;


/**
*  Class PKEYPacket
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class PKEYPacket extends Packet implements KeySummary
{
    private static final String hex = "0123456789ABCDEF";
    private static final String badPKCypher = "Unknown Public key algorithm";

    protected byte version = 0;
    protected boolean comment = false;
    protected byte pka = 0;
    protected int size = 0;
    protected long keyID = 0;
    protected int timestamp = 0;
    protected short validity = 0;
    protected byte[][] nums = null;
    protected String commentString = null;
    protected String keyprint = "not yet computed";
    protected boolean expired = false;

    /**
    * Packets may only be publicly created through factory methods
    */
    protected PKEYPacket()
    {
    }
    /**
    * Takes the packet header, and either absorbs or skips
    * the data from the stream, depending on whether we can do
    * anything sane with it
    * @param hdr PacketHeader just read from the stream
    * @param r stream to continue to read packet body from
    * @param doRead whether to do the read operation
    * @exception IOException if an I/O error occurs.
    */
    protected PKEYPacket(PacketHeader hdr, Read r) throws java.io.IOException
    {
        super(hdr, r, true);

        try {
            readHeader();
            PKCypher.read_mpn_summary(pka, this, source);
        } finally {
            // get to end of packet - we know that the length is determinate
            source.seek(offset + header.getLength());
        }
    }

    private void readHeader() throws java.io.IOException
    {
        // read key summary info
        source.seek(offset);
        int temp = source.read();
        if(temp < 0) throw new MalformedPacketException("Empty public key packet");
        version = (byte)(temp & 0xFF);

        // allow for overloaded packet type
        comment = header.getType() == Packet.PSUBKEY && version != Packet.VERSION_3;
        if(comment)
        {
            source.seek(offset);
            byte[] stuff = new byte[(int)header.getLength()];
            source.read(stuff, 0, stuff.length);
            Reader utfReader = new InputStreamReader(
                new ByteArrayInputStream(stuff), "UTF8");
            char[] bucket = new char[(int) stuff.length];
            int l = 0;
            try {
                l = utfReader.read(bucket);
            } catch (java.io.IOException e) {} // bad encoding??
            commentString = new String(bucket, 0, l);
            bucket = null;
            source = null;
            stuff = null;
            return;
        }
        if(version < Packet.MIN_VERSION || version > Packet.VERSION_3)
        {
            source.seek(offset + header.getLength());
            throw new BadVersionException(version);
        }

        // read timestamp and possible expiry value
        long tlong = source.read32();
        timestamp = (int)(tlong &0xFFFFFFFF);

        if(version < Packet.VERSION_3)
        {
            temp = source.read16();
            validity = (short)(temp & 0xFFFF);
        }

        if(validity != 0)
        {
            long issueDate = timestamp * 1000L;
            long deltaT = validity * 86400L * 1000L;
            expired = System.currentTimeMillis() >
                issueDate + deltaT;
        }

        // read algorithm
        temp = source.read();
        pka = (byte)(temp & 0xFF);
        if(!PKCypher.isRecognised(pka))
        {
            source.seek(offset + header.getLength());
            throw new MalformedPacketException(badPKCypher);
        }
    }

    public boolean isExpired() {return expired;}

    public void setKeyID(byte[] b)
    {
        keyID = 0;

        // null => fill this in later
        if(null == b) return;

        // pack the lowest bytes of the array into the long
        for(int i = b.length-1; i>=0 && i>= b.length-8; --i)
        {
            int k = b.length - (i+1);
            //long l = (b[i]&0xFFL) << (8*k);
            //System.out.println(com.ravnaandtines.util.text.Hexprint.fmt(l));
            keyID |= (b[i]&0xFFL) << (8*k);
        }
    }
    public void setSize(int l)
    {
        size = l;
    }
    public byte getVersion()
    {
        return version;
    }
    public long getKeyID()
    {
        return keyID;
    }
    public int getSize()
    {
        return size;
    }
    public int getTimestamp()
    {
        return timestamp;
    }
    public byte getPka()
    {
        return pka;
    }
    public boolean isComment()
    {
        return comment;
    }
    private void format(byte[] buffer)
    {
        StringBuffer work = new StringBuffer(3*buffer.length);
        for(int i=0; i<buffer.length; ++i)
        {
            work.append(hex.charAt( (buffer[i]>>4)&0xF) );
            work.append(hex.charAt(  buffer[i]&0xF) );
            work.append(" ");
            if((i%8)==7) work.append(" ");
        }
        keyprint = work.toString().trim();
    }

    public String getKeyprint()
    {
        return keyprint;
    }

    public void load() throws java.io.IOException
    {
        readHeader();
        // which should now move us to the end of a pure public key packet
        // secret key subclass is now positioned to read the rest
        nums = PKCypher.read_mpn_pubkey(pka, source);
        size = PKCypher.sizePubkey(pka, nums);
        extractKeyfrag();
    }

    private void extractKeyfrag()
    {
        switch (pka)
        {
            case PKCypher.RSA:
            case PKCypher.RSA_ENCRYPT_ONLY:
            case PKCypher.RSA_SIGN_ONLY:
            case PKCypher.GF2255:
            if(version < Packet.VERSION_3)
            {
		        int sig = PKCypher.pkeCharacteristicMPI(pka);
                setKeyID(nums[sig]);
                getFingerprint();
                break;
            }
            // drop through for non2.6 style algorithms
            default:
	          {
                // Currently hard-wired as per OpenPGP
                try {
                  MDA sha = Hash.getInstance(Hash.PGP5_SHA1);

		              byte[] hash = null;

		              if(keyHashUpdate(sha))
		              {
			              hash = sha.digest();
                          setKeyID(hash);
                          format(hash);
		              }
                } catch (Exception e) {}
	          }
        } // swend
    }

    // PGP2.6 fingerprint - MD5 over the key content only
    private void getFingerprint()
    {
        MDA md5 = Hash.getInstance(Hash.MD5);

        /*
           isn't this a lot better than:- 

        java.security.MessageDigest md5 = null;
        try {
           md5 = java.security.MessageDigest.getInstance("MD5");
        } catch (Exception e) {return;}*/

        for(int offset = 0; offset < nums.length; ++offset)
        {
            md5.update(nums[offset], 0, nums[offset].length);
        }
        byte[] buffer = md5.digest();
        format(buffer);
     }


    /* PGP 5.0 fingerprint equivalent */
    public boolean keyHashUpdate(MDA context)
    {
	    int bufferSize	= formatKeySize();
	    byte[] buffer = new byte[bufferSize];

	    if(buffer == null) return false;
	    buffer[0] = (byte)(Packet.CTB_DESIGNATOR + 4 * Packet.PKEY + 1);
	    buffer[1] = (byte)((bufferSize / 256) &0xFF);
	    buffer[2] = (byte)(bufferSize % 256);
	    context.update(buffer, 0, 3);
	    formatPubkey(buffer);
	    context.update(buffer, 0, buffer.length);
	    buffer = null;
	    return true;
    }

    int length_pubkey()
    {
	    int Nnums = nums.length;
	    int offset = -1;
	    int result = 0;

	    if(Nnums >= 0)
	    {
		    while(++offset < Nnums)
			    result += (nums[offset].length + 2);
        }
        return result;
    }

    int	formatKeySize()
    {
	    return
			(1 +
			4 + //SIZEOF_TIMESTAMP +
			((version < Packet.VERSION_3) ? 2/*SIZEOF_VALIDITY*/ : 0) +
			1 +
			length_pubkey());
    }

    void put_pubkey(byte[] buffer, int offset)
    {
	    int Nnums = nums.length;
	    int n = -1;
	    if(Nnums >= 0)
	    {
		    while(++n < Nnums)
            {
                int l = PKCypher.length_mpn(nums[n]);
                buffer[offset++] = (byte)((l / 256) &0xFF);
                buffer[offset++] = (byte)((l % 256) &0xFF);
                System.arraycopy(nums[n], 0, buffer, offset, nums[n].length);
                offset += nums[n].length;
            }
        }
    }
    void	formatPubkey(byte[] buffer)
    {
        int offset = 0;
	    buffer[offset++] = version;
        buffer[offset++] = (byte)((timestamp>>24) & 0xFF);
        buffer[offset++] = (byte)((timestamp>>16) & 0xFF);
        buffer[offset++] = (byte)((timestamp>> 8) & 0xFF);
        buffer[offset++] = (byte)((timestamp) & 0xFF);

	    if(version < Packet.VERSION_3)
	    {
            buffer[offset++] = (byte)((validity>> 8) & 0xFF);
            buffer[offset++] = (byte)((validity) & 0xFF);
	    }

	    buffer[offset++] = pka;

        put_pubkey(buffer, offset);
    }

    public void incompleteKey()
    {
        nums = null;
        System.gc();
    }
    public boolean isComplete()
    {
        return nums != null;
    }
    public byte[][] getKey()
    {
        return nums;
    }
    public byte getPKA()
    {
        return pka;
    }
}
