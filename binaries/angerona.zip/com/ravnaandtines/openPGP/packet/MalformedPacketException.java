package com.ravnaandtines.openPGP.packet;

import java.io.*;
/**
*  Class MalformedPacketException
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* Packet leading byte has the high bit unset
* <p>
* @author Mr. Tines
* @version 1.0 11-Nov-1998
*
*/


public class MalformedPacketException extends IOException
{
    /**
    * Exception is a warning if this value is true
    */
    private boolean advisory = false;

    /**
    * Default constructor is bad lead byte failure
    */
    public MalformedPacketException()
    {
        super("Packet lead byte high bit is not set");
    }

    /**
    * Bad lead byte failure with value given
    * @param i lead byte value
    */
    public MalformedPacketException(int i)
    {
        super("Packet lead byte value "+Integer.toHexString(i));
    }

    /**
    * Other failure with specific message (recoverable)
    * @param s Warning message
    */
    public MalformedPacketException(String s)
    {
        super(s);
        advisory = false;
    }

    /**
    * Other failure with specific message (recoverable)
    * @param s Warning message
    * @param warn set whether this is advisory
    */
    public MalformedPacketException(String s, boolean warn)
    {
        super(s);
        advisory = warn;
    }

    /**
    * Signals whether this exception is a warning or an error
    * @return true if this exception is a warning only.
    */
    public boolean isAdvisory()
    {
        return advisory;
    }
} 