package com.ravnaandtines.openPGP.keyring;
import com.ravnaandtines.openPGP.packet.SIGPacket;
import java.util.Date;
import com.ravnaandtines.crypt.pka.MPI;

/**
*  Class Signature
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class Signature extends Trusted
{
	public static final int SS_BAD		= -2;	/* Signature does not match (confirmed this run) */
	public static final int SS_SUSPECT	= -1;	/* Signature does not match (according to file)  */
	public static final int SS_UNKNOWN	=  0;   /* Signature has not been checked */
	public static final int SS_PROBABLE	=  1;	/* Signature matchs (according of file) */
	public static final int SS_VERIFIED	=  2;/* Verified this program run */

	public static final int SIG_OKAY = 0;
	public static final int SIG_NO_KEY = 1;		/* No public key to check signature with */
	public static final int SIG_ERROR = 2;		/* checking process failed (e.g. no memory) */
	public static final int SIG_BAD = 3;		/* The signature is WRONG */

    private SIGPacket content = null;
    private Signature next = null;
    private PublicKey from = null;
//	pubkey 	*	from;		/* key that made this signature */
//	sigDetails*	details; /* Normally NULL; only set if NOT on disc */

	int 		sigStat = SS_UNKNOWN;
//	long		fileOffset;
//	byte	 	trust;

    public Signature(SIGPacket content)
    {
        this.content = content;
    }

    private void setStat(int status)
    {
        sigStat = status;
    }

    public int getStat()
    {
        return sigStat;
    }

    public void setSigner(PublicKey signing_key)
    {
        from = signing_key;
    }

    public PublicKey toKey()
    {
        return from;
    }

    public String getName()
    {
        return null;
    }
    public Signature nextSignature()
    {
        return next;
    }
    public void append(Signature s)
    {
        Signature x = this;
        while(x.next != null) x=x.next;
        x.next = s;
    }
    public Date getDate()
    {
        long t = ((long)content.getTimestamp())&0x00000000FFFFFFFFL;
        Date date = new Date(1000L*t);
        return date;
    }
    public boolean completeSignature()
    {
        if( content != null && content.isComplete()) return true;
        try{ content.load(); }
        catch(java.io.IOException ex) {return false;}
        return true;
    }
    public void incompleteSignature()    {
        content.incompleteSignature();
    }
    public byte getMDA()
    {
        return content.getMDA();
    }
    public byte getPKA()
    {
        return content.getPKA();
    }
    public byte getSigClass()
    {
        return content.getSigClass();
    }
    public byte getVersion()
    {
        return content.getVersion();
    }
    public int verify(byte[] digest)
    {
        byte[][] nums = content.getSig();

        MPI[] sign = new MPI[nums.length];
        for(int i=0; i<nums.length; ++i)
        {
            sign[i] = new MPI();
            sign[i].num = nums[i];
        }

        // may need to decorate the message digest - like for RSA
        // actually all we do here is append the mda value for RSA
        digest = content.decorate(digest);

        boolean ok = from.verify(sign, digest);

        if(ok)
        {
            setStat(SS_VERIFIED);
            return SIG_OKAY;
        }
        else
        {
            setStat(SS_BAD);
            return SIG_BAD;
        }
    }
    public void digestExtras(com.ravnaandtines.crypt.mda.MDA context)
    {
        content.digestExtras(context);
    }
}
