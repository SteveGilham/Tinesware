package com.ravnaandtines.openPGP.keyring;

import java.util.*;


/**
*  Class KeytableEnumeration
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class KeytableEnumeration implements Enumeration
{
    private Enumeration main = null;
    private Enumeration sub = null;

    KeytableEnumeration(Enumeration e)
    {
        main = e;
    }

    public boolean hasMoreElements()
    {
        if(sub != null)
        {
            if(sub.hasMoreElements()) return true;
            sub = null;
        }
        return main.hasMoreElements();
    }

    public Object nextElement()
    {
        do{
            Object o = next();
            PublicKey p = (PublicKey)o;
            if(p.getStatus() != PublicKey.KS_MISSING) return o;
        } while(hasMoreElements());
        return null;
    }

    private Object next()
    {
        if(sub != null) return sub.nextElement();
        Object o = main.nextElement();
        if(o instanceof Vector)
        {
            sub = ((Vector)o).elements();
            return sub.nextElement(); // assumes not empty by construction
        }
        sub = null;
        return o;
    }
}