package com.ravnaandtines.openPGP.keyring;
import com.ravnaandtines.openPGP.packet.UIDPacket;

/**
*  Class UserID
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class UserID extends Trusted
{
    private Signature sig = null;
    private UserID next = null;
    private UIDPacket raw = null;

    public UserID()
    {
    }
    
    public UserID(PublicKey pub_key, UserID previous, UIDPacket where)
    {
		/* add to end of list of names to maintain order */
		if(previous != null)
			previous.next = this;
		else
			pub_key.setName(this); /* first in chain */
        raw = where;
        setTrust(Trusted.MAX_DEPTH);
	}

    public String getName()
    {
        if(raw == null)
        {
            return "";
        }
        return raw.toString();
    }

    public byte[] toByteArray()
    {
        if(raw == null)
        {
            return null;
        }
        return raw.toByteArray();
    }


    public UserID nextUsername()
    {
        return next;
    }
    public Signature getSignature()
    {
        return sig;
    }
    public void sign(SecretKey signer, PublicKey binder)
    {
    }

    public void addSignature(Signature s)
    {
        s.append(sig);
        sig = s;
    }
} 