package com.ravnaandtines.openPGP.keyring;
import com.ravnaandtines.openPGP.packet.SKEYPacket;
import com.ravnaandtines.openPGP.packet.SSUBKEYPacket;

/**
*  Class SecretKey
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class SecretKey extends PublicKey
{
    private SecretKey mainkey = null;
    private SecretKey subkey = null;
    private SKEYPacket load = null;
    private SSUBKEYPacket subload = null;

    public SecretKey()
    {
    }
    public SecretKey(SKEYPacket p)
    {
        super(p, true);
        // read secret key elements
    }
    public boolean unlock()
    {
        return false;
    }
    public PublicKey getPubkey()
    {
        return (PublicKey)this;
    }
    public void revoke(boolean permanently)
    {
    }
    public void lock()
    {
    }
    public boolean isLocked()
    {
        return true;
    }
}
