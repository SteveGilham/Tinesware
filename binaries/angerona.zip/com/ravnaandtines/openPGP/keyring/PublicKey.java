package com.ravnaandtines.openPGP.keyring;

import java.util.Date;
import java.text.*;
import com.ravnaandtines.openPGP.packet.Packet;
import com.ravnaandtines.openPGP.packet.SIGPacket;
import com.ravnaandtines.openPGP.packet.PKEYPacket;
import com.ravnaandtines.openPGP.packet.PSUBKEYPacket;
import com.ravnaandtines.openPGP.packet.TRUSTPacket;
import com.ravnaandtines.util.text.Hexprint;
import com.ravnaandtines.util.event.StatusEvent;
import com.ravnaandtines.crypt.pka.PKCypher;
import com.ravnaandtines.crypt.pka.MPI;
import com.ravnaandtines.crypt.pka.Key;
import com.ravnaandtines.crypt.pka.PKA;

/**
*  Class PublicKey
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class PublicKey extends Trusted
{
    private PublicKey subkey = null; //chain
    private PublicKey superkey = null; //root
    private PKEYPacket load = null; // may be a PSUBKEYPacket
    private Keyring ring = null;
    long keyID = 0;

    private Signature direct = null;
    private UserID name = null;

    private int status;

    static final int KS_MISSING = 0;
    static final int KS_INCOMPLETE = 1;
    static final int KS_COMPLETE = 2;


    public PublicKey()
    {
        status = KS_MISSING;
    }

    public PublicKey(long id)
    {
        super();
        keyID = id;
    }

    public PublicKey(PKEYPacket p, boolean loadNow)
    {
        super();
        load = p;
        status = KS_INCOMPLETE;

        // TODO: load and compute Version 2.6 keyprint here
        if(loadNow || load.getVersion() > PKEYPacket.VERSION_2_6)
		{
            // It is not in the key-ring or it is a version3 packet; in either case
            // we must read it in its entirety now
            try {
                p.load();
                } catch (java.io.IOException ex) {
                // not a lot we can do
            }

            if(loadNow)
            {
                String[] hex = {"0x"+com.ravnaandtines.util.text.Hexprint.fmt(p.getKeyID())};
                Keyring.ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.STATUS,
                        MessageFormat.format(
                        "Public key packet found : \"(0)\"",
                        hex)));
            }
            else
            {
                //if we were reading it only to obtain the keyId. because its is
                //a VERSION_3 packet we may now discard the rest
                p.incompleteKey();
            }
        }
    }

    public void setTrust(byte b)
    {
        if(ring != null) ring.setPublicChanged();
        super.setTrust(b);
    }

    int getStatus()
    {
        if(status != KS_MISSING)
        {
            status = load.isComplete() ? KS_COMPLETE : KS_INCOMPLETE;
        }
        return status;
    }

    public boolean completeKey()
    {
        if( load != null && load.isComplete()) return true;
        try{ load.load(); }
        catch(java.io.IOException ex) {return false;}
        return true;
    }

    /**
    * checks a signature on the key
    */
    public int checkSignature(UserID name, Signature sig)
    {
	    int	result	= Signature.SIG_ERROR;

	    /* First check we have the keys for this operation */
	    if(!sig.toKey().completeKey() || !completeKey())
		    return Signature.SIG_NO_KEY;
	    if(sig.getSigClass() == SIGPacket.SUBKEY_BINDING)
        {
            if(superkey == null || !superkey.completeKey())
		        return Signature.SIG_NO_KEY;
        }
	    sig.completeSignature();
	    //if(getSignature(sig->details)) - no-op routine in CTClib for non-RSA
	    {
		    byte[] digest = keyNameHash(sig, name);
            result = sig.verify(digest);
	    }
	    sig.incompleteSignature();
	    return result;
    }
    private boolean keyHashUpdate(com.ravnaandtines.crypt.mda.MDA hash)
    {
        return load.keyHashUpdate(hash);
    }

    private byte[] keyNameHash(Signature sig, UserID name)
    {
        com.ravnaandtines.crypt.mda.MDA context =
            com.ravnaandtines.crypt.mda.Hash.getInstance(sig.getMDA());
        if(null == context) return null;

	    if(sig.getSigClass() == SIGPacket.SUBKEY_BINDING)
        {
		    superkey.keyHashUpdate(context);
        }
	    if(keyHashUpdate(context))
	    {
		    if(name!=null)
		    {
                byte[] bytes = name.toByteArray();
			    if(sig.getVersion() > Packet.VERSION_2_6)
			    {
				    byte[] lenField = { (byte)(Packet.CTB_DESIGNATOR + (Packet.UID << 2)), 0,0,0,0};
				    lenField[3] = (byte)(bytes.length >>> 8);
				    lenField[4] = (byte)(bytes.length & 0xff);
				    context.update(lenField, 0, 5);
			    }
			    context.update(bytes, 0, bytes.length);
		    }
            sig.digestExtras(context);
	    }
        return context.digest();
    }

    public UserID getUsername()
    {
        return name;
    }

    public String getName()
    {
       if(null == name) return "0x"+Hexprint.fmt(getKeyID());
       else return name.getName();
    }
    public long getKeyID()
    {
        if(null == load) return keyID;
        return load.getKeyID();
    }
    public boolean equals(PublicKey p)
    {
        return false;
    }
    public boolean isEnabled()
    {
        return true;
    }

    public int getSize()
    {
        if(null == load) return -1;
        return load.getSize();
    }

    public byte getVersion()
    {
        if(null == load) return (byte)0;
        return load.getVersion();
    }

    public String data()
    {
        if(load == null) return "UNKNOWN KEY";
        int size = load.getSize();
        byte alg = load.getPka();
        String id = Long.toHexString(getKeyID());
        // need to do load on demand for this...
        if(!load.isComplete())
        {
            try {load.load();}
            catch (java.io.IOException lex)
            {load.incompleteKey();}
        }
        String print = load.getKeyprint();
        long t = ((long)load.getTimestamp())&0x00000000FFFFFFFFL;
        Date date = new Date(1000L*t);

        StringBuffer buf = new StringBuffer("");
        if(!isEnabled()) buf.append("DISABLED KEY ");
        boolean valid = true;
        buf.append(PKCypher.getName(alg, false));
        buf.append(size);
        buf.append("/[");

        int l = id.length();
        for(int i=l; i<16; ++i) buf.append("0");
        for(int j=0; j<l; ++j)
        {
            buf.append(Character.toUpperCase(id.charAt(j)));
            if(9 == l-j) buf.append("]");
        }

        if(valid)
        {
            buf.append(" ");
            DateFormat fmt = DateFormat.getDateTimeInstance();
            buf.append(fmt.format(date));
            buf.append(" keyprint ");
            buf.append(print);
        }
        return buf.toString();
    }

    public boolean isRevoked()
    {
        return false;
    }
    public Signature getSignature()
    {
        return direct;
    }
    public PublicKey getSubkey()
    {
        return subkey;
    }
    public SecretKey getSeckey()
    {
        return null;//todo
    }
    public void extract()
    {
       //todo
    }
    public void sign(SecretKey signer)
    {
    }
    public void able()
    {
    }
    public void delete()
    {
    }

    /* checkSubkeys checks if the subkey is a keyRecoveryKey of mainkey
    **   if it is returns the next non-keyRecoveryKey subkey or NULL if none.
    **   If the subkey is non-keyRecovery it returns it.
    **   If subkey is NULL, it returns NULL.
    */
    private PublicKey checkKRK(PublicKey sub, PublicKey main)
    {
        if(null == sub) return null;
	    // recursively call self to eliminate any following keyRecoveryKeys
        PublicKey fallback = sub.subkey = checkKRK(sub.subkey, main);
/*
	    if(!checkSigs(sub, main, revocation(sub)))
		    return fallback;
	    if(!checkSigs(sub, main, revocation(main)))
		    return fallback;
	    UserID userid = firstName(main);
	    while(userid)
	    {
		    if(!checkSigs(sub, main, firstSig(userid)))
			    return fallback;
		    userid = nextName(userid);
	    }
*/
	    return sub;
    }

    public void removeKRK()
    {
        subkey = checkKRK(subkey, this);
    }

    public void addSubkey(PublicKey key)
    {
        if(key == null) return;
        key.superkey = this;
        key.subkey = this.subkey;
        this.subkey = key;
    }

    void setName(UserID newName)
    {
        name = newName;
    }

    public void addSignature(Signature s)
    {
        s.append(direct);
        direct = s;
    }

    boolean verify(MPI[] sign, byte[] digest)
    {
        // need to turn 'this' into a Key
        Key me = new Key();
        byte[][] nums = load.getKey();
        me.nums = new MPI[nums.length];
        for(int i=0; i<nums.length;++i)
        {
            me.nums[i] = new MPI();
            me.nums[i].num = nums[i];
        }
        PKA alg = PKCypher.getInstance(load.getPKA());
        MPI message = new MPI();
        message.num = digest;
        return alg.verify(sign, message, me,
        // dummy monitor here!!
            new com.ravnaandtines.util.Monitor(){
            public boolean user_break() {return false;}});
    }
}
