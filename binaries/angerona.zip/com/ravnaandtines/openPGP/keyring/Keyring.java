package com.ravnaandtines.openPGP.keyring;

import java.util.*;
import java.text.MessageFormat;
import com.ravnaandtines.openPGP.packet.*;
import com.ravnaandtines.util.io.*;
import com.ravnaandtines.util.event.*;
import com.ravnaandtines.util.text.Hexprint;

/**
*  Class Keyring
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/


public class Keyring
{
    private static Keyring ring = null;

    private RandomAccessFile pubring = null;
    private String pubName = null;
    private String secretName = null;
    private boolean pubRingBacked = false;
    private boolean secRingBacked = false;
    private Vector unlocked = null;

    private Keytable pk = null;
    private boolean publicChanged = false;

    private Vector sk = null;
    private boolean secretChanged = false;

    static StatusEventSupport ses = new StatusEventSupport();

    private static final String ioex = "Problem reading keyring packet : \"(0)\"";

    private Keyring()
    {
        pk = new Keytable();
        sk = new Vector();
    }

    public static void addStatusListener(StatusListener l)
    {
        ses.addStatusListener(l);
    }

    public static void removeStatusListener(StatusListener l)
    {
        ses.removeStatusListener(l);
    }

    private static void ensure()
    {
        if(ring == null) ring = new Keyring();
    }

    private void clearInternalisedKeys()
    {
        if(unlocked != null)
        {
            for(Enumeration e = unlocked.elements();
                e.hasMoreElements();)
            {
                SecretKey s = (SecretKey)e.nextElement();
                s.lock();
            }
            unlocked.removeAllElements();
            unlocked = null;
        }
    }

    private void clearInternalisedKey(SecretKey key)
    {
        if(unlocked != null)
        {
	        int i = unlocked.indexOf(key);
	        if(i >= 0)
	        {
                SecretKey s = (SecretKey)unlocked.elementAt(i);
                s.lock();
                unlocked.removeElement(s);
            }
        }
    }

    private void wipe() // cf destroy_userhash
    {
        // need to erase existing table of keys
        if(pubring != null)
        {
            try {
             pubring.close();
            } catch (java.io.IOException e) {}
            pubring = null;
        }
        pubName = null;
        secretName = null;
        pubRingBacked = false;
        secRingBacked = false;
        clearInternalisedKeys();
        pk.clear();
        sk.removeAllElements();
    }

    private class KeyringContext
    {
	    PublicKey   last_mainkey = null;    /* last pub-key (excluding sub-keys) found */
	    PublicKey   last_key = null;	    /* last pub-key found (may be sub-key) */
	    SecretKey   last_seckey = null;
	    UserID      last_name = null;
	    Trusted     last_trust;
    }



    // cf init_userhash
    private void loadPublic(String file, RandomAccessFile read)
    {
        pubring = read;
        pubName = file;
        KeyringContext context = new KeyringContext();
        for(;;)
        {
            String[] args = new String[1];

            Packet p = null;
            try {
                p = Packet.getInstance(pubring);
                } catch (MalformedPacketException mp) {
                    args[0] = mp.getLocalizedMessage();
                    ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.WARN,
                        MessageFormat.format(
                        "Badly formatted keyring packet : \"(0)\"",
                        args)));
                } catch (java.io.IOException io) {
                    args[0] = io.getLocalizedMessage();
                    ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.WARN,
                        MessageFormat.format(ioex, args)));
                // TODO - signal; maybe continue, maybe wipe
                break;
            }
            if(null == p) break; // expected end of file

            if(p.getType() == Packet.PKEY || p.getType() == Packet.SKEY)
            {
                finish(context);
            }
            queue(context, p, read);
        }
        finish(context);
    }


    private void insertSeckey(SecretKey sec_key)
    {
	    /* first ensure that the public key is in the public ring */
        pk.add(sec_key.getPubkey());

        /* Then proceed only if the secret key is new */
		//if(!seckey_from_keyID(keyRings, sec_key->publicKey->keyId))
		{
			sk.addElement(sec_key);
			secretChanged = true;
		}
	}

    private void finish(KeyringContext context)
    {
        // eliminate KeyRecovery keys
	    if(context.last_mainkey != null)
        {
            context.last_mainkey.removeKRK();
        }
	    if(context.last_seckey != null)
	    {
		    insertSeckey(context.last_seckey);
		    context.last_seckey  = null;
		    context.last_key	 = null;
		    context.last_mainkey = null;
	    }
	    else if(context.last_mainkey != null)
	    {
            publicChanged = pk.add(context.last_mainkey) != Keytable.NOOP;
		    context.last_key = null;
		    context.last_mainkey = null;
	    }
        context.last_name=null;
    }

    /* Note that keyRings->file may or may not equal input depending on whether
    **   we are reading the public key ring or some other file (secret ring included).
    **   The action may accordingly vary slightly */
    void queue( KeyringContext context, Packet p, Read input )
    {
	    long fileOffset = (input == pubring) ? p.getOffset() : PacketHeader.INDETERMINATE;
        String[] args = new String[1];

	    switch(p.getType())
	    {
		    case Packet.PKEY:
		    case Packet.PSUBKEY:
		    {
                PublicKey key = new PublicKey((PKEYPacket)p, (input != pubring));
                if(((PKEYPacket)p).isComment())
                {
                    args[0] = ((PSUBKEYPacket)p).getCommentString();
                    ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.WARN,
                        MessageFormat.format(
                        "Comment packet encountered : \"(0)\"",
                        args)));
                    break;
                }
			    if(p.getType() == Packet.PKEY)
			    {
				    context.last_key = key;
				    context.last_mainkey = key;
			    }
			    else //if(summary->type == CTB_PUB_SUBKEY)
			    {
				    context.last_mainkey.addSubkey(key);
				    context.last_key	= key;
			    }
			    context.last_name  = null;
			    context.last_trust = key;
			    break;
		    }

		    case Packet.SKEY:
		    case Packet.SSUBKEY:
		    {
                SecretKey sec_key = new SecretKey((SKEYPacket)p);
                if(input != pubring)
                {
                    args[0] = Hexprint.fmt(sec_key.getKeyID());
                    ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.STATUS,
                        MessageFormat.format(
                        "Secret key record : \"(0)\"",
                        args)));
                }
                context.last_seckey = sec_key;
                context.last_trust = context.last_key = context.last_mainkey = sec_key.getPubkey();
                context.last_name = null;
			    break;
		    }

		    case Packet.UID:
			if(context.last_mainkey != null)
			{
                UserID nameRec = new UserID(context.last_mainkey,
                    context.last_name, (UIDPacket)p);
                if(input != pubring)
                {
                    try {
                        p.load();
                        args[0] = nameRec.toString();
                        if(args[0] == null) args[0] = "";
                        ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.STATUS,
                        MessageFormat.format(
                        "User ID record : \"(0)\"",
                        args)));
                    } catch (java.io.IOException ex) {
                        args[0] = ex.getLocalizedMessage();
                        ses.fireStatusEvent( new StatusEvent(
                        this,  StatusEvent.WARN,
                        MessageFormat.format(ioex, args)));
                    }
                }
                context.last_trust = context.last_name = nameRec;
			}
			break;
						
		    case Packet.SIG:
		    {
                Signature sig = new Signature((SIGPacket)p);

			    if(context.last_key != null)	//We can only sensibly process a key signature if we have
											    // a key for it to refer to.
			    {
                    PublicKey signing_key = pk.getFirstKey(((SIGPacket)p).getKeyID());

				    if(null == signing_key || signing_key.getStatus() != PublicKey.KS_COMPLETE)
				    {
				        // Signature key not (yet) in key-ring; check if its the key being signed
					    if(((SIGPacket)p).getKeyID() == context.last_mainkey.getKeyID())
					    {
						    signing_key = context.last_mainkey;	// Self-signature
					    }
					    else if(null == signing_key)
					    {
						    signing_key = new PublicKey(((SIGPacket)p).getKeyID());
						    // empty placeholder are ALWAYS put in the hash table
                            pk.add(signing_key);
					    }
				    } // key not available

                    sig.setSigner(signing_key);
                    if(context.last_name != null)
                    {
                        context.last_name.addSignature(sig);
                    }
                    else
                    {
                        context.last_key.addSignature(sig);
                    }

				    if(input != pubring)
				    {
/*
					    char * sigType;
					    sigValid validity;

					    sig->details = (sigDetails*)zmalloc(sizeof(sigDetails));
					    if(readSKEpacket(input, summary->position, sig->details) != KIO_OKAY)
				    	{	qfree(sig->details); sig->details = NULL; return CB_SKIP; }

					    sigType =  enumName(SIGCLASS, sig->details->sigClass, TRUE);
					    validity = checkSignature(context->last_key, context->last_name, sig);
					    if(!context->last_name)
					    {	// No name so it is a revocation or a subkey certificate (or we don't recognise it)
						    if(sig->details->sigClass != SIG_KEY_COMPROM &&
							    sig->details->sigClass != SIG_SUBKEY_CERT)
						    {
							    fullCondition(CB_ERROR, KEY_NO_USERID, CB_DECRYPTION, sigType, signing_key);
							    free_signature(sig);
							    break;
						    }
						    // Revocation (self-signature); the key will probably not yet be in the keyring
						    // however it should be in context->last_key
						    else if(memcmp(summary->itemID, signing_key->keyId, KEYFRAGSIZE))
						    {
							    // revoked with the wrong key!
							    fullCondition(CB_WARNING, KEY_WRONG_REVOKE, CB_DECRYPTION, sigType, signing_key);
						    }
						    switch(validity)
						    {
							    case SIG_OKAY:
								context->last_key->directSig = sig;
								context->last_key->trust		= KTB_ENABLE_DISABLE;
								fullCondition(CB_INFO, KEY_KEYSIG_FOUND, CB_DECRYPTION, sigType, signing_key);
								break;

							    case SIG_ERROR: // Process of checking failed (status of key dubious)
								context->last_key->trust	= KTB_ENABLE_DISABLE;
								fullCondition(CB_WARNING, KEY_UNCK_REVOKE, CB_DECRYPTION, sigType, signing_key);
								free_signature(sig);
								break;

							    default:
								fullCondition(CB_ERROR, KEY_BAD_REVOKE, CB_DECRYPTION,
											sigType, signing_key);
								free_signature(sig);
								break;
						    }
					    }
					    else // no name
					    {
						    key_man_conds cond;

						    switch(validity)
						    {	case SIG_OKAY:		cond = KEY_KEYSIG_FOUND;	break;
							    case SIG_BAD:		cond = KEY_BADSIG_FOUND;	break;
							    default:			cond = KEY_NOKEY_SIG_FND;	break;
						    }
						    fullCondition((short) CB_INFO, (short) cond, CB_DECRYPTION,
										sigType, signing_key);
                        } // context.last_name
*/
				    }
				    context.last_trust = sig;
			    } // key to add signature to
			    break;
		    }

		    case Packet.TRUST:
			if(context.last_trust != null)
			{
				context.last_trust.setTrust(((TRUSTPacket)p).getTrust());
				context.last_trust = null;
			}
			break;
					
	    }
	    //return CB_CONTINUE;
    }


    private boolean loadSecret(com.ravnaandtines.util.io.RandomAccessFile read)
    {
        // still to do
        return true;
    }

    private boolean readSeckeys(String file)
    {
        secRingBacked = false;
        try {
            com.ravnaandtines.util.io.RandomAccessFile read =
                new com.ravnaandtines.util.io.RandomAccessFile(file, "r");
            if(loadSecret(read))
            {
                secretName = file;
                return true;
            }
        } catch (Exception e) {}
        wipe();
        return false;
    }

    private boolean clearAll()
    {
        clearInternalisedKeys();
        if(!write()) return false;
        wipe();
        //gfQuit();
        return true;
    }

    private boolean write()
    {
        publicChanged = false;
        secretChanged = false;
        return true; //todo
    }

    void setPublicChanged()
    {
        publicChanged = true;
    }
    void setSecretChanged()
    {
        secretChanged = true;
    }

    public static boolean readPubring(String file)
    {
        ensure();
        ring.wipe();

        try {
            com.ravnaandtines.util.io.RandomAccessFile read =
                new com.ravnaandtines.util.io.RandomAccessFile(file, "r");
            ring.loadPublic(file, read);
            return true;
        } catch (Exception ex) {ex.printStackTrace();}
        return false;
    }

    public static boolean readSecring(String file)
    {
        return (ring == null) ? false : ring.readSeckeys(file);
    }

    public static boolean clear()
    {
        return ring == null ? true : ring.clearAll();
    }
    public static boolean isValid()
    {
        return (ring == null) ? false : ring.pubring != null;
    }
    public static Enumeration publicKeys()
    {
        return (ring == null) ? null : ring.pk.keys();
    }
    public static Enumeration secretKeys()
    {
        return (ring == null) ? null : ring.sk.elements();
    }
}