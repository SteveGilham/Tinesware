package com.ravnaandtines.openPGP.keyring;
import java.util.*;
/**
*  Class Keytable
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
* This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 dd-Mmm-yyyy
*
*/

public class Keytable
{
    private Hashtable table = new Hashtable();
    public static final int NOOP = 0;
    public static final int CHANGE = 1;
    public static final int DEADBEEF = 2;


    /**
    * package level utility to manage public keys indexed by
    * their keyID (as long)
    */
    Keytable()
    {
    }

    /**
    * Adds another public key to this list, complaining (but
    * continuing) if two keys clash by indexed value).
    * @param pkey PublicKey to index
    * @return NOOP if no changes, CHANGE if distinct or extension, DEADBEEF if deadbeef
    */
    int add(PublicKey pkey)
    {
        Long key = new Long(pkey.getKeyID());
//System.out.println("adding key ID "+com.ravnaandtines.util.text.Hexprint.fmt(pkey.getKeyID()));
        Object o = table.get(key);
        if(null == o)
        {
            table.put(key, pkey);
            return NOOP;
        }
        else if (o instanceof PublicKey)
        {
            PublicKey other = (PublicKey)o;
            if(pkey.equals(other)) return CHANGE;    //TODO merge new data
            table.remove(key);
            Vector v = new Vector();
            v.addElement(other);
            v.addElement(pkey);
            table.put(key, v);
        }
        else
        {
            Vector v = (Vector) o;
            Enumeration e = v.elements();
            while(e.hasMoreElements())
            {
                PublicKey other = (PublicKey) e.nextElement();
                if(pkey.equals(other)) return CHANGE;    //TODO merge new data
            }
            v.addElement(pkey);
        }
        return DEADBEEF;
    }

    boolean isPresent(long keyID)
    {
        Long key = new Long(keyID);
        return table.containsKey(key);
    }

    boolean isUnique(long keyID)
    {
        Long key = new Long(keyID);
        Object o = table.get(key);
        if(null == o) return true;
        return (o instanceof PublicKey);
    }

    PublicKey getFirstKey(long keyID)
    {
        Long key = new Long(keyID);
        Object o = table.get(key);
        if(null == o) return null;
        if (o instanceof PublicKey) return (PublicKey)o;
        Vector v = (Vector) o;
        return (PublicKey) v.firstElement();
    }
    Vector getKeys(long keyID)
    {
        Long key = new Long(keyID);
        Object o = table.get(key);
        if(null == o) return null;
        if (o instanceof PublicKey)
        {
            Vector v = new Vector();
            v.addElement(o);
            return v;
        }
        return (Vector)o;
    }

    void clear()
    {
        for(;;)
        {
            Enumeration e = table.keys();
            if(!e.hasMoreElements()) break;
            Object o = table.remove(e.nextElement());
            if(o instanceof Vector)
            {
                ((Vector) o).removeAllElements();
            }
        }
    }

    Enumeration keys()
    {
        return new KeytableEnumeration(table.elements());
    }
}
