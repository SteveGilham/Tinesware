package com.ravnaandtines.crypt.cea;

import java.util.*;

/**
*  Class Cypher
*  <P>
*   main despatcher for cipher algorithms and modes.
*   Modal stuff is done here; each algorithm just has to provide the CEA
*   interface
*  <P>
*  Coded Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
* @author Mr. Tines
* @version 1.0 23-Dec-1998
*/

public class Cypher
{
    /**
    * Algorithm class bundle
    */
    private static ResourceBundle res =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.cea.CEAClasses");
    /**
    * Algorithm tags bundle
    */
    private static ResourceBundle res1 =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.cea.CEATags");
    /**
    * Conventional encryption algorithm selector bytes.
    */
    /**
    * Not a PGP-classic imitator
    */
    public static final byte FLEX_FLAG = (byte)0x80;
    /**
    * Another cipher key follows
    */
    public static final byte MORE_FLAG = 0x40;
    /**
    * removes the "more" flag
    */
    public static final byte CEA_MASK = ~MORE_FLAG;

    /**
    * use  the IDEA cipher
    */
    public static final byte IDEA = 1;
    private static Class cIDEA = null;
    /**
    * PGP5 code for Triple-DES -
    *                       note that we cannot use CEM flags with this
    */
    public static final byte TDES = 2;
    private static Class cTDES = null;
    /**
    * PGP5 code for CAST
    */
    public static final byte CAST5 = 3;
    private static Class cCAST5 = null;

    /**
    * GPG algorithm values
    * 128-bit Blowfish
    */
    public static final byte GPG_BLOW16 = 4;
    private static Class cBLOW16 = null;
    /**
    * Rot-N ??
    */
    public static final byte GPG_ROT_N = 5;
    /**
    * SAFER-SK128 (??13 rounds??)
    */
    public static final byte GPG_SAFERSK128 = 6;
    private static Class cSAFERSK128 = null;
    /**
    * DES_SK - whatever that is
    */
    public static final byte GPG_DES_SK = 7;
    /**
    * 160-bit Blowfish
    */
    public static final byte GPG_BLOW20 = 42;
    private static Class cBLOW20 = null;
    /**
    * GOST (if they have replaced the IDEA code)
    */
    public static final byte GPG_GOST = 43;

    /**
    * EBP values
    * IDEA with non-PGP2.6 algorithm
    */
    public static final byte EBP_IDEA = 86;
    /**
    * EBP base value for SAFER SK-128 and the only one used.  Max rounds
    */
    public static final byte EBP_SAFER = 97;
    /**
    * explicit no encryption - more flag must not be set
    */
    public static final byte NONE = (byte)(0|FLEX_FLAG);
    /**
    * systematic IDEA
    */
    public static final byte IDEAFLEX  = (byte)(IDEA|FLEX_FLAG);
    /**
    * 3-Way
    */
    public static final byte TWAY = (byte)(2|FLEX_FLAG);
    private static Class cTWAY = null;
    /**
    * 128-bit Blowfish
    */
    public static final byte BLOW16 = (byte)(3|FLEX_FLAG);
    /**
    * Tiny Encryption Algorithm
    */
    public static final byte TEA = (byte)(4|FLEX_FLAG);
    private static Class cTEA = null;
    /**
    * 40-bit Blowfish
    */
    public static final byte BLOW5 = (byte)(5|FLEX_FLAG);
    private static Class cBLOW5 = null;
    /**
    * Square
    */
    public static final byte SQUARE = (byte)(6|FLEX_FLAG);
    private static Class cSQUARE = null;
    /**
    * Single DES
    */
    public static final byte DES = (byte)(7|FLEX_FLAG);
    private static Class cDES = null;
    /**
    * S3-DES (Schneier's variant)
    */
    public static final byte S3DES = (byte)(8|FLEX_FLAG);
    /**
    * Biham's key-dependent DES
    */
    public static final byte KDDES = (byte)(9|FLEX_FLAG);
    /**
    * triple DES
    */
    public static final byte TDESFLEX = (byte)(10|FLEX_FLAG);
    /**
    * CAST5-128
    */
    public static final byte CAST5FLEX = (byte)(11|FLEX_FLAG);
    /**
    * Rot-N ??
    */
    public static final byte ROT_NFLEX = (byte)(12|FLEX_FLAG);
    /**
    * Flexible GPG Safer
    */
    public static final byte SAFERSK128FLEX = (byte)(13|FLEX_FLAG);
    /**
    * Flexible GPG DESSK
    */
    public static final byte DESSKFLEX = (byte)(14|FLEX_FLAG);
    /**
    * Flexible 160-bit Blowfish
    */
    public static final byte BLOW20 = (byte)(15|FLEX_FLAG);
    /**
    * Flexible GOST
    */
    public static final byte GOSTFLEX = (byte)(16|FLEX_FLAG);

    /**
    * other data is present if only CEA_MORE_FLAG set
    */
    public static final byte ESCAPE = (byte)(0|MORE_FLAG|FLEX_FLAG);

    /**
    * Have we sought the class data?
    */
    private static boolean loaded = false;

    /**
    * returns an instance of the desired encryption algorithm
    * @param cea byte code indicating algorithm
    */
    public static CEA getInstance(byte cea)
    {
        if(!loaded) load();

        switch (cea)
        {
            case IDEA:
            case EBP_IDEA:
            case IDEAFLEX:
                return build(cIDEA);
            case TDES:
            case TDESFLEX:
                return build(cTDES);
            case CAST5:
            case CAST5FLEX:
                return build(cCAST5);
            case GPG_BLOW16:
            case BLOW16:
                return build(cBLOW16);
            //case GPG_ROT_N:
            //case ROT_NFLEX:
                //return
            case GPG_SAFERSK128:
            case EBP_SAFER:
            case SAFERSK128FLEX:
                return build(cSAFERSK128);
            //case GPG_DES_SK:
            //case DESSKFLEX:
                //return
            case GPG_BLOW20:
            case BLOW20:
                return build(cBLOW20);
            //case GPG_GOST:
            //case GOSTFLEX:
                //return
            case TWAY:
                return build(cTWAY);
            case TEA:
                return build(cTEA);
            case BLOW5:
                return build(cBLOW5);
            case SQUARE:
                return build(cSQUARE);
            case DES:
                return build(cDES);
            //case S3DES:
            //case KDDES:
        }
        return null;
    }

    /**
    * returns an instance of the desired encryption algorithm
    * @param c class indicating algorithm
    */
    private static CEA build(Class c)
    {
        if(null == c) return null;
        try {
            return (CEA) c.newInstance();
        } catch (IllegalAccessException iae) {}
        catch (InstantiationException ie) {}
        return null;
    }

    /**
    * Tells us if the indicated algorithm has been found
    * @param cea byte code indicating algorithm
    */
    public static boolean isAlgorithmAvailable(byte cea)
    {
        if(!loaded) load();

        switch (cea)
        {
            case IDEA:
            case EBP_IDEA:
            case IDEAFLEX:
                return cIDEA != null;
            case TDES:
            case TDESFLEX:
                return cTDES != null;
            case CAST5:
            case CAST5FLEX:
                return cCAST5 != null;
            case GPG_BLOW16:
            case BLOW16:
                return cBLOW16 != null;
            //case GPG_ROT_N:
            //case ROT_NFLEX:
                //return
            case GPG_SAFERSK128:
            case EBP_SAFER:
            case SAFERSK128FLEX:
                return cSAFERSK128 != null;
            //case GPG_DES_SK:
            //case DESSKFLEX:
                //return
            case GPG_BLOW20:
            case BLOW20:
                return cBLOW20 != null;
            //case GPG_GOST:
            //case GOSTFLEX:
                //return
            case TWAY:
                return cTWAY != null;
            case TEA:
                return cTEA != null;
            case BLOW5:
                return cBLOW5 != null;
            case SQUARE:
                return cSQUARE != null;
            case DES:
                return cDES != null;
            //case S3DES:
            //case KDDES:
        }
        return false;
    }

    /**
    * finds a Class for each of the algorithms of interest if possible
    */
    private static synchronized void load()
    {
        if(loaded) return;
        cIDEA = find("IDEA");
        cTDES = find("3DES");
        cCAST5 = find("CAST5");
        cBLOW16 = find("Blowfish128");
        cSAFERSK128 = find("SAFER-SK128");
        cBLOW20 = find("Blowfish160");
        cTWAY = find("3-Way");
        cTEA = find("TEA");
        cBLOW5 = find("Blowfish40");
        cSQUARE = find("SQUARE");
        cDES = find("DES");
        loaded = true;
    }

    /**
    * finds a Class for the named algorithm (the name is keyed
    * from a resource value), ensuring that it implements CEA
    */
    private static Class find(String name)
    {
        Class result = null;
        try {
            result = Class.forName(res.getString(name));
        } catch ( MissingResourceException mre) { return null;}
        catch ( ClassNotFoundException cnfe) { return null;}
        if(null == result) return null;

        Class [] ifs = result.getInterfaces();
        for(int i=0; i<ifs.length; ++i)
        {
            if(ifs[i] == CEA.class) return result;
        }
        return null;
    }

    /**
    * Serves up a descriptive string for the algorithm
    * @param alg the algorithm on which to report
    * @param full true if you want the long form
    * @return the description string
    */
    public static String getAlgName(byte alg, boolean full)
    {
        boolean brief = !full;
        switch(alg)
        {
            case IDEA: return brief ? res1.getString("IDEAP") : res1.getString("IDEA_International");
            case TDES: return brief ? res1.getString("3DESP") : res1.getString("Triple_DES_PGP_");
            case CAST5: return brief ? res1.getString("CASTP") : res1.getString("CAST5_PGP_");

            case GPG_BLOW16: return brief ? res1.getString("BLOW16G") : res1.getString("Blowfish_with_16_byte");
            case GPG_ROT_N: return brief ? res1.getString("ROTNG") : res1.getString("ROT_GPG_");
            case GPG_SAFERSK128: return brief ? res1.getString("SAFERG") : res1.getString("SAFER_Secure_And_Fast");
//            case GPG_DES_SK: return brief ?
            case GPG_BLOW20: return brief ? res1.getString("BLOW20G") : res1.getString("Blowfish_with_20_byte");
            case GPG_GOST: return brief ? res1.getString("GOSTG") : res1.getString("GOST_Gosudarstvennyi");

            case EBP_IDEA: return brief ? res1.getString("IDEAE") : res1.getString("IDEA_International1");
            case EBP_SAFER: return brief ? res1.getString("SAFERE") : res1.getString("SAFER_Secure_And_Fast1");
            case IDEAFLEX: return brief ? res1.getString("IDEA") : res1.getString("IDEA_International2");
            case TWAY: return brief ? res1.getString("3WAY") : res1.getString("3WAY_cipher");
            case BLOW16: return brief ? res1.getString("BLOW16") : res1.getString("Blowfish_with_16_byte1");
            case TEA: return brief ? res1.getString("TEA") : res1.getString("TEA_Tiny_Encryption");
            case BLOW5: return brief ? res1.getString("BLOW5") : res1.getString("Blowfish_with_40_bit");
            case SQUARE: return brief ? res1.getString("SQUARE") : res1.getString("Square_128_bit_key");
            case DES: return brief ? res1.getString("DES") : res1.getString("DES_Data_Encryption");
            case S3DES: return brief ? res1.getString("S3DES") : res1.getString("s3DES");
            case KDDES: return brief ? res1.getString("KDDES") : res1.getString("key_dependent_DES");
            case TDESFLEX: return brief ? res1.getString("3DES") : res1.getString("Triple_DES_CTC_");
            case CAST5FLEX: return brief ? res1.getString("CAST5") : res1.getString("CAST5_CTC_");
            case ROT_NFLEX: return brief ? res1.getString("ROTN") : res1.getString("ROT");
            case SAFERSK128FLEX: return brief ? res1.getString("SAFER") : res1.getString("SAFER_Secure_And_Fast2");
//            case DESSKFLEX: return brief ? res1.getString("KDESF") : res1.getString("key_dependent_DES");
            case BLOW20: return brief ? res1.getString("BLOW20") : res1.getString("Blowfish_with_20_byte1");
            case GOSTFLEX: return brief ? res1.getString("GOST") : res1.getString("GOST_Gosudarstvennyi1");
            default: return brief ? res1.getString("UNKALG") : res1.getString("Unknown_bulk_cipher");
        }
    }

    /**
    * Conventional encryption mode selector bytes
    * <p>work from the end of the file
    */
    public static final byte REVERSE_FLAG = (byte)0x80;
    /**
    * three keys follow for outer chaining
    */
    public static final byte TRIPLE_FLAG = 0x40;
    /**
    * Rot-N ??
    */
    public static final byte CEM_MASK = 0x3F;
    /**
    * CFB mode - assumed for PGP-classic
    */
    public static final byte mCFB = 1;
    /**
    * ECB mode - with ciphertext stealing
    */
    public static final byte mECB = 2;
    /**
    * OFB mode
    */
    public static final byte mOFB = 3;
    /**
    * CBC mode - with ciphertext stealing
    */
    public static final byte mCBC = 4;
    /**
    * Rivest's all or nothing mode - with ciphertext stealing
    */
    public static final byte mAAN = 5;


    /**
    * Serves up a descriptive string for the mode
    * @param mode the mode on which to report
    * @param full true if you want the long form
    * @return the description string
    */
    public static String getModeName(byte mode, boolean full)
    {
        boolean brief = !full;
        switch(mode)
        {
            case mCFB: return brief ? res1.getString("CFB") : res1.getString("Cypher_Feedback_mode");
            case mECB: return brief ? res1.getString("ECB") : res1.getString("Electronic_Codebook");
            case mOFB: return brief ? res1.getString("OFB") : res1.getString("Output_Feedback_mode");
            case mCBC: return brief ? res1.getString("CBC") : res1.getString("Cypher_Block_Chaining");
            case mAAN: return brief ? res1.getString("Fusion") : res1.getString("Rivest_s_all_or");
            default: return brief ? res1.getString("UNKMODE") : res1.getString("Unknown_bulk_cipher1");
        }
    }

    /**
    * Alg/mode pair
    */
	private Details cypher;
    /**
    * Overall encryption direction (not the cypher's direction)
    */
	boolean decryp;
    /**
    * TODO
    */
	int length;
    /**
    * The cypher
    */
	CEA secret;
    /**
    * The block length of the cypher
    */
	short blocklen;
    /**
    * The key length of the cypher
    */
	short keylen;
    /**
    * One block's worth of IV
    */
	byte[] iv = null;
    /**
    * 2 blocks worth of buffer for e.g. CBC mode
    */
    byte[] delay = null;
    /**
    * number of valid bytes in the delay buffer
    */
    short buffered;

    /**
    * default constructor
    */
    private Cypher()
    {
    }

    /**
    * This function returns true for modes that use encryption primitives
    * to encrypt and decryption primitives to decrypt
    * It returns false for modes that use encryption for both
    * @param cv_mode mode in use
    * @return whether a two-way algorithm is required
    */
    static boolean modeUsesDecrypt(byte cv_mode)
    {
        switch (cv_mode & CEM_MASK)
        {
            case mOFB:
            case mCFB: return false;
            default: return true;
        }

    }

    /**
    * Changes buffer via xor with random mask block
    *	Used for Cipher Feedback (CFB) or Cipher Block Chaining
    *	(CBC) modes of encryption.
    *	Can be applied for any block encryption algorithm,
    *	with any block size.
    * @param buf input data
    * @param offset input data start
    * @param mask mask block
    * @param moffset mask offset
    * @param count bytes to mask must be > 0
    */
    private static void xorbuf(byte[] buf, int offset, byte[] mask,
    	int moffset, int count)
    {
	    if (count > 0)
        {
		    do{
			    buf[offset++] ^= mask[moffset++];
		    }while (--count > 0);
        }
    }

    /**
    * ECB encrypts or decrypts 1 block
    * @param in input data array
    * @param offin starting point into array
    * @param out output data array
    * @param offout starting point into array
    * @param encrypt if true, use defined encryption, else decrypt
    */
    private final void ECB1block(
        byte[] in, int offin, byte[] out, int offout, boolean encrypt)
    {
        secret.ecb(encrypt, in, offin, out, offout);
    }

    /*Cypher Feedback (CFB) mode support ****************************************/

    /**
    *	cfbshift - shift bytes into IV for CFB input
    *	Used only for Cipher Feedback (CFB) mode of encryption.
    *	Can be applied for any block encryption algorithm with any block size.
    * 	@param iv is the initialization vector.
    *	@param buf is the buffer pointer.
    *   @param bufoff is the offset into the buffer
    *	@param count is the number of bytes to shift in...must be > 0.
    *	@param blocksize is the size of the block in bytes
    */
    static void cfbshift(byte[] iv, byte[] buf, int bufoff,
		int count, int blocksize)
    {
	    int retained;
	    if (count > 0)
	    {
		    retained = blocksize-count;	/* number bytes in iv to retain */
		    /* left-shift retained bytes of IV over by count bytes to make room */
            int idx = 0;
		    while (retained-- > 0)
		    {
			    iv[idx] = iv[idx+count];
			    idx++;
		    }
		    /* now copy count bytes from buf to shifted tail of IV */
		    do	{iv[idx++] = buf[bufoff++];}
		    while (--count > 0);
	    }
    }	/* cfbshift */

    /**
    * CFB en/decrypt the data
    * @param buf data to encrypt
    * @param bufoff start point
    * @param count number of bytes to work on
    */
    private void CFB(byte[] buf, int bufoff, int count)
    {
	    int block = secret.getBlocksize();
	    int chunksize;
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;
	    int index;

	    if(reverse)
		    index = bufoff+count-block;
	    else
		    index = bufoff;

	    while ((chunksize = Math.min(count, block)) > 0)
	    {
            /* don't step off the start of the array */
		    if(reverse && (chunksize < block))
                index = bufoff;

		    /* encrypt IV into temp */
            ECB1block(iv, 0, delay, 0, true);

		    if(decryp) /* buf is cyphertext - shift to IV*/
			    cfbshift(iv, buf, index, chunksize, block);

		    xorbuf(buf, index, delay, 0, chunksize); /* enciphered bytes now output */

		    if(!decryp)
			    cfbshift(iv, buf, index, chunksize, block);

		    count -= chunksize;
		    if(reverse) index -= chunksize;
		    else index += chunksize;
	    } /* end while */
    }

/*Electronic Codebook (ECB) mode support ***********************************/

    /**
    * ECB en/decrypt the data block by block
    * @param buf data to encrypt
    * @param bufoff start point
    * @param count number of bytes to work on
    * @return number of bytes output
    */
    private int ECB(byte[] buf, int bufoff, int count)
    {
	    int block = secret.getBlocksize();
	    byte[] temp = new byte[block];
	    int chunksize;
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;

        int index, outdex;
        int retval = 0;

        /*  ensure first two blocks - or everything if < 2 blocks
            is buffered.  Then we can start working.  After an initial
            block or so, data comes in 0 or more large chunks, with
            perhaps a short tail.  Expect to have >1 and <= 2 blocks
            left buffered.
        */
        int totalBytes = buffered + count;
        int nblocks = totalBytes/block;
        nblocks = (totalBytes == nblocks * block) ?
               nblocks-2 : nblocks - 1;

        if(buffered < 2*block)
        {
            int need = 2*block - buffered;

            /* not enough left */
            if(count < need)
            {
                /*  we expect this to happen for the first block (key protection)
                    or block+2 (encrypted message packet); and perhaps also for
                    a *very* short message */
                if(reverse)
                {
                    System.arraycopy(
                        buf, bufoff, delay, 2*block-(buffered+count), count);
                }
                else
                {
                    System.arraycopy(
                        buf, bufoff, delay, buffered, count);
                }
                buffered += (short) count;
                return 0;
            }


            if(reverse)
            {
                System.arraycopy(
                    buf, count-need, delay, 0, need);
                index = bufoff+count-need-block;
                outdex = bufoff+block*nblocks;
            }
            else
            {
                System.arraycopy(
                    buf, bufoff, delay, buffered, need);
                index = bufoff+need;
                outdex = bufoff;
            }
            buffered = (short)(2*block);
            count -= need;
        }
	    else
        {
	        if(reverse)
                index = outdex = bufoff+block*nblocks;
	        else
		        outdex = index = bufoff;
        }

        while (count > 0)
	    {
            int thisBlock = (reverse) ? block : 0;

            /* en/decrypt thisBlock into temp */
            ECB1block(delay, thisBlock, temp, 0, !decryp);

            /* shuffle delayed block along */
            if(reverse) System.arraycopy(delay, 0, delay, block, block);
            else System.arraycopy(delay, block, delay, 0, block);

            /* pull next (partial?) block of data from source array */
            chunksize = Math.min(count, block);
            if(reverse)
            {
                System.arraycopy(
                    buf, index, delay, block-chunksize, chunksize);
                if((index-bufoff) >= chunksize)index -= chunksize;
                else index = bufoff;
            }
            else
            {
                System.arraycopy(
                    buf, index, delay, block, chunksize);
                index += chunksize;
            }
            count -= chunksize;
            buffered += (short)(chunksize - block);

            /* put data into source array - assumes input buffer holds length
                rounded up to nearest block w/o problems */
            if(reverse)
            {
                System.arraycopy(temp, 0, buf, outdex-block, block);
                outdex -= block;
            }
            else
            {
                System.arraycopy(temp, 0, buf, outdex, block);
                outdex += block;
            }
            retval += block;
	    } /* end while */
        return retval;
    }

    /**
    * Finish ECB by using cyphertext stealing on the final 1-2 blocks
    * @param buf where to put output data
    * @param bufoff start point
    * @return number of bytes emitted
    */
    private int ECB_CTS(byte[] buf, int bufoff)
    {
	    int block = secret.getBlocksize();
	    byte[] temp = new byte[block];
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;
        int leftover = buffered - block;

        //assert(buffered >= block);

        /* first simple case */
        if(buffered == block)
        {
            ECB1block(delay,(reverse?block:0), buf, bufoff, !decryp);
            return block;
        }
        else if (buffered == 2*block)
        {
            /* No need to worry about reversal as no diffusion here */
            ECB1block(delay, 0, buf, bufoff, !decryp);
            ECB1block(delay, block, buf, bufoff+block, !decryp);
            return 2*block;
        }

        if(!decryp)
        {
            /* Encrypt whole block at appropriate end into temp... */
            ECB1block(delay,(reverse?block:0), temp, 0, true);

            /* Put leading leftover bytes into output, and assemble new block
                with real leftovers */
            if(reverse)
            {
                System.arraycopy(
                    temp, block-leftover, buf, bufoff+block, leftover);
                System.arraycopy(
                    temp, 0, temp, leftover, block-leftover);
                System.arraycopy(
                    delay, block-leftover, temp, 0, leftover);
            }
            else
            {
                System.arraycopy(
                    temp, 0, buf, bufoff, leftover);
                System.arraycopy(
                    temp, leftover, temp, 0, block-leftover);
                System.arraycopy(
                    delay, block, temp, block-leftover, leftover);
            }

            /* Encrypt that into place for output */
            ECB1block(temp, 0, buf, bufoff+(reverse?0:leftover), true);
        }
        else /* Decryption phase */
        {
            /* Decrypt hybrid block into temp */
            ECB1block(delay, (reverse?block-leftover:leftover),
                        temp, 0, false);

            /* Put true leftover bytes into output and assemble whole block */
            if(reverse)
            {
                System.arraycopy(
                    temp, 0, buf, bufoff, leftover);
                System.arraycopy(
                    temp, leftover, temp, 0, block-leftover);
                System.arraycopy(
                    delay, 2*block-leftover, temp, block-leftover, leftover);
            }
            else
            {
                System.arraycopy(
                    temp, block-leftover, buf, bufoff+block, leftover);
                System.arraycopy(
                    temp, 0, temp, leftover, block-leftover);
                System.arraycopy(
                    delay, 0, temp, 0, leftover);
            }

            /* And decrypt that into place*/
            ECB1block(temp, 0, buf, bufoff+(reverse?leftover:0), false);
        }
        return buffered;
    }

    /*Output Feedback (OFB) mode support ****************************************/

    /**
    * OFB en/decrypt the data
    * @param buf data to encrypt
    * @param bufoff start point
    * @param count number of bytes to work on
    */
    private void OFB(byte[] buf, int bufoff, int count)
    {
	    int block = secret.getBlocksize();
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;
	    int index;

        /*  we start with the implicit zero IV originally defined in CipherInit()
            by zmalloc()ing the context; we encrypt this before XORing.  It would
            have been possible to use the first block of junk present in PGP's
            format as an IV, but this would not be meaningful for a stream cipher,
            and E(E(0))^Random should be random enough to avoid the known plaintext
            being used for an attack. */

	    if(reverse)
		    index = bufoff+count-1;
        else
		    index = bufoff;

	    while (count>0)
	    {
            if(0==buffered)
            {
            /* refresh the stream of bytes; for a real stream cypher, the
                block size is notional, but should be > 2 for architectural
                reasons */
                ECB1block(iv, 0, delay, 0, true);
                System.arraycopy(
                    delay, 0, iv, 0, block);
                buffered=(short) block;
            }

            buf[index] ^= iv[(reverse)? buffered-1
                                     : block-buffered];
            --(buffered);
            if(reverse) --index; else ++index;
            --count;
        }
    }

/*Cipher Block Chaining (CBC) mode support ***********************************/

    /**
    * CBB encrypts or decrypts 1 block
    * @param in input data array
    * @param offin starting point into array
    * @param out output data array
    * @param offout starting point into array
    * @param encrypt if true, use defined encryption, else decrypt
    */
    private void CBC1block(
    byte[] in, int offin, byte[] out, int offout, boolean encrypt)
    {
	    int block = secret.getBlocksize();
        if(encrypt) /* mask and encrypt the current block: */
        {
            xorbuf(in, offin, iv, 0, block);
            ECB1block(in, offin, out, offout, true);
		    /* update the mask: */
            System.arraycopy(out, offout, iv, 0, block);
        }
        else
        {
            byte[] temp = new byte[block];
            System.arraycopy(in, offin, temp, 0, block);
            ECB1block(in, offin, out, offout, false);
            xorbuf(out, offout, iv, 0, block);
            System.arraycopy(temp, 0, iv, 0, block);
            for(int i=0; i<temp.length; ++i) temp[i] = 0;
        }
    }

    /**
    * CBC en/decrypt the data
    * @param buf data to encrypt
    * @param bufoff start point
    * @param count number of bytes to work on
    * @return numbere of bytes emitted
    */
    private int CBC(byte[] buf, int bufoff, int count)
    {
	    int block = secret.getBlocksize();
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;
	    byte[] temp = new byte[block];
	    int chunksize;
	    int index, outdex;
        int retval = 0;


        /*  ensure first two blocks - or everything if < 2 blocks
            is buffered.  Then we can start working.  After an initial
            block or so, data comes in 0 or more large chunks, with
            perhaps a short tail.  Expect to have >1 and <= 2 blocks
            left buffered.
        */
        int totalBytes = buffered + count;
        int nblocks = totalBytes/block;
        nblocks = (totalBytes == nblocks * block) ?
               nblocks-2 : nblocks - 1;

        if(buffered < 2*block)
        {
            int need = 2*block - buffered;

            /* not enough left */
            if(count < need)
            {
                /* we expect this to happen for the first block (key protection) */
                /* or block+2 (encrypted message packet); and perhaps also for a */
                /* *very* short message */
                if(reverse)
                {
                    System.arraycopy(
                        buf, bufoff, delay, 2*block-(buffered+count), count);
                }
                else
                {
                    System.arraycopy(
                        buf, bufoff, delay, buffered, count);
                }
                buffered += (short) count;
                return 0;
            }


            if(reverse)
            {
                System.arraycopy(
                    buf, bufoff+count-need, delay, 0, need);
                index = bufoff+count-need-block;
                outdex = bufoff+block*nblocks;
            }
            else
            {
                System.arraycopy(
                    buf, bufoff, delay, buffered, need);
                index = bufoff+need;
                outdex = bufoff;
            }
            buffered = (short)(2*block);
            count -= need;
        }
	    else
        {
	        if(reverse)
                index = outdex = bufoff+block*nblocks;
	        else
		        outdex = index = bufoff;
        }

        while (count > 0)
        {
            int thisBlock = (reverse) ? block : 0;

            /* en/decrypt thisBlock into temp */
            CBC1block(delay, thisBlock, temp, 0, !decryp);

            /* shuffle delayed block along */
            if(reverse) System.arraycopy(
                delay, 0, delay, block, block);
            else System.arraycopy(
                delay, block, delay, 0, block);

            /* pull next (partial?) block of data from source array */
            chunksize = Math.min(count, block);
            if(reverse)
            {
                System.arraycopy(
                    buf, index, delay, block-chunksize, chunksize);
                if((index-bufoff) >= chunksize)index -= chunksize;
                else index = bufoff;
            }
            else
            {
                System.arraycopy(
                    buf, index, delay, block, chunksize);
                index += chunksize;
            }
            count -= chunksize;
            buffered += (short)(chunksize - block);

            /* put data into source array - assumes input buffer holds length
                rounded up to nearest block w/o problems */
            if(reverse)
            {
                System.arraycopy(temp, 0, buf, outdex-block, block);
                outdex -= block;
            }
            else
            {
                System.arraycopy(temp, 0, buf, outdex, block);
                outdex += block;
            }
            retval += block;
        } /* end while */
        return retval;
    }

    /**
    * Finish CBC by using cyphertext stealing on the final 1-2 blocks
    * @param buf where to put output data
    * @param bufoff start point
    * @return number of bytes emitted
    */
    private int CBC_CTS(byte[] buf, int bufoff)
    {
	    int block = secret.getBlocksize();
	    byte[] temp = new byte[block];
	    boolean reverse = (cypher.getMode() & REVERSE_FLAG) != 0;
        int leftover = buffered - block;

        //assert(context->buffered >= block);

        /* first simple case */
        if(buffered == block)
        {
            CBC1block(delay, (reverse?block:0),
                  buf, bufoff, !decryp);
            return block;
        }
        else if (buffered == 2*block && ! reverse)
        {
            CBC1block(delay, 0, buf, bufoff, !decryp);
            CBC1block(delay, block, buf, bufoff+block, !decryp);
            return 2*block;
        }
        else if (buffered == 2*block)
        {
            CBC1block(delay, block, buf, bufoff+block, !decryp);
            CBC1block(delay, 0, buf, bufoff, !decryp);
            return 2*block;
        }

        if(!decryp)
        {
            /* Encrypt whole block at appropriate end into temp... */
            CBC1block(delay, (reverse?block:0), temp, 0, true);

            /* Put the first leftover bytes at the end of the buffer */
            if(reverse) System.arraycopy(
                temp, block-leftover, buf, bufoff, leftover);
            else System.arraycopy(
                temp, 0, buf, block+bufoff, leftover);

            /* perform masking of leftover bytes, using temp */
            xorbuf(temp, (reverse?block-leftover:0),
                delay, block-(reverse?leftover:0),
             leftover);

            /* Encrypt that into place for output at start of buffer */
            ECB1block(temp, 0, buf, bufoff+(reverse?leftover:0), true);
        }
        else /* Decryption phase */
        {
            int i;
            /* Decrypt last, hybrid, block into buf */
            ECB1block(delay, (reverse?block:0), buf,
                bufoff+(reverse?leftover:0), false);
            /* Put leftover bytes into rest of output */
            if(reverse) System.arraycopy(
                delay, block-leftover, buf, bufoff, leftover);
            else System.arraycopy(
                delay, block, buf, bufoff+block, leftover);

		    for (i = 0; i < leftover; ++i)
            {
			    /* at this point, buf[i + block]  contains a cipherbyte C,
                and buf[i] contains the XOR of the same cipherbyte with
                the corresponding plainbyte P... And contrariwise for
                the reversed case */
                if(reverse) buf[bufoff+i+block] ^= (buf[bufoff+i]
                    ^= buf[bufoff+i+block]);
                else buf[bufoff+i] ^= (buf[bufoff+i + block]
                    ^= buf[bufoff+i]);
			    /* ... now buf[i] contains only the cipherbyte C, and */
			    /* buf[i + block] contains the plainbyte P, modulo reverse */
		    }

            /* Decrypt and unmask that block and replace it */
            ECB1block(buf, bufoff+(reverse?leftover:0), temp, 0, false);
            System.arraycopy(temp, 0, buf, bufoff+(reverse?leftover:0), block);
            xorbuf(buf, bufoff+(reverse?leftover:0), iv, 0, block);
        }
        return buffered;
    }
    /*****************************************************************************/
    /*
        Public interface : basic operations
    */
    /*****************************************************************************/
    /**
    * Constructor
    * @param cypher the algorithm and mode pair chosen (assumed valid)
    * @param key key material array (assumed long enough)
    * @param keyoff start of key material in array
    * @param decrypt sense of desired operation
    */
    public Cypher (Details cypher, byte[] key, int keyoff, boolean decrypt)
    {
        decryp = (decrypt && modeUsesDecrypt(cypher.getMode()));
	    boolean triple = (cypher.getMode() & TRIPLE_FLAG) != 0;

	    this.cypher = cypher;
        secret = getInstance((byte)(cypher.getAlg() & CEA_MASK));
        secret.init(key, keyoff, triple);

	    int block = secret.getBlocksize();
	    iv = new byte[block];
        for(int i=0; i<iv.length; ++i) iv[i] = 0;

        switch(cypher.getMode() & CEM_MASK)
        {
            case mCFB: /* No prep needed for these modes */
            case mECB:
                break;
            case mOFB: /* Encrypt the IV so that possibility of correlation */
            case mCBC: /* with ciphertext is avoided */
                delay = new byte[2*block];
                ECB1block(delay, 0, iv, 0, true);
            break;
        }
    }


    /**
    * Enciphers or deciphers count bytes in buf
    * @param buf  data
    * @param bufoff start point
    * @param count number of bytes input
    * @return number of bytes emitted
    */
    int op(byte[] buf, int bufoff, int count)
    {
	    switch (cypher.getMode() & CEM_MASK)
	    {
		    case mCFB: CFB(buf, bufoff, count); return count;
            case mECB: return ECB(buf, bufoff, count);
		    case mOFB: OFB(buf, bufoff, count); return count;
            case mCBC: return CBC(buf, bufoff, count);

		    default: break;
	    }
        return -1; /* compiler silencing */
    }

    /**
    * Terminates encryption, emitting any leftover bytes
    * @param buffer data
    * @param bufoff start point
    * @return number of bytes emitted
    */

    int end(byte[] buffer, int bufoff)
    {
        int buffered;

        /* do any ciphertext stealing required by the mode */
	    switch (cypher.getMode() & CEM_MASK)
	    {
            case mECB: buffered = ECB_CTS(buffer, bufoff);
                break;
            case mCBC: buffered = CBC_CTS(buffer, bufoff);
                break;

            /* modes not requiring CTS*/
		    default:  buffered = 0;
            break;
	    }

	    /*zap algorithm specific keyschedule data */
        secret.destroy();

	    /* repeat at next higher level */
        if(iv != null)
        {
            for(int ivi=0; ivi<iv.length; ++ivi) iv[ivi] = 0;
            iv = null;
        }
        if(delay != null)
        {
            for(int id=0; id<delay.length; ++id) delay[id] = 0;
            delay = null;
        }
        return buffered;
    }

    /**
    * interrogation of input lengths in bytes
    * @param cv_algor algorithm byte
    * @return bytes per block
    */
    static int cipherBlock(byte cv_algor)
    {
        if(!loaded) load();
        CEA temp = getInstance((byte)(cv_algor & CEA_MASK));
        return temp.getBlocksize();
    }

    /**
    * interrogation of key lengths in bytes
    * @param cv_algor algorithm byte
    * @return bytes in key
    */

    static int cipherKey(byte cv_algor)
    {
        if(!loaded) load();
        CEA temp = getInstance((byte)(cv_algor & CEA_MASK));
        return temp.getKeysize();
    }

    /**
    * interrogation of mode availability by algorithm
    * @param cv_mode mode byte
    * @param cv_algor algorithm byte
    * @return availability
    */

    static boolean isModeAvailable(byte cv_mode, byte cv_algor)
    {
        switch (cv_mode & CEM_MASK)
        {
            case mCFB: return true;
            /* unless using a hash, in which case only CFB mode will do */
            /* currently there are none */
            case mECB:
            case mOFB:
            case mCBC: return true;
            default: return false;
        }
    }

    /**
    * High-bit byte version of algorithm
    * @param cv_algor algorithm byte
    * @return alternative value
    */
    static byte flexAlg(byte cv_algor)
    {
        byte alg = (byte)(cv_algor & CEA_MASK);
        switch(alg)
        {
   	        case IDEAFLEX:
	        case EBP_IDEA:
   	        case IDEA: return IDEAFLEX;
            case TDESFLEX:
            case TDES: return TDESFLEX;
            case CAST5FLEX:
            case CAST5:return CAST5FLEX;
		    case BLOW20:
            case GPG_BLOW20: return BLOW20;
            case GPG_SAFERSK128:
            case SAFERSK128FLEX: return SAFERSK128FLEX;
            default: return 0;
        }
    }

    /**
    * non-High-bit byte version of algorithm
    * @param cv_algor algorithm byte
    * @return alternative value
    */
    static byte unflexAlg(byte cv_algor)
    {
        byte alg = (byte)(cv_algor & CEA_MASK);
        switch(alg)
        {
            case IDEA:
	        case EBP_IDEA:
   	        case IDEAFLEX: return IDEA;
            case TDES:
            case TDESFLEX: return TDES;
            case CAST5:
            case CAST5FLEX:return CAST5;
		    case BLOW20:
            case GPG_BLOW20: return GPG_BLOW20;
            case GPG_SAFERSK128:
            case SAFERSK128FLEX: return GPG_SAFERSK128;
            default: return 0;
        }
    }

    /**
    * Invoke the IDEA_licence method of any IDEA implementation
    * @return alternative value
    */
    public static String IDEA_licence()
    {
        if(!isAlgorithmAvailable(IDEA)) return "";
        try {
            Object o = cIDEA.newInstance();
            Class[] arg = new Class[0];
            java.lang.reflect.Method m = cIDEA.getDeclaredMethod(
                res.getString("IDEA_licence"), arg);
            return (String) m.invoke(null, arg);
        } catch (IllegalAccessException iae) {return "";}
        catch (java.lang.reflect.InvocationTargetException ite) {return "";}
        catch (NoSuchMethodException nsme) {return "";}
        catch (InstantiationException ie) {return "";}
    }
}
/* end of cipher.c */


