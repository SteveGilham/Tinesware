package com.ravnaandtines.crypt.cea;

/**
* <pre>
*  Class IDEA -
*	based upon idea.c - C source code for IDEA block cipher.
 *	IDEA (International Data Encryption Algorithm), formerly known as
 *	IPES (Improved Proposed Encryption Standard).
 *	Algorithm developed by Xuejia Lai and James L. Massey, of ETH Zurich.
 *	This implementation modified and derived from original C code
 *	developed by Xuejia Lai.
 *	Zero-based indexing added, names changed from IPES to IDEA.
 *	CFB functions added.  Random number routines added.
 *
 *  Optimized for speed 21 Oct 92 by Colin Plumb.
 *  Very minor speedup on 23 Feb 93 by Colin Plumb.
 *  idearand() given a separate expanded key on 25 Feb 93, Colin Plumb.
 *
 *	There are two adjustments that can be made to this code to
 *	speed it up.  Defaults may be used for PCs.  Only the -DIDEA32
 *	pays off significantly if selectively set or not set.
 *	Experiment to see what works better for you.
 *
 *	Multiplication: default is inline, -DAVOID_JUMPS uses a
 *		different version that does not do any conditional
 *		jumps (a few percent worse on a SPARC), while
 *		-DSMALL_CACHE takes it out of line to stay
 *		within a small on-chip code cache.
 *	Variables: normally, 16-bit variables are used, but some
 *		machines (notably RISCs) do not have 16-bit registers,
 *		so they do a great deal of masking.  -DIDEA32 uses "int"
 *		register variables and masks explicitly only where
 *		necessary.  On a SPARC, for example, this boosts
 *		performace by 30%.
 *
 *	The IDEA(tm) block cipher is covered by a patent held by ETH and a
 *	Swiss company called Ascom-Tech AG.  The Swiss patent number is
 *	PCT/CH91/00117.  International patents are pending. IDEA(tm) is a
 *	trademark of Ascom-Tech AG.  There is no license fee required for
 *	noncommercial use.  Commercial users may obtain licensing details
 *	from Dieter Profos, Ascom Tech AG, Solothurn Lab, Postfach 151, 4502
 *	Solothurn, Switzerland, Tel +41 65 242885, Fax +41 65 235761.
 *
 *	The IDEA block cipher uses a 64-bit block size, and a 128-bit key
 *	size.  It breaks the 64-bit cipher block into four 16-bit words
 *	because all of the primitive inner operations are done with 16-bit
 *	arithmetic.  It likewise breaks the 128-bit cipher key into eight
 *	16-bit words.
 *
 *	For further information on the IDEA cipher, see these papers:
 *	1) Xuejia Lai, "Detailed Description and a Software Implementation of
 *  	   the IPES Cipher", Institute for Signal and Information
 *   	   Processing, ETH-Zentrum, Zurich, Switzerland, 1991
 *	2) Xuejia Lai, James L. Massey, Sean Murphy, "Markov Ciphers and
 *   	   Differential Cryptanalysis", Advances in Cryptology- EUROCRYPT'91
 *
 *	This code assumes that each pair of 8-bit bytes comprising a 16-bit
 *	word in the key and in the cipher block are externally represented
 *	with the Most Significant Byte (MSB) first, regardless of the
 *	internal native byte order of the target CPU.
 * Modified 6 Mar 1996 by Heimdall to copy the IV rather than copying
 *   the pointer to the IV.
 *
 *   Modified 14 Apr 1996 by Mr. Tines to separate the CFB mode from the
 *   IDEA algorithm; add the NO_IDEA bracketing to allow simple compilation
 *   of patent-free option.  External routines are in the NO_IDEA case set
 *   to be no-ops.
 *
 *   Localise keyschedule deallocation with
 *   the allocation.  Mr. Tines 16-Feb-97
 *
 *   Java port Mr. Tines 16-Nov-1998
 * </pre>
* @author Mr. Tines
* @version 1.0 16-Nov-1998
 */

/*
Encryption key subblocks:
round 1:         1      2      3      4      5      6
round 2:         7      8   1024   1536   2048   2560
round 3:      3072   3584   4096    512     16     20
round 4:        24     28     32      4      8     12
round 5:     10240  12288  14336  16384   2048   4096
round 6:      6144   8192    112    128     16     32
round 7:        48     64     80     96      0   8192
round 8:     16384  24576  32768  40960  49152  57345
round 9:       128    192    256    320
Decryption key subblocks:
round 1:     65025  65344  65280  26010  49152  57345
round 2:     65533  32768  40960  52428      0   8192
round 3:     42326  65456  65472  21163     16     32
round 4:     21835  65424  57344  65025   2048   4096
round 5:     13101  51200  53248  65533      8     12
round 6:     19115  65504  65508  49153     16     20
round 7:     43670  61440  61952  65409   2048   2560
round 8:     18725  64512  65528  21803      5      6
round 9:         1  65534  65533  49153
 Encrypting 1024 KBytes (65536 blocks)...1.997 seconds = 525338 bytes per second


X      0        1       2       3
Y  52859    23597    6202   63282
T      0        1       2       3
Get    Cypher: af db be c8 35 45 b1 95
Expect Plain : 01 23 45 67 89 AB CD EF
Get    Plain : 01 23 45 67 89 ab cd ef

Key: 00 01 00 02 00 03 00 04 00 05 00 06 00 07 00 08
Expect Cypher: 11 fb ed 2b 01 98 6d e5
Get    Cypher: 11 fb ed 2b 01 98 6d e5
Expect Plain : 00 00 00 01 00 02 00 03
Get    Plain : 00 00 00 01 00 02 00 03

Key: 3a 98 4e 20 00 19 5d b3 2e e5 01 c8 c4 7c ea 60
Expect Cypher: 97 bc d8 20 07 80 da 86
Get    Cypher: 97 bc d8 20 07 80 da 86
Expect Plain : 01 02 03 04 05 06 07 08
Get    Plain : 01 02 03 04 05 06 07 08

Key: 00 64 00 c8 01 2c 01 90 01 f4 02 58 02 bc 03 20
Expect Cypher: 65 be 87 e7 a2 53 8a ed
Get    Cypher: 65 be 87 e7 a2 53 8a ed
Expect Plain : 05 32 0a 64 14 c8 19 fa
Get    Plain : 05 32 0a 64 14 c8 19 fa


Normal exit.
*/

public class IDEA implements CEA
{
    public IDEA()
    {
        destroy();
    }

    /**
    * Signal that the algorithm is included (a skeleton implementation
    * would have this routine return false, return a null licence string
    * and nothing else
    */
    public static boolean isAvailable()
    {
        return true;
    }

    /**
    * Evaluates the local end of line once
    */
    private static String NL = System.getProperty("line.separator");
    /**
    * Return the algorithm licencse as a string
    * @return IDEA licence
    */
    public static String IDEA_licence()
    { return
        "This Software/Hardware product contains the algorithm IDEA as described and "+
        "claimed in US Patent No. 5,214,703, EPO Patent No. 0482154 and filed "+
        "Japanese Patent Application No. 508119/1991 \"Device for the conversion of "+
        "a digital block and use of same\" (hereinafter referred to as \"Algorithm\"). "+
        "Any use of the Algorithm for Commercial Purposes is thus subject to a "+
        "license from Ascom Systec Ltd. of CH-5506 Mgenwil (Switzerland), being the "+
        "patentee and sole owner of all rights, including the term IDEA.  Commercial "+
        "Purposes shall mean any revenue generating purpose including but not limited "+
        "to" +NL+
        "i) using the Algorithm for company internal purposes (subject to a Site "+
        "License)." +NL+
        "ii) incorporating an application software containing the Algorithm into any "+
        "hardware and/or software and distributing such hardware and/or software "+
        "and/or providing services related thereto to others (subject to a Product "+
        "License)." +NL+
        "iii) using a product containing an application software that uses the "+
        "Algorithm (subject to an End-User License), except in case where such "+
        "End-User has acquired an implied license by purchasing the said product "+
        "from an authorized licensee or where the End-User has already signed up for "+
        "a Site License.  All such commercial license agreements are available "+
        "exclusively from Ascom Systec Ltd. and may be requested via the Internet "+
        "World Wide Web at http://www.ascom.ch/systec or by sending an electronic "+
        "mail to IDEA@ascom.ch. " +NL+
        "Any misuse will be prosecuted." +NL+
        "Use other than for Commercial Purposes is strictly limited to data transfer "+
        "between private individuals and not serving Commercial Purposes. The use by "+
        "government agencies, non-profit organizations etc. is considered as use for "+
        "Commercial Purposes but may be subject to special conditions. Requests for "+
        "waivers for non-commercial use (e.g. by software developers) are welcome. " +NL;
    }

    private static final int ROUNDS	= 8;		/* Don't change this value, should be 8 */
    private static final int KEYLEN	= (6*ROUNDS+4);	/* length of key schedule */

    private static class IDEAkey {
        short[] key = new short[KEYLEN];
        public void wipe() {for (int i=0; i<key.length; ++i) key[i] = 0;}
    }

    private static final int low16(int x)
    {
        return (x & 0xFFFF);
    }

    /*
    *	Compute multiplicative inverse of x, modulo (2**16)+1,
    *	using Euclid's GCD algorithm.  It is unrolled twice to
    *	avoid swapping the meaning of the registers each iteration,
    *	and some subtracts of t have been changed to adds.
    */
    private static final short inv(int xi)
    {
	    int t0, t1;
	    int q, y;
        int x = low16(xi);

	    if (x <= 1) return (short) x;	/* 0 and 1 are self-inverse */
	    t1 = low16(0x10001 / x);	/* Since x >= 2, this fits into 16 bits */
	    y = low16(0x10001 % x);
	    if (y == 1)
		    return (short) low16(1-t1);
	    t0 = 1;
	    do
	    {
            q = low16 (x / y);
		    x = low16 (x % y);
		    t0 += low16(q * t1);
            t0 = low16(t0);
		    if (x == 1)
			    return (short) t0;
		    q = low16(y / x);
		    y = low16(y % x);
		    t1 += low16(q * t0);
            t1 = low16(t1);
	    } while (y != 1);
	    return (short)low16(1-t1);
    } /* inv */

    /*	Compute IDEA encryption subkeys Z */
    private static void en_key_idea(short[] userkey, short[] Z)
    {
	    int i,j;
	    for (j=0; j<8; j++)
        {
		    Z[j] = userkey[j];
        }

        int z0 = 0;
	    for (i=0; j<KEYLEN; j++)
	    {
            i++;
		    Z[z0+i+7] = (short) low16(((Z[z0 + (i & 7)] << 9) |
                                       ((Z[z0 + (i+1 & 7)]&0xFFFF) >>> 7)));
		    z0 += i & 8;
		    i &= 7;
	    }
    }        /* en_key_idea */

    /*	Compute IDEA decryption subkeys DK from encryption subkeys Z */
    /* Note: these buffers *may* overlap! */
    static void de_key_idea(IDEAkey Z, IDEAkey DK)
    {
	    int j;
	    short t1, t2, t3;
	    IDEAkey T = new IDEAkey();
        int p = KEYLEN; //	uint16_t *p = T + KEYLEN;

        int z0 = 0;

	    t1 = inv(Z.key[z0++]);
	    t2 = (short) low16(-Z.key[z0++]);
	    t3 = (short) low16(-Z.key[z0++]);
    	T.key[--p] = inv(Z.key[z0++]);
	    T.key[--p] = t3;
	    T.key[--p] = t2;
	    T.key[--p] = t1;

	    for (j = 1; j < ROUNDS; j++)
	    {
		    t1 = Z.key[z0++];
		    T.key[--p] = Z.key[z0++];
		    T.key[--p] = t1;

		    t1 = inv(Z.key[z0++]);
		    t2 = (short)low16(-Z.key[z0++]);
		    t3 = (short)low16(-Z.key[z0++]);
		    T.key[--p] = inv(Z.key[z0++]);
		    T.key[--p] = t2;
		    T.key[--p] = t3;
		    T.key[--p] = t1;
	    }
	    t1 = Z.key[z0++];
	    T.key[--p] = Z.key[z0++];
	    T.key[--p] = t1;

	    t1 = inv(Z.key[z0++]);
	    t2 = (short)low16(-Z.key[z0++]);
	    t3 = (short)low16(-Z.key[z0++]);
	    T.key[--p] = inv(Z.key[z0++]);
	    T.key[--p] = t3;
	    T.key[--p] = t2;
	    T.key[--p] = t1;

        /* Copy and destroy temp copy */
	    for (j = 0; j < KEYLEN; j++)
	    {
		    DK.key[j] = T.key[j];
            T.key[j] = 0;
	    }
    } /* de_key_idea */

    /*
    * MUL(x,y) computes x = x*y, modulo 0x10001.
    */
    private static final short MUL(short a, short b)
    {
	    int  p;

	    if (a != 0)
	    {
            if (b != 0)
		    {
                p = low16(a) * low16(b);
			    b = (short) low16(p);
			    a = (short) low16(p>>16);
			    return (short)(b - a + (((b&0xFFFF) < (a&0xFFFF)) ? 1 : 0));
		    }
		    else
		    {
                return (short)(1-a);
		    }
	    }
	    else
	    {
            return (short)(1-b);
	    }
    }        /* mul */

    /*	IDEA encryption/decryption algorithm */
    /* Note that in and out can be the same buffer */
    private static final void cipher_idea(short[] in, short[] out, IDEAkey Z)
    {
	    short x1, x2, x3, x4, s2, s3;
    	int r = ROUNDS;

	    x1 = in[0];  x2 = in[1];
	    x3 = in[2];  x4 = in[3];
        int z0 = 0;

	    do
	    {
		    x1 = MUL(x1,Z.key[z0++]);
		    x2 += Z.key[z0++];
		    x3 += Z.key[z0++];
		    x4 = MUL(x4, Z.key[z0++]);

		    s3 = x3;
		    x3 ^= x1;
		    x3 = MUL(x3, Z.key[z0++]);
		    s2 = x2;
		    x2 ^= x4;
		    x2 += x3;
		    x2 = MUL(x2, Z.key[z0++]);
		    x3 += x2;

		    x1 ^= x2;
		    x4 ^= x3;
		    x2 ^= s3;
		    x3 ^= s2;
	    } while (--r > 0);
	    x1 = MUL(x1, Z.key[z0++]);

	    out[0] = x1;
	    out[1] = (short)low16(x3 + Z.key[z0++]);
	    out[2] = (short)low16(x2 + Z.key[z0++]);
	    x4 = MUL(x4, Z.key[z0++]);
	    out[3] = x4;
    } /* cipher_idea */

/*-------------------------------------------------------------*/

/*
 * This is the number of Kbytes of test data to encrypt.
 * It defaults to 1 MByte.
 */
    private static final int KBYTES = 1024;
    public static void main(String args[])
    {
        test();
    }
    public static void test()
    {	// Test driver for IDEA cipher
	    int i, j, k;
	    IDEAkey Z = new IDEAkey(), DK = new IDEAkey();
	    short[] XX = new short[4];
	    short[] TT = new short[4];
	    short[] YY = new short[4];
	    short[] userkey = new short[8];
	    long start, end;
	    long l;

	    /* Make a sample user key for testing... */
	    for(i=0; i<8; i++)
		    userkey[i] = (short)(i+1);

	    /* Compute encryption subkeys from user key... */
	    en_key_idea(userkey,Z.key);
	    System.out.println("Encryption key subblocks: ");
	    for(j=0; j<ROUNDS+1; j++)
	    {
		    System.out.print("round "+j+":   ");
		    if (j==ROUNDS)
			    for(i=0; i<4; i++)
				    System.out.print(" "+low16(Z.key[j*6+i]));
		    else
			    for(i=0; i<6; i++)
				    System.out.print(" "+low16(Z.key[j*6+i]));
            System.out.println("");
	    }

	    /* Compute decryption subkeys from encryption subkeys... */
	    de_key_idea(Z,DK);
	    System.out.println("\nDecryption key subblocks: ");
	    for(j=0; j<ROUNDS+1; j++)
	    {
		    System.out.print("round "+j+":   ");
		    if (j==ROUNDS)
			    for(i=0; i<4; i++)
				    System.out.print(" "+low16(DK.key[j*6+i]));
    		else
	    		for(i=0; i<6; i++)
				    System.out.print(" "+low16(DK.key[j*6+i]));
            System.out.println("");
	    }

	    /* Make a sample plaintext pattern for testing... */
	    for (k=0; k<4; k++)
		    XX[k] = (short)k;

        int bk = KBYTES*64;
	    System.out.println(" Encrypting "+KBYTES+" KBytes ("+bk+" blocks)...");
	    start = System.currentTimeMillis();
	    cipher_idea(XX,YY,Z);       // encrypt plaintext XX, making YY
	    for (l = 1; l < bk; l++)
		    cipher_idea(YY,YY,Z);	// repeated encryption
	    cipher_idea(YY,TT,DK);      // decrypt ciphertext YY, making TT
	    for (l = 1; l < bk; l++)
		    cipher_idea(TT,TT,DK);	// repeated decryption
	    end = System.currentTimeMillis() - start;
        double dd = end/1000.0;
        double rate = KBYTES/dd;
	    System.out.println(""+dd+" seconds = "+rate+" kbytes per second");
        System.out.println(" "+low16(XX[0])+"  "+low16(XX[1])
        +"  "+low16(XX[2])+"  "+low16(XX[3]));
        System.out.println(" "+low16(YY[0])+"  "+low16(YY[1])
        +"  "+low16(YY[2])+"  "+low16(YY[3]));
        System.out.println(" "+low16(TT[0])+"  "+low16(TT[1])
        +"  "+low16(TT[2])+"  "+low16(TT[3]));

	    // Now decrypted TT should be same as original XX
	    for (k=0; k<4; k++)
		    if (TT[k] != XX[k])
		    {
			    System.out.println("Error!  Noninvertable encryption.");
			    System.exit(-1);	/* error exit */
		    }
        {
            IDEA keysched = new IDEA();
	        byte[][] key =
                {{0x01, 0x23, 0x45, 0x67, 0x12, 0x34, 0x56, 0x78,
                  0x23, 0x45, 0x67, (byte)0x89, 0x34, 0x56, 0x78, (byte)0x9A},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x3a, (byte)0x98, 0x4e, 0x20, 0x00, 0x19, 0x5d, (byte)0xb3,
                  0x2e, (byte)0xe5, 0x01, (byte)0xc8, (byte)0xc4, 0x7c, (byte)0xea, 0x60},
                 {0x00, 0x64, 0x00, (byte)0xc8, 0x01, 0x2c, 0x01, (byte)0x90,
                 0x01, (byte)0xf4, 0x02, 0x58, 0x02, (byte)0xbc, 0x03, 0x20},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04,
                  0x00, 0x05, 0x00, 0x06, 0x00, 0x07, 0x00, 0x08},
                 {0x00, 0x05, 0x00, 0x0A, 0x00, 0x0F, 0x00, 0x14,
                  0x00, 0x19, 0x00, 0x1E, 0x00, 0x23, 0x00, 0x28},
                 {0x3A, (byte)0x98, 0x4E, 0x20, 0x00, 0x19, 0x5D, (byte)0xB3,
                  0x2E, (byte)0xE5, 0x01, (byte)0xC8, (byte)0xC4, 0x7C, (byte)0xEA, 0x60},
                 {0x00, 0x64, 0x00, (byte)0xC8, 0x01, 0x2C, 0x01, (byte)0x90,
                  0x01, (byte)0xF4, 0x02, 0x58, 0x02, (byte)0xBC, 0x03, 0x20},
                 {(byte)0x9D, 0x40, 0x75, (byte)0xC1, 0x03, (byte)0xBC, 0x32, 0x2A,
                  (byte)0xFB, 0x03, (byte)0xE7, (byte)0xBE, 0x6A, (byte)0xB3, 0x00, 0x06}
            };
   	        byte[][] in =
            {{0x01, 0x23, 0x45, 0x67, (byte)0x89, (byte)0xAB, (byte)0xCD, (byte)0xEF},
             {0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03},
             {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08},
             {0x05, 0x32, 0x0a, 0x64, 0x14, (byte)0xc8, 0x19, (byte)0xfa},
             {0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03},
             {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08},
             {0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, (byte)0x96, (byte)0xAF},
             {(byte)0xF5, 0x20, 0x2D, 0x5B, (byte)0x9C, 0x67, 0x1B, 0x08},
             {(byte)0xFA, (byte)0xE6, (byte)0xD2, (byte)0xBE, (byte)0xAA, (byte)0x96, (byte)0x82, 0x6E},
             {0x0A, 0x14, 0x1E, 0x28, 0x32, 0x3C, 0x46, 0x50},
             {0x05, 0x0A, 0x0F, 0x14, 0x19, 0x1E, 0x23, 0x28},
             {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08},
             {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08},
             {0x05, 0x32, 0x0A, 0x64, 0x14, (byte)0xC8, 0x19, (byte)0xFA},
             {0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08}
            };
   	        byte[][] out =
            {{(byte)0xaf, (byte)0xdb, (byte)0xbe, (byte)0xc8, 0x35, 0x45, (byte)0xb1, (byte)0x95},
             {0x11, (byte)0xfb, (byte)0xed, 0x2b, 0x01, (byte)0x98, 0x6d, (byte)0xe5},
             {(byte)0x97, (byte)0xbc, (byte)0xd8, 0x20, 0x07, (byte)0x80, (byte)0xda, (byte)0x86},
             {0x65, (byte)0xbe, (byte)0x87, (byte)0xe7, (byte)0xa2, 0x53, (byte)0x8a, (byte)0xed},
             {0x11, (byte)0xFB, (byte)0xED, 0x2B, 0x01, (byte)0x98, 0x6D, (byte)0xe5},
             {0x54, 0x0E, 0x5F, (byte)0xEA, 0x18, (byte)0xC2, (byte)0xF8, (byte)0xB1},
             {(byte)0x9F, 0x0A, 0x0A, (byte)0xB6, (byte)0xE1, 0x0C, (byte)0xED, 0x78},
             {(byte)0xCF, 0x18, (byte)0xFD, 0x73, 0x55, (byte)0xE2, (byte)0xC5, (byte)0xC5},
             {(byte)0x85, (byte)0xDF, 0x52, 0x00, 0x56, 0x08, 0x19, 0x3D},
             {0x2F, 0x7D, (byte)0xE7, 0x50, 0x21, 0x2F, (byte)0xB7, 0x34},
             {0x7B, 0x73, 0x14, (byte)0x92, 0x5D, (byte)0xE5, (byte)0x9C, 0x09},
             {0x3E, (byte)0xC0, 0x47, (byte)0x80, (byte)0xBE, (byte)0xFF, 0x6E, 0x20},
             {(byte)0x97, (byte)0xBC, (byte)0xD8, 0x20, 0x07, (byte)0x80, (byte)0xDA, (byte)0x86},
             {0x65, (byte)0xBE, (byte)0x87, (byte)0xE7, (byte)0xA2, 0x53, (byte)0x8A, (byte)0xED},
             {(byte)0xF5, (byte)0xDB, 0x1A, (byte)0xC4, 0x5E, 0x5E, (byte)0xF9, (byte)0xF9}
            };

            byte[] work = new byte[8];
            byte[] back = new byte[8];
            for (int i2=0; i2<15; ++i2)
            {
            keysched.init(key[i2], 0, false);
            keysched.ecb(true, in[i2], 0, work, 0);

            System.out.println("Expect Cypher: "+
            Integer.toHexString(out[i2][0]&0xFF)+" "+
            Integer.toHexString(out[i2][1]&0xFF)+" "+
            Integer.toHexString(out[i2][2]&0xFF)+" "+
            Integer.toHexString(out[i2][3]&0xFF)+" "+
            Integer.toHexString(out[i2][4]&0xFF)+" "+
            Integer.toHexString(out[i2][5]&0xFF)+" "+
            Integer.toHexString(out[i2][6]&0xFF)+" "+
            Integer.toHexString(out[i2][7]&0xFF));
 	        System.out.println("Get    Cypher: "+
            Integer.toHexString(work[0]&0xFF)+" "+
            Integer.toHexString(work[1]&0xFF)+" "+
            Integer.toHexString(work[2]&0xFF)+" "+
            Integer.toHexString(work[3]&0xFF)+" "+
            Integer.toHexString(work[4]&0xFF)+" "+
            Integer.toHexString(work[5]&0xFF)+" "+
            Integer.toHexString(work[6]&0xFF)+" "+
            Integer.toHexString(work[7]&0xFF));

            keysched.ecb(false, work, 0, back, 0);
    	    System.out.println("Expect Plain : "+
            Integer.toHexString(in[i2][0]&0xFF)+" "+
            Integer.toHexString(in[i2][1]&0xFF)+" "+
            Integer.toHexString(in[i2][2]&0xFF)+" "+
            Integer.toHexString(in[i2][3]&0xFF)+" "+
            Integer.toHexString(in[i2][4]&0xFF)+" "+
            Integer.toHexString(in[i2][5]&0xFF)+" "+
            Integer.toHexString(in[i2][6]&0xFF)+" "+
            Integer.toHexString(in[i2][7]&0xFF));
 	        System.out.println("Get    Plain : "+
            Integer.toHexString(back[0]&0xFF)+" "+
            Integer.toHexString(back[1]&0xFF)+" "+
            Integer.toHexString(back[2]&0xFF)+" "+
            Integer.toHexString(back[3]&0xFF)+" "+
            Integer.toHexString(back[4]&0xFF)+" "+
            Integer.toHexString(back[5]&0xFF)+" "+
            Integer.toHexString(back[6]&0xFF)+" "+
            Integer.toHexString(back[7]&0xFF));

            keysched.destroy();
            }
	    }

	        System.out.println("Normal exit.");
    }        /* main */


    private boolean triple;
    private IDEAkey[] ks = null;

    /**
    * Initialise the object with one or three key blocks
    * @param key array of key bytes, 1 or 3 key block lengths
    * @param triple true if three keys for triple application
    */
    public void init(byte[] key, int offset, boolean triple)
    {
	    short [] userkey = new short [getKeysize()/2];
	    int i,k;
	    int keys = triple ? 3 : 1;
        ks = new IDEAkey[2*keys];

        int k0 = 0;
	    for(k=0; k<keys; k++)
	    {
		    /* Assume each pair of bytes comprising a word is ordered MSB-first. */
		    for (i=0; i<(getKeysize()/2); i++)
		    {
			    userkey[i] = (short)((key[k0]<<8) + (key[k0+1]&0xFF));
			    k0 += 2;
		    }
            ks[2*k] = new IDEAkey();
		    en_key_idea(userkey,ks[2*k].key);
            ks[1+2*k] = new IDEAkey();
		    de_key_idea(ks[2*k],ks[1+2*k]);	/* compute inverse key schedule DK */
	    }

	    for (i=0; i<(getKeysize()/2); i++)	/* Erase dangerous traces */
		    userkey[i] = 0;
    } /* initkey_idea */

    /**
    * Transform one block in ecb mode
    * @param encrypt true if forwards transformation
    * @param in input block
    * @param offin offset into block of input data
    * @param out output block
    * @param offout offset into block of output data
    */
    public void ecb(boolean encrypt, byte[] in, int offin,
        byte[] out, int offout)
    {
    	int keys = (triple) ? 3 : 1;
	    int i;

	    short[] sin = new short[getBlocksize()/2];
	    short[] sout = new short[getBlocksize()/2];

        int sked = encrypt ? 0 : (triple? 5 : 1);
        int delta = encrypt ? 2 : -2;


        for(int iin=0; iin<getBlocksize()/2; ++iin)
        {
            sin[iin] = (short)((in[offin+2*iin]<<8) + (0xFF&in[offin+2*iin+1]));
        }
        for(i=0; i<keys; ++i)
        {
            cipher_idea(sin, sout, ks[sked]);
            sked += delta;
            System.arraycopy(sout, 0, sin, 0, sin.length);
        }
        for(int iout=0; iout<getBlocksize()/2; ++iout)
        {
            out[offin+2*iout] = (byte)((sout[iout]>>>8) &0xFF);
            out[offin+2*iout+1] = (byte)(sout[iout] & 0xFF);
        }
    }

    /**
    * Wipe key schedule information
    */
    public void destroy()
    {
        if(ks == null) return;
        for(int i=0; i<ks.length; ++i) ks[i].wipe();
    }

    /**
    * Provide infomation of desired key size
    * @return byte length of key
    */
    public int getKeysize() {return 16;}

    /**
    * Provide infomation of algorithm block size
    * @return byte length of block
    */
    public int getBlocksize() {return 8;}


}
