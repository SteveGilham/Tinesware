package com.ravnaandtines.crypt.cea;

/**
*  Class Details - algorithm+mode pairing
*  <P>
*  <P>
*  Coded Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
* @author Mr. Tines
* @version 1.0 23-Dec-1998
*/


public class Details
{
    /**
    * Algorithm marker
    */
    private byte alg = Cypher.IDEA;
    /**
    * Mode marker
    */
    private byte mode = 0;

    /**
    * Default constructor (PGP2.6 standard)
    */
    public Details()
    {
    }

    /**
    * Specific constructor
    * @param alg Algorithm marker
    * @param mode Mode marker
    */
    public Details(byte alg, byte mode)
    {
        this.alg = alg;
        this.mode = mode;
    }

    /**
    * Gets algorithm marker
    * @return algorithm
    */
    public byte getAlg()
    {
        return alg;
    }

    /**
    * Gets mode marker
    * @return mode
    */
    public byte getMode()
    {
        return mode;
    }

    /**
    * Sets algorithm marker
    * @param alg algorithm marker
    */
    public void setAlg(byte alg)
    {
        this.alg = alg;
    }

    /**
    * Sets mode marker
    * @param mode mode marker
    */
    public void setMode(byte mode)
    {
        this.mode = mode;
    }
}