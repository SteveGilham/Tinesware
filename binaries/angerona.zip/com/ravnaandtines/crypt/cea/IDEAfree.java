/**
*  Class IDEAfree
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
*  This is a no-op used as a placeholder for the actual algorithm -
*  the actual IDEA class will be in a separate jar file.
* <p>
* @author Mr. Tines
* @version 1.0 17-Nov-1998
*
*/

package com.ravnaandtines.crypt.cea;

public class IDEAfree implements CEA
{
    public IDEAfree()
    {
        destroy();
    }

    /**
    * Signal that the algorithm is included (a skeleton implementation
    * would have this routine return false, return a null licence string
    * and nothing else
    */
    public static boolean isAvailable()
    {
        return false;
    }

    /**
    * Return the algorithm licencse as a string
    * @return IDEA licence
    */
    public static String IDEA_licence()
    { return ""; }
    /**
    * Initialise the object with one or three key blocks
    * @param key array of key bytes, 1 or 3 key block lengths
    * @param triple true if three keys for triple application
    */
    public void init(byte[] key, int offset, boolean triple)
    {
    }

    /**
    * Transform one block in ecb mode
    * @param encrypt true if forwards transformation
    * @param in input block
    * @param offin offset into block of input data
    * @param out output block
    * @param offout offset into block of output data
    */
    public void ecb(boolean encrypt, byte[] in, int offin,
        byte[] out, int offout)
    {
	System.arraycopy(in, offin, out, offout, getBlocksize());
    }

    /**
    * Wipe key schedule information
    */
    public void destroy()
    {
    }

    /**
    * Provide infomation of desired key size
    * @return byte length of key
    */
    public int getKeysize() {return 16;}

    /**
    * Provide infomation of algorithm block size
    * @return byte length of block
    */
    public int getBlocksize() {return 8;}


}
