package com.ravnaandtines.crypt.mda;

import java.util.*;

/**
*  Class Hash - factory class for hash algorithms.
*  <P>
*  Coded Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
* @author Mr. Tines
* @version 1.0 23-Dec-1998
*/

public class Hash
{
    /**
    * Algorithm class bundle
    */
    private static ResourceBundle res =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.mda.MDAClasses");
    /**
    * Algorithm tags bundle
    */
    private static ResourceBundle res1 =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.mda.MDATags");
    /**
    * Indicates my unofficial algorithm values
    */
    public static final byte FLEX_FLAG = (byte)0x80;
    /**
    * Strips off algorithm flag
    */
    public static final byte MASK  = 127;			/* as CEA_MASK */

    /**
    * MD5 message digest algorithm - PGP 2.x value
    */
    public static final byte MD5 =           1;
    private static Class cMD5 = null;
    /**
    * PGP5 code for SHA-1
    */
    public static final byte PGP5_SHA1 =	2;
    private static Class cSHA1 = null;
    /**
    * PGP5 code for RIPEM-160
    */
    public static final byte PGP5_RIPEM160 = 3;
    private static Class cPGP5_RIPEM160 = null;

    /**
    * EBP Haval basic value
    */
    public static final byte EBP_HAVAL = 97;
    private static Class cEBP_HAVAL = null;

    /**
    * EBP allows this range for 15 varieties of HAVAL
    */
    public static final byte EBP_HAVAL_MAX = 111;

    /**
    * 3-way used to produce 96 bit hash
    */
    public static final byte TWAY = (byte)(2|FLEX_FLAG);
    public static final Class cTWAY = null;
    /**
    * the original NIST SHA 160bit hash (SHA-0
    */
    public static final byte SHA =  (byte)(3|FLEX_FLAG);
    private static Class cSHA = null;
    /**
    * SHA-1 modification (but use PGP5_SHA1 for preference)
    */
    public static final byte SHA1 = (byte)(4|FLEX_FLAG);

    public static final byte HAVAL_MIN = (byte)(5|FLEX_FLAG);
    public static final byte HAVAL_MAX = (byte)(19|FLEX_FLAG);

    /**
    * MD4 message digest algorithm
    */
    public static final byte MD4 = (byte)(20|FLEX_FLAG);
    public static Class cMD4 = null;

    /**
    * MD2 message digest algorithm
    */
    public static final byte MD2 = (byte)(21|FLEX_FLAG);
    public static Class cMD2 = null;

    /**
    * Have we read the algorithm classes?
    */
    private static boolean loaded = false;

    /**
    * All static, so no sense instantiating
    */
    private Hash()
    {
    }

    /**
    * Serves up a descriptive string for the algorithm
    * @param alg the algorithm on which to report
    * @param full true if you want the long form
    * @return the description string
    */
    public static String getAlgName(byte mode, boolean full)
    {
        boolean brief = !full;
        switch(mode)
        {
            case MD2: return brief ? res1.getString("MD2") : res1.getString("MD2_Message_Digest_2_");
            case MD4: return brief ? res1.getString("MD4") : res1.getString("MD4_Message_Digest_4_");
            case MD5: return brief ? res1.getString("MD5") : res1.getString("MD5_Message_Digest_5_");
            case PGP5_SHA1: return brief ? res1.getString("SHA1P") : res1.getString("NIST_SHA_Secure_Hash");
            case PGP5_RIPEM160: return brief ? res1.getString("RIPEM") : res1.getString("RIPEM_160_bit");
            case EBP_HAVAL: return brief ? res1.getString("HAVALE") : res1.getString("HAVAL_variant_EBP_");
            case TWAY: return brief ? res1.getString("3WAY") : res1.getString("3way_used_to_produce");
            case SHA: return brief ? res1.getString("SHA0") : res1.getString("NIST_SHA_original");
            case SHA1: return brief ? res1.getString("SHA1") : res1.getString("NIST_SHA_Secure_Hash1");
            default: return brief ? res1.getString("UNKNOWN") : res1.getString("Unknown_message");
        }
    }

    /**
    * returns an instance of the desired hash
    * @param mda byte code indicating algorithm
    */
    public static MDA getInstance(byte mda)
    {
        if(!loaded) load();

        switch (mda)
        {
            case PGP5_SHA1:
            case SHA1:
                return build(cSHA1);
            case MD2:
                return build(cMD2);
            case MD4:
                return build(cMD4);
            case MD5:
                return build(cMD5);
            case SHA:
                return build(cSHA);
            case PGP5_RIPEM160:
                return build(cPGP5_RIPEM160);
            case TWAY:
                return build(cTWAY);
            case EBP_HAVAL:
                return build(cEBP_HAVAL);
        }
        return null;
    }

    /**
    * returns an instance of the desired hash
    * @param c class indicating algorithm
    */
    private static MDA build(Class c)
    {
        if(null == c) return null;
        try {
            return (MDA) c.newInstance();
        } catch (IllegalAccessException iae) {}
        catch (InstantiationException ie) {}
        return null;
    }

    /**
    * Tells us if the indicated algorithm has been found
    * @param mda byte code indicating algorithm
    */
    public static boolean isAvailable(byte mda)
    {
        if(!loaded) load();

        switch (mda)
        {
            case PGP5_SHA1:
            case SHA1:
                return cSHA1 != null;
            case MD2:
                return cMD2 != null;
            case MD4:
                return cMD4 != null;
            case MD5:
                return cMD5 != null;
            case SHA:
                return cSHA != null;
            case PGP5_RIPEM160:
                return cPGP5_RIPEM160 != null;
            case TWAY:
                return cTWAY != null;
            case EBP_HAVAL:
                return cEBP_HAVAL != null;
        }
        return false;
    }

    /**
    * finds a Class for each of the algorithms of interest if possible
    */
    private static synchronized void load()
    {
        if(loaded) return;
        cMD2 = find("MD2");
        cMD4 = find("MD4");
        cMD5 = find("MD5");
        cSHA1 = find("SHA1");
        cSHA = find("SHA");
        cPGP5_RIPEM160 = find("RIPEM160");
        cEBP_HAVAL=find("HAVAL");
        loaded = true;
    }

    /**
    * finds a Class for the named algorithm (the name is keyed
    * from a resource value), ensuring that it implements MDA
    */
    private static Class find(String name)
    {
        Class result = null;
        try {
            result = Class.forName(res.getString(name));
        } catch ( MissingResourceException mre) { return null;}
        catch ( ClassNotFoundException cnfe) { return null;}
        if(null == result) return null;

        Class [] ifs = result.getInterfaces();
        for(int i=0; i<ifs.length; ++i)
        {
            if(ifs[i] == MDA.class) return result;
        }
        return null;
    }
}