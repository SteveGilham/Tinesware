package com.ravnaandtines.crypt.pka;

import com.ravnaandtines.openPGP.packet.*;
import com.ravnaandtines.util.io.*;
import java.util.*;

/**
*  Class PKCypher
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* Values derived from the OpenPGP internet draft
* <p>
* @author Mr. Tines
* @version 1.0 11-Nov-1998
*
*/


public class PKCypher
{
    /**
    * Algorithm class bundle
    */
    private static ResourceBundle res =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.pka.PKAClasses");
    /**
    * Algorithm tags bundle
    */
    private static ResourceBundle res1 =
        ResourceBundle.getBundle("com.ravnaandtines.crypt.pka.PKATags");
    /**
    * Public key encryption algorithm selector bytes.
    * This is probably wrong.  There should probably be separate selectors
    * for key exchange and authentication algorithm (many cannot be used
    * for both)
    * perhaps should have PKE_&lt;alg&gt; and PKS_&lt;alg&gt; for encrypt
    * and sign
    */

    public static final int[] RSA_SHA1_ASN = {
      -1, 0x30213009, 0x06052b0e, 0x03021a05, 0x00041400};
    public static final int[] RSA_MD5_ASN = {
      -2, 0x3020300c, 0x06082a86, 0x4886f70d, 0x02050500, 0x04100000};
    public static final int[] RSA_RIPEMD_160_ASN = {
      -1, 0x30213009, 0x06052b24, 0x03020105, 0x00041400};

    /**
    * Bit flag value to indicate out-of-specification CTC algorithm
    */
    public static final byte FLEX_FLAG       =   (byte)0x80;
    /**
    * PGP standard RSA
    */
    public static final byte RSA             =   1;
    private static Class cRSA = null;
    /**
    * Viacrypt deprecated RSA with use restriction - read only
    */
    public static final byte RSA_ENCRYPT_ONLY =  2;
    /**
    * Viacrypt deprecated RSA with use restriction - read only
    */
    public static final byte RSA_SIGN_ONLY   =   3;
    /**
    * PGP5 code for ElGamal/Diffie-Hellman encrypt only
    */
    public static final byte ELGAMAL	     =	16;
    private static Class cELGAMAL = null;
    /**
    * PGP5 code for DSA
    */
    public static final byte DSA             =   17;
    private static Class cDSA = null;
    /**
    * openPGP5 reserved code for elliptic curve
    */
    public static final byte EC              =   18;
    private static Class cEC = null;
    /**
    * openPGP5 reserved code for ECDSA
    */
    public static final byte ECDSA           =   19;
    private static Class cECDSA = null;
    /**
    * openPGP5 reserved code for dual use ElGamal
    */
    public static final byte DUAL_ELGAMAL    =   20;
    private static Class cDUAL_ELGAMAL = null;
    /**
    * openPGP5 reserved code for Diffie Hellman (X9.42, as in IETF-S/MIME)
    */
    public static final byte DH              =   21;
    private static Class cDH = null;
    /**
    * EBP code for RSA in conjunction with another algorithm - read only
    * This value does not honour the OpenPGP standard
    */
    public static final byte EBP_RSA         = 86;
    /**
    * EBP code for Rabin
    * This value does not honour the OpenPGP standard
    */
    public static final byte EBP_RABIN       = 97;
    private static Class cRABIN = null;
    /**
    * CTC code for elliptic curve on GF(2^255)
    * This value does not honour the OpenPGP standard
    */
    public static final byte GF2255          = (byte)(1|FLEX_FLAG);
    private static Class cGF2255 = null;

    /**
    * Have we read the algorithm classes?
    */
    private static boolean loaded = false;

    /**
    * Tells if we know what the algorithm is
    * @param b algorithm identifier byte
    * @return true if b is one of the above
    */
    public static boolean isRecognised(byte b)
    {
        return (b>=1 && b<=3) ||
        (b>=16 && b<=21) || b==EBP_RSA ||
        b==EBP_RABIN || b==GF2255;
    }

    /**
    * Tells the number of MPIs in the algorithm's public key encrypted
    * packets
    * @param b algorithm identifier byte
    * @return number or -1 if the number is not known
    */
    public static int pkeMPIs(byte b)
    {
        switch(b)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY: // this one technically illegal
                return 1;
            case ELGAMAL:
                return 2;
            case DSA:  // I think this one not sane
                return -1;
            case EC:
            case ECDSA:
            case DUAL_ELGAMAL:
            case DH :
                return -1;
            case EBP_RSA:
                return 1;
            case EBP_RABIN:
                return -1;
            case GF2255:
                return 2;
        }
        return -1;
    }

    /**
    * Tells the significant MPI of those in the algorithm's public key packets
    * @param b algorithm identifier byte
    * @return number or -1 if the number is not known
    */
    public static int pkeCharacteristicMPI(byte b)
    {
        switch(b)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
                return 0;
            case ELGAMAL:
                return 2;
            case DSA:
                return 3;
            case EC:
            case ECDSA:
            case DUAL_ELGAMAL:
            case DH :
                return -1;
            case EBP_RSA:
                return 0;
            case EBP_RABIN:
                return -1;
            case GF2255:
                return 0;
        }
        return -1;
    }

    public static int sizePubkey(byte alg, byte[][] nums)
    {
	    int offset = pkeCharacteristicMPI(alg);
	    switch (alg)
        {
            case GF2255:
      	        return 240; /*leading zeroes count, though are not stored */

		    default:
			if(offset >= 0)
            {
                return length_mpn(nums[offset]);
            }
        }
        return 0;
    }

    public static int length_mpn(byte[] n)
    {
        // recover bit length
        int l = 8*n.length;
        int i = 7;
        while(0 == ((1<<i)&n[0]) )
        {
            --l;
            --i;
        }
        return l;
    }

    public static boolean read_mpn_summary(byte alg, KeySummary summary, Read file)
    throws java.io.IOException
    {
	    byte[] n = null;
	    int count = pkeCharacteristicMPI(alg) + 1;

	    while(count-- > 0)
        {
            n = file.readMPI();
            if(null == n) return false;
        }

	    switch (alg)
        {
		    case RSA:
		    case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
            case EBP_RSA:
            {
		        summary.setKeyID(n);
      	        summary.setSize(length_mpn(n));
            }
      	    break;

            case GF2255:
		        summary.setKeyID(n);
      	        summary.setSize(240);
            break;

            default:
		        summary.setKeyID(null);
      	        summary.setSize(0);
            break;
        }
        return true;
    }

//int	PKEsize(byte algor, PKEsizeParam purpose)
//{							/* PUB_SIZE 	SEC_SIZE		CIPH_SIZE	SIG_SIZE		CHAR_NUM */

//	static const PKEparams rsa		= {	2,		4,			1,		1,				0 };
//	static const PKEparams ec		= {	1,		1,			2,		2,				0 };
//	static const PKEparams elgamal	= {	3,		1,			2,		2,				2 };
//	static const PKEparams dsa		= {	4,		1,			2,		2,				3 };
//	static const PKEparams maxima	= {	MAXPUBNUMS,	MAXSECNUMS,	MAXCYPHNUMS, MAXSIGNUMS,	MAXPUBNUMS-1 };
    public static int sigSize(byte alg)
    {
        switch(alg)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
                return 1;
            case ELGAMAL:
                return 2;
            case DSA:
                return 2;
            case EC:
            case ECDSA:
            case DUAL_ELGAMAL:
            case DH :
                return -1;
            case EBP_RSA:
                return 1;
            case EBP_RABIN:
                return -1;
            case GF2255:
                return 2;
        }
        return -1;
    }
    public static int secSize(byte alg)
    {
        switch(alg)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
                return 4;
            case ELGAMAL:
                return 1;
            case DSA:
                return 1;
            case EC:
            case ECDSA:
            case DUAL_ELGAMAL:
            case DH :
                return -1;
            case EBP_RSA:
                return 4;
            case EBP_RABIN:
                return -1;
            case GF2255:
                return 1;
        }
        return -1;
    }
    public static int pubSize(byte alg)
    {
        switch(alg)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
                return 2;
            case ELGAMAL:
                return 3;
            case DSA:
                return 4;
            case EC:
            case ECDSA:
            case DUAL_ELGAMAL:
            case DH :
                return -1;
            case EBP_RSA:
                return 2;
            case EBP_RABIN:
                return -1;
            case GF2255:
                return 1;
        }
        return -1;
    }

    public static byte[][] read_mpn_pubkey(byte alg, Read file)
    throws java.io.IOException
    {
	    int Nnums = pubSize(alg);
        int offset = -1;

	    if(Nnums >= 0)
	    {
            byte[][] result = new byte[Nnums][];
		    while(++offset < Nnums)
            {
                result[offset] = file.readMPI();
            }
            return result;
        }
        return null;
    }

    public static byte[][] read_mpn_signature(byte alg, Read file)
    throws java.io.IOException
    {
	    int Nnums = sigSize(alg);
        int offset = -1;

	    if(Nnums >= 0)
	    {
            byte[][] result = new byte[Nnums][];
		    while(++offset < Nnums)
            {
                result[offset] = file.readMPI();
            }
            return result;
        }
        return null;
    }

    /**
    * Serves up a descriptive string for the algorithm
    * @param alg the algorithm on which to report
    * @param full true if you want the long form
    * @return the description string
    */
    public static String getName(byte alg, boolean full)
    {
        boolean brief = !full;
        switch(alg)
        {
            case RSA: return brief ? res1.getString("RSA") : res1.getString("RSA_Rivest_Shamir");
            case RSA_ENCRYPT_ONLY: return brief ? res1.getString("RSA_ENCR") : res1.getString("RSA_encryption_only");
            case RSA_SIGN_ONLY: return brief ? res1.getString("RSA_SIGN") : res1.getString("RSA_signature_only");
            case ELGAMAL: return brief ? res1.getString("ELGAMAL") : res1.getString("ElGamal_Diffie");
            case DSA: return brief ? res1.getString("DSA") : res1.getString("DSA_Digital_Signature");
            case EBP_RSA: return brief ? res1.getString("EBP_RSA") : res1.getString("EBP_s_value_for_RSA");
            case EBP_RABIN: return brief ? res1.getString("EBP_RABIN") : res1.getString("EBP_s_value_for_Rabin");
            case GF2255: return brief ? res1.getString("GF2_255") : res1.getString("elliptic_curve_on_GF");
//            case PEGWIT9: return brief ? res1.getString("PEGWIT9") : res1.getString("elliptic_curve_as_per");
            default: return brief ? res1.getString("unkpke") : res1.getString("unknown_PKE_algorithm");
            case EC: return brief ? res1.getString("OpenPGP_EC") : res1.getString("Elliptic_curve");
            case ECDSA: return brief ? res1.getString("OpenPGP_ECDSA") : res1.getString("Elliptic_curve1");
            case DUAL_ELGAMAL: return brief ? res1.getString("OpenPGP_Dual_ELGAMAL") : res1.getString("ElGamal_Encrypt_or");
            case DH : return brief ? res1.getString("DH_X9_42") : res1.getString("Diffie_Hellman_X4_92");
        }
    }

    private PKCypher()
    {
    }

    /**
    * returns an instance of the desired algorithm
    * @param pka byte code indicating algorithm
    */
    public static PKA getInstance(byte pka)
    {
        if(!loaded) load();
        switch (pka)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
            case EBP_RSA:
                return build(cRSA);
            case ELGAMAL:
                return build(cELGAMAL);
            case DSA:
                return build(cDSA);
            case EC:
                return build(cEC);
            case ECDSA:
                return build(cECDSA);
            case DUAL_ELGAMAL:
                return build(cDUAL_ELGAMAL);
            case DH:
                return build(cDH);
            case EBP_RABIN:
                return build(cRABIN);
            case GF2255:
                return build(cGF2255);
        }
        return null;
    }

    /**
    * returns an instance of the desired hash
    * @param c class indicating algorithm
    */
    private static PKA build(Class c)
    {
        if(null == c) return null;
        try {
            return (PKA) c.newInstance();
        } catch (IllegalAccessException iae) {}
        catch (InstantiationException ie) {}
        return null;
    }

    /**
    * Tells us if the indicated algorithm has been found
    * @param pka byte code indicating algorithm
    */
    public static boolean isAvailable(byte pka)
    {
        if(!loaded) load();

        switch (pka)
        {
            case RSA:
            case RSA_ENCRYPT_ONLY:
            case RSA_SIGN_ONLY:
            case EBP_RSA:
                return cRSA != null;
            case ELGAMAL:
                return cELGAMAL != null;
            case DSA:
                return cDSA != null;
            case EC:
                return cEC != null;
            case ECDSA:
                return cECDSA != null;
            case DUAL_ELGAMAL:
                return cDUAL_ELGAMAL != null;
            case DH:
                return cDH != null;
            case EBP_RABIN:
                return cRABIN != null;
            case GF2255:
                return cGF2255 != null;
        }
        return false;
    }

    /**
    * finds a Class for each of the algorithms of interest if possible
    */
    private static synchronized void load()
    {
        if(loaded) return;
        cRSA = find("RSA");
        cELGAMAL = find("ELGAMAL");
        cDSA = find("DSA");
        cEC = find("EC");
        cECDSA=find("ECDSA");
        cDUAL_ELGAMAL=find("DUAL_ELGAMAL");
        cDH = find("DH");
        cRABIN = find("RABIN");
        cGF2255 = find("GF2255");
        loaded = true;
    }

    /**
    * finds a Class for the named algorithm (the name is keyed
    * from a resource value), ensuring that it implements MDA
    */
    private static Class find(String name)
    {
        Class result = null;
        try {
            result = Class.forName(res.getString(name));
        } catch ( MissingResourceException mre) { return null;}
        catch ( ClassNotFoundException cnfe) { return null;}
        if(null == result) return null;

        Class [] ifs = result.getInterfaces();
        for(int i=0; i<ifs.length; ++i)
        {
            if(ifs[i] == PKA.class) return result;
        }
        return null;
    }

}