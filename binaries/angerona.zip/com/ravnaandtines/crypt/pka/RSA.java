package com.ravnaandtines.crypt.pka;

import com.ravnaandtines.crypt.mda.Hash;
import com.ravnaandtines.crypt.pka.Key;
import com.ravnaandtines.crypt.pka.KeyType;
import com.ravnaandtines.util.Monitor;
import com.ravnaandtines.crypt.pka.MPI;
import com.ravnaandtines.crypt.pka.PKA;
import com.ravnaandtines.util.math.Bignum;
import com.ravnaandtines.util.math.Random;
import com.ravnaandtines.util.event.*;

/**
*  Class RSA - the RSA public key algorithm.
*<p>
* <STRONG>NOT YET DEBUGGED AFTER CONVERSION FROM 'C'</STRONG>
* <p>
*<p>
* Many routines return booleans indicating success.  In the case of any of these
* routines failing it is due to failure to allocated memory.
* mod_power_mpn alone can also fail due to a user interrupt. //TODO
* <p>
*  Coded & copyright Heimdall <heimdall@bifroest.demon.co.uk>  1996
* All rights reserved.
*<p>
* Java port Mr. Tines <tines@windsong.demon.co.uk> Feb 1999
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 14-Feb-1999
*
*/


public class RSA implements PKA
{
    private static final int RSAPUB_N = 0;
    private static final int RSAPUB_E = 1;

    private static final int RSASEC_D = 0;
    private static final int RSASEC_P = 1;
    private static final int RSASEC_Q = 2;
    private static final int RSASEC_U = 3;

    private static final int RSASIG = 0;

    public RSA()
    {
    }

    public Key[] generateKeypair(KeyType type, Monitor watcher,
        Random r, StatusEventSupport signal)
    {
        Key pub_key = new Key(2);
        Key sec_key = new Key(4);
        if(newRSAkey(type, sec_key, pub_key, watcher, r, signal))
        {
            Key[] result = {pub_key, sec_key};
            return result;
        }
        pub_key.wipe();
        sec_key.wipe();
        return null;
    }

    public MPI[] encrypt(MPI message, Key pubkey, Monitor watcher)
    {
        Bignum input = new Bignum();
        Bignum result = null;
        Bignum output = new Bignum();
        try {
            if(rsa_public_operation(output, input, pubkey, watcher))
            {
               result = output;
            }
            else
            {
                output.clear_mpn();
            }
        }
        finally
        {
            input.clear_mpn();
        }
        if(result == null) return null;
        MPI[] ret = new MPI[1];
        ret[0] = new MPI();
        ret[0].num = result.put_mpn();
        return ret;
    }

    public MPI decrypt(MPI[] carrier, Key seckey, Monitor watcher)
    {
        Bignum input = new Bignum();
        Bignum result = null;
        Bignum output = new Bignum();
        try {
            if(rsa_private_operation(output, input, seckey, watcher))
            {
               result = output;
            }
            else
            {
                output.clear_mpn();
            }
        }
        finally
        {
            input.clear_mpn();
        }
        if(result == null) return null;
        MPI[] ret = new MPI[1];
        ret[0] = new MPI();
        ret[0].num = result.put_mpn();
        return ret[0];
    }

    public MPI[] sign(MPI message, Key seckey, Monitor watcher)
    {
        Bignum input = new Bignum();
        Bignum result = null;
        Bignum output = new Bignum();
        try {
            if(rsa_private_operation(output, input, seckey, watcher))
            {
               result = output;
            }
            else
            {
                output.clear_mpn();
            }
        }
        finally
        {
            input.clear_mpn();
        }
        if(result == null) return null;
        MPI[] ret = new MPI[1];
        ret[0] = new MPI();
        ret[0].num = result.put_mpn();
        return ret;
    }

    public boolean verify(MPI[] signature, MPI message, Key pubkey, Monitor watcher)
    {
        Bignum input = new Bignum();
        if(!input.get_mpn(signature[0].num)) return false;
        Bignum result = null;
        Bignum output = new Bignum();
        try {
            if(rsa_public_operation(output, input, pubkey, watcher))
            {
               result = output;
            }
            else
            {
                output.clear_mpn();
            }
        }
        finally
        {
            input.clear_mpn();
        }
        if(result == null) return false;
        byte[] buffer = result.put_mpn();
        // ret is now the decrypted digest buffer
        // return ret[0].equals(message);
    	/* PGP 2.2 format - 16 - MD5 digest length in bytes */
	    if(	buffer[0]	== 1 &&
    		buffer[17]	== 0 &&
	    	all_ff(buffer, 18, buffer.length - 19) &&
		    buffer[buffer.length - 1] == 1)
	    {
            for(int i22=0; i22<16; ++i22)
            {
                if(buffer[i22+1] != message.num[i22]) return false;
            }
            return true;
	    }

        byte[] asn = getASN(message.num[message.num.length-1]);

	    /* PGP 2.3 and on format */
	    if(	buffer[0]	== 1 &&
		    all_ff(buffer,1, buffer.length -
                (2 + asn.length + message.num.length-1)) &&
		    buffer[buffer.length - (asn.length + message.num.length-1 + 1)] == 0)
	    {
            int i26;
            for(i26=0; i26 < asn.length; ++i26)
            {
                if(buffer[i26 + buffer.length - (asn.length + message.num.length -1)]
                    != asn[i26])
                {
                    return false;
                }
            }

            boolean state = true;
            for(i26=0; i26 < message.num.length-1; ++i26)
            {
                if(buffer[i26+buffer.length - (message.num.length-1)]
                    != message.num[i26]) /*return*/state= false;
            }
            return /*true*/state;
	    }
        return false;
    }

    private static byte[] RSA_SHA1_ASN = null;
    private static byte[] RSA_MD5_ASN = null;
    private static byte[] RSA_RIPEMD_160_ASN = null;

    private byte[] prepare(int[] from)
    {
        byte[] to = new byte[4*(from.length-1) + from[0] ];
        for(int i=0; i<to.length; ++i)
        {
            int ix = 1+i/4;
            int off = (3-(i%4))*8;
            to[i] = (byte) ((from[ix]>>>off)&0xFF);
        }
        return to;
    }

    private byte[] getASN(byte mdalg)
    {
        int i, ix, off;

	    switch(mdalg)
	    {
		    case Hash.MD5:
                if(null == RSA_MD5_ASN)
                {
                    RSA_MD5_ASN=prepare(PKCypher.RSA_MD5_ASN);
                }
			    return RSA_MD5_ASN;

		    case Hash.PGP5_SHA1:
		    case Hash.SHA1:
                if(null == RSA_SHA1_ASN)
                {
                    RSA_SHA1_ASN=prepare(PKCypher.RSA_SHA1_ASN);
                }
			    return RSA_SHA1_ASN;

		    case Hash.PGP5_RIPEM160:
                if(null == RSA_RIPEMD_160_ASN)
                {
                    RSA_RIPEMD_160_ASN=prepare(PKCypher.RSA_RIPEMD_160_ASN);
                }
			    return RSA_RIPEMD_160_ASN;

		    //case MDA_EBP_HAVAL_MIN:
		    //case MDA_EBP_HAVAL_MAX:
		    //case MDA_3WAY:
		    //case MDA_SHA:

		    default:
			    return new byte[0];
	    }
    }

    private static boolean all_ff(byte[] buffer, int offset, int length)
    {
	    while(length-- > 0)
		    if(buffer[length+offset] != (byte)0xFF) return false;
    	return true;
    }

    private boolean rsa_public_operation(Bignum outbuf, Bignum inbuf,
        Key pub_key, Monitor watcher)
    /* Execute a public key operation (verification or encryption)   */
    {
        Bignum e = new Bignum();
        Bignum n = new Bignum();

        try{
            if(e.get_mpn(pub_key.nums[RSAPUB_E].num) &&
            n.get_mpn(pub_key.nums[RSAPUB_N].num) )
            {
	            return outbuf.mod_power_mpn(inbuf, e, n, watcher);
            }
            return false;
        }
        finally{
            e.clear_mpn();
            n.clear_mpn();
        }
    }

    private boolean rsa_private_operation(Bignum output, Bignum input,
        Key sec_key, Monitor watcher)
    /* Execute a private key operation (signing or decryption)     */
    {
	    Bignum	expon = new Bignum(), base = new Bignum(),
            temp = new Bignum(), OP = new Bignum();
//	    boolean[] result = {true};

        Bignum p = new Bignum();
        Bignum q = new Bignum();
        Bignum u = new Bignum();

	    //if(sec_key->skstat != INTERNAL) return CE_OTHER; /* fail hard as key still encrypted */

        try {
            if(!p.get_mpn(sec_key.nums[RSASEC_P].num)) return false;
            if(!q.get_mpn(sec_key.nums[RSASEC_Q].num)) return false;
            if(!expon.get_mpn(sec_key.nums[RSASEC_D].num)) return false;
	        expon.remainder_mpn(p, true);
	        if(!base.copy_mpn(input)) return false;

	        base.remainder_mpn(p, false);
	        if(!OP.mod_power_mpn(base, expon, p, watcher))
            {
                return false;
            }
	        if(!expon.get_mpn(sec_key.nums[RSASEC_D].num)) return false;

	        expon.remainder_mpn(q, true);
	        if(!base.copy_mpn(input)) return false;

	        base.remainder_mpn(q, false);
	        if(!output.mod_power_mpn(base, expon, q, watcher))
            {
                return false;
            }
            /* The next addition is to ensure that the result of the following
            ** subtraction is positive.  (The routines in use do not handle
            ** negative numbers.)  The subsequent remainder operation means it
            ** has no effect on the ultimate result. */
            if(!output.add_mpn(q)) return false;
	        output.subtract_mpn(OP);
            if(!u.get_mpn(sec_key.nums[RSASEC_U].num)) return false;
	        if(!temp.multiply_mpn(output, u))
            {
                return false;
            }
	        temp.remainder_mpn(q, false);
	        if(!output.multiply_mpn(temp, p))
            {
                return false;
            }
            return output.add_mpn(OP);
        }
        finally
        {
            temp.clear_mpn();
            expon.clear_mpn();
            base.clear_mpn();
            OP.clear_mpn();
            p.clear_mpn();
            q.clear_mpn();
            u.clear_mpn();
        }
    }
    private final short randomShort(Random r)
    {
	      return (short)( ((Bignum.mixedRandom(r)&0xFF)<<8) |
                           (Bignum.mixedRandom(r)&0xFF) );
    }

    private boolean	newRSAkey(KeyType keyType, Key sec_key,
        Key pub_key, Monitor watcher, Random r, StatusEventSupport signal)
    {
	    short topOfP, topOfQ;
	    boolean oddLength = (boolean)((keyType.keyLength % 2) == 1);
	    short primeLength = (short)((keyType.keyLength + 1) / 2);
	    boolean[] status = {true};
	    Bignum p=new Bignum(), q=new Bignum(), phi=new Bignum(), one=new Bignum();
	    int modulus;
	    Bignum n=new Bignum(), e=new Bignum(), d=new Bignum(), u=new Bignum();

	    r.randload((short)(keyType.keyLength + 200));
        signal.fireStatusEvent(
            new StatusEvent(this, StatusEvent.STATUS,
            "Commencing RSA key generation set-up")
        );

        boolean complete = false;

        try{
            do {
	    	    short A = (short)(randomShort(r) | 0x8000);
		        short B = (short)(randomShort(r) | 0x8000);

		        topOfP	= (short)Math.min(A&0xFFFF,B&0xFFFF);
		        topOfQ	= (short)Math.max(A&0xFFFF,B&0xFFFF);
		        modulus	= (topOfP&0xFFFF) * (topOfQ&0xFFFF);
				/* check values okay */
	        }while(
                (topOfQ&0xFFFF) < (topOfP&0xFFFF) + 16	|| /* 1) sufficiently different */
			    topOfQ == 0xFFFF		|| /* 2) topOfQ not in danger of overflowing */
			    /* 3a) if odd that multiplication will loose a bit in length */
			    ( oddLength && (modulus&0xFFFFFFFFL) >= 0x7FFFFFFFL) ||
			    /* 3b) if even that multiplication will not loose a bit in length */
			    (!oddLength && (modulus&0xFFFFFFFFL) <  0x80000000L));

            /* note we are forcing the public exponent to be odd not testing for this. */
            e.set_mpn(keyType.publicExponent | 1);
            signal.fireStatusEvent(
                new StatusEvent(this, StatusEvent.STATUS,
                    "Seeking first RSA prime")
            );
            if(!p.findPrime(primeLength, topOfP, keyType.method, e, r, watcher))
            {
                return false;
            }
            signal.fireStatusEvent(
                new StatusEvent(this, StatusEvent.STATUS,
                    "Seeking second RSA prime")
            );
            if(!q.findPrime(primeLength, topOfQ, keyType.method, e, r, watcher))
            {
                return false;
            }
            signal.fireStatusEvent(
                new StatusEvent(this, StatusEvent.STATUS,
                    "Concluding RSA key generation")
            );

		    if(	!n.multiply_mpn(p, q) ||
			    !phi.copy_mpn(n)		 ||
			    !one.set_mpn(1)			) return false;

		    phi.subtract_mpn(p);
		    phi.subtract_mpn(q);
		    phi.add_mpn(one);
		    if(	!d.modularInverse(e, phi, watcher)	||
			    !u.modularInverse(p, q, watcher))	return false;

            pub_key.nums[RSAPUB_N].num = n.put_mpn();
            pub_key.nums[RSAPUB_E].num = e.put_mpn();

            sec_key.nums[RSASEC_P].num = p.put_mpn();
            sec_key.nums[RSASEC_Q].num = q.put_mpn();
            sec_key.nums[RSASEC_D].num = d.put_mpn();
            sec_key.nums[RSASEC_U].num = u.put_mpn();

            complete = true;
        }
        finally {
	        p.clear_mpn();
            q.clear_mpn();
            phi.clear_mpn();
            one.clear_mpn();
	        n.clear_mpn();
            e.clear_mpn();
            d.clear_mpn();
            u.clear_mpn();

            if(!complete)
            {
                if(watcher.user_break())
                    signal.fireStatusEvent(
                        new StatusEvent(this, StatusEvent.WARN,
                        "RSA key generation interrupted by user")
                );
                else
                    signal.fireStatusEvent(
                        new StatusEvent(this, StatusEvent.ERROR,
                        "RSA key generation failed - out of memory")
                );
            }
        }
        return true;
    }
/*
    public boolean verifySecKeyRSA(Key sec_key)
    {
	bignum modulus;
	boolean result;

	init_mpn(&modulus);
// Checksum okay however there is a one in 64k chance of this with
// the wrong pass-phrase => check we have the factors of N.
   result = (boolean)
   (	multiply_mpn(&modulus, sec_key->pkdata.nums[RSASEC_P].plain,												sec_key->pkdata.nums[RSASEC_Q].plain) &&
			eq_mpn(modulus, sec_key->publicKey->pkdata.nums[RSAPUB_N]));
	clear_mpn(&modulus);
	return result;
}

#if defined (RSA_NONDLL_TEST)
// RSA test routine
int mutualFactor(pubkey * left, pubkey * right, char buffer[1000])
{
	bignum	commonFactor;
	bignum	one;
	int		result =  0;

	init_mpn(&commonFactor);
	init_mpn(&one);
	set_mpn(1L, &one);
	if(!completeKey(right) || !completeKey(left))
	{
		strcpy(buffer, "failed to complete key");
		result = -1;
	}
	else if(!HCF(&commonFactor, left->pkdata.nums[RSAPUB_N], right->pkdata.nums[RSAPUB_N]))
	{
		strcpy(buffer, "HCF() failed.");
		result = -1;
	}
	else if(!eq_mpn(commonFactor, one))
	{
		format_mpn(buffer, commonFactor);
		result = 1;
	}
	clear_mpn(&commonFactor);
	clear_mpn(&one);
	return result;
}
 end of file rsa.c */


}