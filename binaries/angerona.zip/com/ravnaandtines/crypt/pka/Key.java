package com.ravnaandtines.crypt.pka;

/**
*  Class Key - a very simple jacket class for a an array of byte arrays,
*  for lowest common denominator handling of public key algorithm keys.
* <p>
* Copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1999
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* <p>
* @author Mr. Tines
* @version 1.0 14-Feb-1999
*
*/

public class Key
{
    /**
    * The class is a carrier for a byte[][], to avoid having
    * to deal eventually with byte[][][]s
    */
    public MPI[] nums = null;

    /**
    * Default constructor
    */
    public Key()
    {
    }

    /**
    * Constructs, allocating a number of MPIs
    * @param i the number of MPIs to allocate
    */
    public Key(int i)
    {
        nums = new MPI[i];
        for(int k=0;k<i;++k) nums[i] = new MPI();
    }

    /**
    * Constructs, allocating a number of allocated MPIs
    * @param i the number of MPIs to allocate
    * @param j the size of MPIs to allocate
    */
    public Key(int i, int j)
    {
        nums = new MPI[i];
        for(int k=0;k<i;++k) nums[i] = new MPI(j);
    }

    /**
    * Clears the contents of this Key
    */
    public void wipe()
    {
        for(int i = 0; nums!=null && i<nums.length; ++i)
        {
            nums[i].wipe();
        }
        nums = null;
    }

}