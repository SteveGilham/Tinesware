package com.ravnaandtines.crypt.pka;
import com.ravnaandtines.util.Monitor;
import com.ravnaandtines.util.math.Random;
import com.ravnaandtines.util.event.StatusEventSupport;

/**
*  Interface PKA - a very simple intreface for public key algorithms.
* <p>
* Copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1999
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* <p>
* @author Mr. Tines
* @version 1.0 14-Feb-1999
*
*/

public interface PKA
{
    public Key[] generateKeypair(KeyType type, Monitor watcher,
        Random r, StatusEventSupport signal);

    public MPI[] encrypt(MPI message, Key pubkey, Monitor watcher);
    public MPI   decrypt(MPI[] carrier, Key seckey, Monitor watcher);

    public MPI[] sign(MPI message, Key seckey, Monitor watcher);
    public boolean verify(MPI[] signature, MPI message, Key pubkey, Monitor watcher);
}
