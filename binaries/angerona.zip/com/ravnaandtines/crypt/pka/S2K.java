package com.ravnaandtines.crypt.pka;

/**
*  Class S2K - Open PGP string to key specification.
* <p>
* Copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1999
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* <p>
* @author Mr. Tines
* @version 1.0 14-Feb-1999
*
*/

public class S2K
{

    /**
    * simple hash of UTF8 of passphrase
    */
    public static final byte simple=0x00;
    /**
    * salted hash
    */
    public static final byte salted=0x01;
    /**
    * iterated hash
    */
    public static final byte iterated=0x03;

    /**
    * what procedure to use
    */
    private byte type;

    /**
    * Hash algorithm as per Hash
    */
    private byte mda;

    /**
    * Salt
    */
    private byte[] salt = new byte[8];

    /**
    * iteration level
    */
    private byte iterator;
    private int count;

    private static final int EXPBIAS = 6;

    public S2K(byte hash)
    {
        mda = hash;
        type = simple;
    }

    public S2K(byte hash, byte[] salt, int offset)
    {
        this(hash);
        type = salted;
        System.arraycopy(salt, offset, this.salt, 0, 8);
    }

    public S2K(byte hash, byte[] salt, int offset, byte iter)
    {
        this(hash, salt, offset);
        type = iterated;
        iterator = iter;
        count = (16 + (iterator&15)) << ((iterator>>>4)+EXPBIAS);
    }

    public static int length(byte type)
    {
        switch(type)
        {
            case simple: return 1;
            case salted: return 9;
            case iterated: return 10;
        }
        return -1;
    }

    public static S2K build(byte[] packet, int offset, int length)
    {
        if(length < 9) return new S2K(packet[offset]);
        else if(length<10) return new S2K(packet[offset], packet, offset+1);
        else return new S2K(packet[offset], packet, offset+1, packet[offset+9]);
    }


}