package com.ravnaandtines.crypt.pka;

/**
*  Class MPI - a very simple jacket class for a byte array, for lowest
*  common denominator handling of public key algorithm keys.
* <p>
* Copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1999
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* <p>
* @author Mr. Tines
* @version 1.0 14-Feb-1999
*
*/

public class MPI
{
    /**
    * The class is a carrier for a byte[], to avoid having
    * to deal eventually with byte[][][]s
    */
    public byte[] num = null;

    /**
    * Default constructor
    */
    public MPI()
    {
    }

    /**
    * Constructs, allocating a number of bytes of space
    * @param i the number of bytes to allocate
    */
    public MPI(int i)
    {
       num = new byte[i];
    }

    /**
    * Clears the contents of this MPI
    */
    public void wipe()
    {
        for(int i = 0; num!=null && i<num.length; ++i)
        {
            num[i] = 0;
        }
        num = null;
    }

    public boolean equals(MPI other)
    {
        if(other.num.length != num.length) return false;
        for(int i=0; i<num.length; ++i)
        {
            if(other.num[i] != num[i]) return false;
        }
        return true;
    }
}