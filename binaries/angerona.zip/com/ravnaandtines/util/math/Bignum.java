package com.ravnaandtines.util.math;
import java.io.*;
import com.ravnaandtines.util.Monitor;

/**
*  Class Bignum - Multiple precision unsigned integer arithmetic; unlike
* java.math.BigInteger, it is a mutable class (so that the numbers
* can be wiped).
*<p>
* <STRONG>ONLY PARTIALLY DEBUGGED AFTER CONVERSION FROM 'C'</STRONG>
* <p>
* The BIGNUMS module is a multiple precision arithmetic module intended for
* the implementation of Public Key Encryption systems.  Note that it is NOT
* a general purpose multiple precision module.  Specifically:-
*   1) It handles only non-negative integers.
*   2) It is primarily concerned with (and optimised for) modular arithmetic.
*   3) It does not handle short integers efficiently.
*<p>
* Many routines return booleans indicating success.  In the case of any of these
* routines failing it is due to failure to allocated memory.
* mod_power_mpn alone can also fail due to a user interrupt. //TODO
* <p>
*  Coded & copyright Heimdall <heimdall@bifroest.demon.co.uk>  1996
* All rights reserved.
*<p>
*  Elliptic curve encryption support routines coded and copyright
*  Mr. Tines <tines@windsong.demon.co.uk> 1997
* <p>
* Java port Mr. Tines <tines@windsong.demon.co.uk> Jan-Jun 1999
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 17-Jan-1999
*
*/

public final class Bignum
{
    private static final int MAXUNIT = (~0);
    // unit is 32-bit int; half-unit is 16-bit short
    private static final int UNITBITS = 32;
    private static final int HALFBITS = 16;
    private static final int MAXHALF = ((1<<HALFBITS)-1);
    private static final long MASK = 0xFFFFFFFFL;


    // multiply two unsigned int values to give a 64-bit result
    private static final long multUnitxUnit(int op1, int op2)
    {
        return (op1&MASK) * (op2&MASK);
    }

    // divide a two-unit quantity by a unit
    private static final int divUnitByHalf(long dividend,
        int quotient, int[] remainder)
    {
        long times = 0, over = 0, denom = quotient&MASK;

        while(dividend < 0)
        {
             times += Long.MAX_VALUE/denom;
             over  += Long.MAX_VALUE%denom;
             dividend -= Long.MAX_VALUE;
        }

        if(remainder != null || over != 0)
        {
            over += dividend%denom;
            while(over >= denom)
            {
                over -= denom;
                ++times;
            }
            if(remainder != null) remainder[0] = (int) (over&MASK);
        }

        times += dividend/denom;
        return (int)(times&MASK);
    }

    // The actual data - how many of the array are used, and the array
    private int used;
    private int[] digit;

    /**
    * default construction of empty (implicit zero) number
    */
    public Bignum()
    {
        used = 0;
        digit = null;
    }

    // structure used to pass context for modular operations
    private class ModulusCache
    {
	    int length;
	    int shift;
	    int topUnit;
    }

    // trace info
    private static int[] stats = new int[20];
    private static Writer file = null;

    /**
    * Sets output for trace information
    * @param s to which to write log data
    */
    public static void setLog(Writer s)
    {
        file  = s;
    }

    /*
    * Schneier recommends sieving with primes up to 2000; there are just over
    * 300 primes under 2000
    */
    private static final int NPRIMES = 300;
    private static short[] primes = new short[NPRIMES];
    static {
        primes[0] = 0;
    }

    /*
    * The following function calculates the first NPRIMES prime number for
    * use in the initial prime number sieve screening of candidate primes.
    */
    private static void calculatePrimes()
    {
        int[] square = new int[NPRIMES];
        short candidate = 5;
        short index = 1;
        short found = 2;

        primes[0] = 2;
        square[0] = 2 * 2;
        primes[1] = 3;
        square[1] = 3 * 3;
        while(found < NPRIMES)
        {
            while(candidate >= square[index])
            {
                if(candidate % primes[index++] == 0)
                {
                    candidate += (short)2; /* reject candidate -> next candidate */
                    index = 1;
                }
            }
            primes[found]	= candidate;	/* accept candidate */
		        square[found++]	= (candidate * candidate);
		        candidate += (short)2;
            index = 1;
        }
    }

    /**
    * Computes the value (this % modulus) where modulus is interpreteted as
    * an unsigned value
    */
    private short mod_short(short modulus)
    {
        int m = (modulus&0xFFFF);
	      int accum = 0;
	      int factor = (int)(0x100000000L % m);//2^32 mod m
	      int offset = used;

	      while(offset-- > 0)
	      {
            int delta = (int)((digit[offset]&MASK) % m);
            int slide = (int)(((accum * factor)&MASK) % m);
		        accum = delta + slide;
	      }
	      return (short)((accum&MASK) % m);
    }

    /**
    * Sets this value to be the HCF of the two input values
    */
    public boolean HCF(Bignum left, Bignum right)
    {
	      Bignum temp_left = new Bignum(), temp_right = new Bignum();
	      Bignum swap, large, small;
	      boolean success = false; /* Initially assume failure */

	      if(temp_left.copy_mpn(left) && temp_right.copy_mpn(right))
	      {
		        if(left.gt_mpn(right))
		        {	large = temp_left;	small = temp_right; }
		        else
		        {	small = temp_left;	large = temp_right; }

		        while(small.used > 0)
		        {
			        large.remainder_mpn(small, false);
			        swap = large; large = small; small = swap;
		        }
		        success = copy_mpn(large); /* final potential failure */
	      }
	      temp_left.clear_mpn();
	      temp_right.clear_mpn();

	      return success;
    }

    /**
    * returns true if this value could be a prime
    * Could improve prime sieving as per PGP 2.3 by storing remainders
    */
    public boolean sieve()
    {
	      int offset	= 0;

	      if(primes[0] == 0) calculatePrimes(); /* executed first time only */
	      while(offset < NPRIMES)
	      {
		        if(mod_short(primes[offset++]) == 0)
		        {
			        /* candidate is a multiple of a known small prime number;
			        ** to be properly general we test if the candidate IS that prime number */
			        return (used == 1 &&
         	        digit[0] == primes[--offset]);
		        }
	      }
	      return true;
    }


    /**
    * Reduces the used value to drop leading zeroes
    */
    private void normalise()
    {
	      while(used > 0 &&
	        digit[used - 1] == 0)
	      {used--;}
    }

    private static final char[] hexDigit = {'0','1','2','3','4','5','6',
        '7','8','9','A','B','C','D','E','F'};
    private static final String hexString = "0123456789ABCDEF";

    private static StringBuffer formatNumber(int[] number, int length)
    {
        return formatNumber(number, length, 0);
    }
    private static StringBuffer formatNumber(int[] number, int length, int base)
    {
        StringBuffer s = new StringBuffer();
        for(int i=0; i<length; ++i) s.append("00000000");
        int ptr = 8*length - 1;
	      short	index	= -1;
	      short	count;
	      int 	value;

	      while(++index < length)
	      {
		        value = number[index+base];
		        count = 8;
		        while(count-- > 0)
		        {
			          s.setCharAt(ptr--, hexDigit[(value & 0xF)]);
			          value  = value >>> 4;
		        }
	      }
	      ptr = 0;
	      //while(s.charAt(ptr) == '0') ptr++;
        if(ptr > 0)
        {
            s.reverse();
            s.setLength(s.length()-ptr);
            s.reverse();
        }
	      return s;
    }

    /**
    * Returns as a StringBuffer, the hex expansion of the number
    */
    public StringBuffer format_mpn()
    {
	      return formatNumber(digit, used);
    }

    /**
    * Returns as a String, the hex expansion of the number
    */
    public String toString() {return format_mpn().toString();}

    // write the number to the log
    private void outputNumber(String name) throws java.io.IOException
    {
        if(file != null)
        {
           file.write(name+": #x"+toString()+System.getProperty("line.separator"));
        }
    }

    // allocate space for the number
    private boolean setSize(int size, boolean preserve)
    {
        int	oldbytes = null==digit ? 0 : digit.length;
        int newbytes = size+1; // allow for leading zero value

        if(oldbytes < newbytes)
        {
            // allocate the new space
            int[] temp = new int[newbytes];
            if(null == temp) return false;
            for(int i=0; i<temp.length; ++i) temp[i] = 0;

            // copy values across if required
            if(preserve && used > 0 && digit != null)
            {
                System.arraycopy(digit, 0, temp, 0, digit.length);
            }
            // clear old array, and swap in new one
            for(int j=0; digit !=null && j<digit.length; ++j) digit[j] = 0;
		        digit = temp;
        }
        used = size; // not normalised
        return true;
    }

    /**
    * initialises a Bignum to an int value (taken as unsigned)
    */
    public boolean set_mpn(int value)
    {
	      if(setSize(1, false)) // dispose of old
	      {
		        digit[0] = value;
		        digit[1] = 0;
		        if(value == 0) used = 0;
		        return true;
	      }
	      else
		      return false;
    }

    /**
    * Interprets the hex string as a Bignum
    */
    public boolean read_mpn(String input)
    {
	      int	charLen	= input.length();
	      int	wordLen	= (charLen + 8 - 1) / 8; // 8 nybbles per unit
	      int	ptr		= charLen;
	      int	factor	= 1;
	      int xdigit;
	      int	index	= 0;

        // allocate space
	      if(!setSize(wordLen, false)) return false;

	      while(ptr-- > 0)
	      {
		        if(factor == 1) digit[index] = 0;
            // peel off and interpret the next character, aborting
            // if not recognised
		        xdigit	= hexString.indexOf(
                Character.toUpperCase(
                input.charAt(ptr) ));
		        if(xdigit < 0) return false;

		        digit[index] += factor * xdigit;
		        factor	= factor * 16;
		        if(factor==0) // cunning shift trick
		        {
			          index++;
			          factor = 1;
		        }
	      }
	      digit[wordLen] = 0;
	      used = wordLen;
	      normalise();
	      return true;
    }

    /**
    * Zeroes the array and detaches it, restoring to newly allocated state
    */
    public void	clear_mpn()
    {
        if(digit != null)
        {
            for(int i=0; i<digit.length; ++i) digit[i] = 0;
        }
        digit = null;
        used = 0;
    }

    /**
    * Interprets the byte[] as a Bignum
    */
    public boolean get_mpn(byte[]external)
    {
        int bytecount	= external.length;
	    int wordcount	= (bytecount + 3)/4; // 4 bytes per unit
    	int word;
	    int ptr;
        //	char		debug[1000];

	    if(!setSize(wordcount, false)) return false;
	    word		= wordcount - 1;
	    ptr			= 0;
	    used  = wordcount;

        for(int i=0; i<digit.length; ++i) digit[i] = 0;
	    while(bytecount > 0)
	    {
		    digit[word] = digit[word] * 256 + (external[ptr++]&0xFF);
		    if((--bytecount % 4) == 0) word--;
	    }
        //	formatMPNumber(debug, result);
	     return true;
    }

    private static final int[] lookup = { 0,1,2,2,  3,3,3,3,  4,4,4,4,  4,4,4,4 };

    // where is the top bit?
    private int topBit(int value)
    {
	      int	guess = 16;
	      int incrm = (guess / 2);

	      stats[4]++;
	      while(incrm >= 2)
	      {
		      if( (value&0xFFFFFFFFL) >= (1 << guess))
			      guess += incrm;
		      else
			      guess -= incrm;
		      incrm /=  2;
	      }
	      guess -=  2;
	      return (lookup[(value >>> guess)] + guess);
    }


    /*  Test routine to ensure that topBit always returns the correct answer **/
//#ifdef TESTTOPBIT
//static void testTopBit(void)
//{
//	uint16_t result = 0;
//
//	assert(topBit(0) == 0);
//	while(++result < UNITBITS)
//	{
//		assert(topBit(((unit)1 <<  result) - 1  ) == result);
//		assert(topBit( (unit)1 << (result  - 1) ) == result);
//	}
//	assert(topBit(MAXUNIT) == UNITBITS);
//}
//#endif

    /**
    * returns the bit-length of the Bignum
    */
    public int length_mpn()
    {
	      stats[13]++;
	      if(used > 0)
		      return (	(used - 1) * UNITBITS
			      +	topBit(digit[used - 1]));
	      else
		      return 0;
    }

    /**
    * expands the value as a byte array
    */
    public byte[] put_mpn()
    {
	      int	numBits		= length_mpn();
	      int	bytecount	= ((numBits + 7) / 8);
	      int	word	    = 0;
	      int value	    = digit[word++];

        byte[] external = new byte[bytecount];

	      int	ptr		= bytecount;
	      int count	= 4;

	      while(ptr > 0)
	      {
		        external[--ptr]	= (byte)(value & 0xFF);
		        value	= value >>> 8;
		        if(--count == 0)
		        {
			          value = digit[word++];
			          count = 4;
		        }
	      }
	      return external;
    }

    /**
    * returns number of bytes in this Bignum
    */
    public int size_mpn()
    {
        return ((length_mpn() + 7)/ 8);
    }

    /**
    *  multiplies a multiple precision number by a single precision value.
    * the result and the multiple precision operand may be the same location
    * length is the nominal length, the result must be at least one length
    */
    private static void s_m_mult_add(
        int[] result, int reso,
        int[] multi, int moff,
        int scalar, int length)
    {
        long carry = 0;
        int index = 0;

        stats[0]++;
        /* Is basically practical => proceed */
        while(index < length)
        {
            long product = multUnitxUnit(scalar, multi[index+moff])
                + (result[reso+index]&MASK) + carry;
            result[reso+index++] = (int)(product&MASK);
            carry = product >>> 32;
        }
        long temp = (result[reso+index]&MASK)+carry;
        result[reso+index] = (int)(temp&MASK);
        if((temp >>> 32) != 0) result[reso+index+1]++;
    }

    /**
    * multiplies a multiple precision number by a single precision value
    * the result and the multiple precision operand may be the same location
    * length is the nominal length, the result must be at least one length
    */
    private static void s_m_mult_sub(
        int[] result, int ro,
        int[] multi, int mo,
        int scalar, int length)
    {
        long borrow = 0;
        int index = 0;

        stats[1]++;
        /* Is basically practical => proceed */
        while(index < length)
        {
            long product = multUnitxUnit(scalar, multi[mo+index]) + borrow;
            borrow = product >>> 32;
            product &= MASK;
            if(product > (result[ro+index]&MASK))
                ++borrow;
            result[ro+index++] -= (int)product;
        }
        //assert(result[(size_t)index] >= borrow);
        result[ro+index] -= (int)(borrow&MASK);
    }

    private static java.math.BigInteger convert(
        int[] value, int offset,
        int length)
    {
        try {
            byte[] tmp = new byte[4*length];
            for(int i=0; i<length; ++i)
            {
                int k = (length-i)-1;
                tmp[4*k + 0] = (byte)((value[offset+i]>>>24)&0xFF);
                tmp[4*k + 1] = (byte)((value[offset+i]>>>16)&0xFF);
                tmp[4*k + 2] = (byte)((value[offset+i]>>> 8)&0xFF);
                tmp[4*k + 3] = (byte)((value[offset+i])&0xFF);
            }
            return new java.math.BigInteger(1,tmp);
        } catch (Exception ex) {return null;}
    }

    /**
    * subtracts one multiple precision number from another, any or all of
    * the arguments may be the same location; returns true if there is overall
    * borrow
    */
    private static boolean m_m_sub(
        int[] result, int off,
        int[] minus, int mo,
        int length)
    {
        long difference;
        long positive;
        int index = 0;
//System.out.println("value: "+formatNumber(result, length, off));

        stats[3]++;
        while(true)
        {
            /* no borrow sub-loop */
            do
            {
                positive	= MASK&result[index+off];
                difference	= positive - (MASK&minus[index+mo]);
                difference &= MASK;
                result[index+off] = (int)(difference);
                index++;
                if(index >= length)
                {
                    return (difference > positive);
                }
            } while(difference <= positive);

            /* borrow sub-loop */
            do
            {
                positive	= MASK&result[index+off];
                difference  = (positive-1) - (MASK&minus[index+mo]);
                difference &= MASK;
                result[index+off] = (int)(difference);
                index++;
                if(index >= length)
                {
                    return (difference >= positive);
                }
            } while(difference >= positive);
        }
    }

    /**
    * which of the two fragments is the larger?
    */
    private static boolean mp_gt(
        int[] left, int lo,
        int[] right, int ro,
        int offset)
    {
        stats[6]++;
        while(offset-- > 0)
        {
            if(left[offset+lo] != right[offset+ro])
            {
                return (MASK&left[offset+lo]) > (MASK&right[offset+ro]);
            }
        }
        return false;
    }

    /**
    * basic modular operation
    */
    private static int s_m_mod(
        int[] operand, int off,
        int[] modulus, int mo,
        ModulusCache modSummary)
    {
	      int length		= modSummary.length;
	      int shift		  = modSummary.shift;
	      int	topUnit		= modSummary.topUnit;
	      int scalar;
	      boolean first	= true;
	      long firstUnit;
	      int secondUnit;

	      if(shift != 0)
	      {
		        firstUnit	= (operand[off+length    ] << shift)
						  + (operand[off+length - 1] >>> (UNITBITS - shift));
		        secondUnit	= (operand[off+length - 1] << shift);

		        if(length > 1)
			          secondUnit += (operand[off+length - 2] >>> (UNITBITS - shift));
	      }
	      else
	      {	/* This is code path is not merely for efficency.  Some machines
		      ** execute shifts by UNITBITS as no-ops rather than set to zero.
		      ** e.g. DEC Alpha			*/
		        firstUnit	= operand[off+length];
		        secondUnit	= operand[off+length - 1];
	      }

	      stats[7]++;
	      /* The divisor for the approximate single unit factor is
        * (modSummary->topUnit + 1) The +1 could cause overflow.
        * This needs special case treatment. */
	      if(topUnit == MAXUNIT)
          {
		        scalar = (int)firstUnit; /* this division in this case is trivial */
          }
	      else
	      {
		        int divisor = topUnit + 1;
		        //assert(firstUnit < topUnit); /* required for udiv_qrnnd */
                scalar = divUnitByHalf((firstUnit<<32)|(secondUnit&MASK),
                divisor, null);
    	  }
	      if((scalar != 1) && (scalar != 0))
		        s_m_mult_sub(operand, off, modulus, mo, scalar, length);
	      else
		      scalar = 0;

	      while(!mp_gt(modulus, mo, operand, off, length + 1))
	      {
		        stats[8]++;
		        if(!first) stats[9]++;
		        first = false;
                boolean ok = !m_m_sub(operand, off, modulus, mo, length + 1);
		        //assert(ok);
		        scalar++;
	      }
	      //assert(operand[length] == 0);
	      return scalar;
    }

    /**
    * modular multiply
    */
    private static void m_m_mult_mod(
        int[] result, int reso,
        int[] left, int lo,
        int[] right, int ro,
        int[] modulus, int mo,
        int[] work,	int wo, ModulusCache modSummary)
    {
        int length = modSummary.length;
        int index  = 0;
        int buffer = length+2;
        stats[10]++;
        System.arraycopy(left, lo, work, buffer+wo, length+2);
	      //assert(buffer[length] == 0);
	      //assert(buffer[length + 1] == 0);
	      //assert(right[length] == 0);
	      //assert(right[length + 1] == 0);
        for(int i=0; i<length+2; ++i)
        {
            result[i+reso] = 0;
            work[i+wo] = 0;
        }
        s_m_mult_add(result, reso, work, wo+buffer, right[ro+index], length);
        ++index;
        result[reso + length + 1] = 0;
        /*	s_m_mod(result, modulus, modSummary);	*/
        while(index < length)
        {
            buffer--;	/* effectively multiplication by 0x100000000  */
            s_m_mod(work, wo+buffer, modulus, mo, modSummary);
            s_m_mult_add(result, reso, work, wo+buffer, right[ro+index], length);
            index++;
          /*		s_m_mod(result, modulus, modSummary); */
        }
        s_m_mod(result, reso+1, modulus, mo, modSummary);
        s_m_mod(result, reso+0, modulus, mo, modSummary);
    }

    /**
    * Copies this value into the buffer
    */
    private void setBuffer(int[] buffer, int offset, int length)
    {
	      int index = length;

	      stats[11]++;
	      //assert(number.used <= length);
	      while(index	  > used)	buffer[--index + offset]	= 0;
	      while(index-- > 0)		buffer[index + offset]	= digit[index];
    }

    /**
    * Is the indicated bit set in the array?
    */
    private static boolean bitSet(int number[], int bitNumber)
    {
	      int word	= (bitNumber / UNITBITS);
	      int bit	    = (bitNumber % UNITBITS);

	      stats[12]++;
	      return (number[word] & (1 << bit)) != 0;
    }

    /**
    * set modulus info form this number
    */
    private void summarise(ModulusCache summary)
    {
	      int length = used;
	      int modulusShift = (UNITBITS - topBit(digit[length - 1]));

	      //assert(modulus->digit[length] == 0);
	      summary.length		= length;
	      summary.shift		= modulusShift;
	      summary.topUnit	= digit[length - 1] << modulusShift;
	      if(length > 1 && modulusShift > 0)
		        summary.topUnit += digit[length - 2] >>> (UNITBITS - modulusShift);
    }


    //boolean	divide_mpn(	bignump quotient, bignump remainder,
	  //				bignum numerator, bignum denominator)
    /**
    * generate the results of dividing this number by the denominator
    */
    public boolean divide_mpn(Bignum[] qr, Bignum denominator)
    {
	      ModulusCache modSummary = new ModulusCache();
	      int	offset = used - denominator.used;
	      int n_bytes = (used + 1);
	      int[] result = new int[n_bytes];

	      //assert(numerator->digit[numerator->used] == 0);
        System.arraycopy(digit, 0, result, 0, n_bytes);
	      denominator.summarise(modSummary);

	      int d_length = modSummary.length;
	      if(mp_gt(denominator.digit, 0, result, offset, d_length)) offset--;
	      if(!qr[0].setSize(offset + 1, false)) return false;
	      if(qr.length > 1 && !qr[1].setSize(d_length, false)) return false;
	      qr[0].digit[offset + 1] = 0;

	      while(offset >= 0)
	      {
		        qr[0].digit[offset] =
			        s_m_mod(result, offset, denominator.digit, 0, modSummary);
		        offset--;
	      }
	      qr[0].normalise();
	      if(qr.length > 1)
	      {
            System.arraycopy(result, 0, qr[1].digit, 0, d_length+1);
		        qr[1].normalise();
	      }
        for(int i=0; i<n_bytes;++i) result[i] = 0;
	      return true;
    }

    /**
    * simple modular remainder
    */
    public void remainder_mpn(Bignum modulus, boolean minus1)
    {
	      ModulusCache modSummary = new ModulusCache();
	      modulus.summarise(modSummary);
	      int length = modSummary.length;
	      int offset = (used - modulus.used);

	      //assert(result->alloc > result->used);
	      //assert(result->digit[result->used] == 0);

	      if(minus1) modulus.digit[0]--;
	      if(mp_gt(modulus.digit, 0, digit, offset, length)) offset--;
	      while(offset >= 0)
	      {
		        s_m_mod(digit, offset--, modulus.digit, 0, modSummary);
	      }
	      normalise();
	      if(minus1) modulus.digit[0]++;
    }


    /**
    * Set this value to the product of the two arguments
    */
    public boolean multiply_mpn(Bignum left, Bignum right)
    {
	      int length = left.used + right.used;  /* could be 1 shorter */
	      int offset  = 0;

	      if(!setSize(length, false)) return false;
        //for(int i=0; i<length+1;++i) digit[i] = 0;

	      while(offset < left.used)
	      {
		        s_m_mult_add(digit, offset, right.digit, 0,
					      left.digit[offset], right.used);
		        offset++;
	      }
	      normalise();
    	  return true;
    }

    /* This routine is not very well written, especially with respect to
    ** extending the result.  Consider a rewrite.  */
    public boolean add_mpn(Bignum add)
    {
        boolean	carry = false;
	      int index = 0;
	      int length;

	      /* First determine the length of the sum */
	      if(used > add.used)
	      {
		        length = used;
		        if(digit[used - 1] == MAXUNIT) length++;
	      }
	      else
	      {
		        length = add.used;
		        if(used < add.used)
		        {
			          if(add.digit[add.used - 1] == MAXUNIT) length++;
		        }
		        else
		        {
		          /* N.B. Assuming that the numbers are normalised neither top unit
		          **      can be zero. */
			          if((add.digit[length]&MASK) <
                    ((add.digit[length] + digit[length] + 1)&MASK))
                {
				            length++;
                }
		        }
	      }
	      if(!setSize(length, true)) return false;

	      while(index < add.used)
	      {
		        carry = (carry && ++digit[index] == 0);
		        digit[index] += add.digit[index];
		        if((digit[index]&MASK) <
                (add.digit[index]&MASK)) carry = true;
		        index++;
	      }

	      /* propagate carry as far as necessary */
	      if(carry) { while(++digit[index++] == 0) {} }

	      //assert(index <= (*result)->alloc);
	      normalise();
	      return true;
    }

    /**
    * take the input value from this
    */
    public void subtract_mpn(Bignum minus)
    {
	      int offset = minus.used;

	      //assert(used >= minus->used);
	      if(m_m_sub(digit, 0, minus.digit, 0, minus.used))
	      {
		        /* overall borrow => propagate it */
		        while(digit[offset++]-- == 0) {}
	      }
	      //assert(offset <= result->used + 1);
	      normalise();
    }

    /**
    * set this value to a copy of the input
    */
    public boolean copy_mpn(Bignum input)
    {
	      int length = input.used;

    	  if(!setSize(length, false)) return false;
        //for(int i=0; i<digit.length;++i) digit[i] = 0;

        System.arraycopy(input.digit, 0, digit, 0, length);
        //digit[length] = 0;
        return true;
    }

    /**
    * Is this the larger?
    */
    public boolean gt_mpn(Bignum right)
    {
	    //if(!left)
		    //return FALSE;
	    //else if(!right)
		    //return TRUE;
	    //else
        if(used != right.used)
		      return (used > right.used);
	      else
		      return mp_gt(digit, 0, right.digit, 0, used);
    }

    /**
    * Are these equal?
    */
    public boolean eq_mpn(Bignum right)
    {
	      if(/*!left || !right || left->*/used != right.used)
		      return false;
	      else
	      {
		        int offset = used;
		        while(offset-- > 0)
		        {
			          if(digit[offset] != right.digit[offset]) return false;
		        }
		        return true;
	      }
    }

    //#define SWAP(a, b) { temp = a; a = b; b = temp; }

    /**
    * sets this = (multi**expon)%modulus
    */
    public boolean mod_power_mpn(Bignum multi, Bignum expon,
        Bignum modulus, Monitor watcher)
    {
        int length		= modulus.used;
        ModulusCache	modSummary = new ModulusCache();
        int exponBits;
        int exponBit		= 0;
        boolean errorCode = true;

        int[] workSpace = new int[5 * (length + 2)];
        if(null == workSpace) return false;
        int power2		= 0;//workSpace;
        int accum		= power2	+ length + 2;
        int intermed	= accum		+ length + 2;
        int work		= intermed	+ length + 2;
        int temp;
/*	testTopBit(); */

        int i, swap;
        for(i=0; i<stats.length; ++i) {stats[i] = 0;}
        modulus.summarise(modSummary);
        multi.setBuffer(workSpace, power2, length+1);
        exponBits = expon.length_mpn();
        if(bitSet(expon.digit, 0))
        {
            System.arraycopy(workSpace, power2, workSpace, accum, length+1);
        }
        else
        {	/* Even exponent; this isn't really expected (for RSA at least) */
            for(i=0; i<length+1; ++i) workSpace[accum+i] = 0;
                workSpace[accum+0] = 1;
        }
        while(++exponBit < exponBits && errorCode)
        {
            m_m_mult_mod(workSpace, intermed,
                        workSpace, power2,
                        workSpace, power2,
                        modulus.digit, 0,
                        workSpace, work, modSummary);
		//SWAP(intermed, power2);
            swap = intermed;
            intermed = power2;
            power2 = swap;
/*		formatNumber(debug, power2, length); */
            if(bitSet(expon.digit, exponBit))
            {
                m_m_mult_mod(workSpace, intermed,
                            workSpace, power2,
                            workSpace, accum,
                            modulus.digit, 0,
                            workSpace, work, modSummary);
			//SWAP(intermed, accum);
                swap = intermed;
                intermed = accum;
                accum =swap;
            }
            if(exponBit % 8 == 0 && watcher.user_break()) errorCode = false;
        }
        if(errorCode)
        {
            if(!setSize(length, false))
                errorCode = false;
            else
            {
                System.arraycopy(workSpace, accum, digit, 0, length);
                digit[length] = 0;
                normalise();
            }
        }
        for(i=0; i<workSpace.length;++i) workSpace[i] = 0;
            return errorCode;
    }

/* routines developed to support elliptic curve encryption */
/* The operations are abstracted from what are used in George Barwood's
   public domain Pegwit PKE system, version 8.1
*/
    /**
    * returns true if bitnumth bit is set
    */
    public boolean nthBitSet_mpn(int bitnum )
    {
	      if (bitnum  >= used*UNITBITS) return false;
        else if (bitnum < 0) return false;
        return bitSet(digit, bitnum);
    }

    /**
    * makes lowest bit equal the boolean value 0 or 1
    */
    public void set0thBit_mpn (boolean bit)
    {
	      if(bit) digit[0] |= 1;
        else digit[0] &= (MAXUNIT - 1);
    }


    /**
    * pack the lowest bitsUsed bits from datalen short's into a bignum
    * with a number of clear bits below this.  implicitly init_mpn()s value
    */
    boolean pack16_mpn(short[] data, int datalen, byte bitsUsed, byte freeLowBits)
    {
	      int numbits = (bitsUsed*datalen)+freeLowBits;
        int numunits = ((numbits + UNITBITS - 1)/UNITBITS);
        short mask = (short)((1 << bitsUsed) - 1);
        int ptr;
        int i;
        short basebits;

        /* Allocate space implicitly clearing*/
        if(!setSize(numunits, false)) return false;

	      /* Copy data across */
        for(i=0,ptr = 0,basebits = freeLowBits;
            i<datalen;
            i++, basebits += bitsUsed)
        {
   	        short nextBit = (short)(basebits + bitsUsed);
            /* coerce to make long enough in 16 bit case! */
            digit[ptr] |= (data[i]&mask) << basebits;

            if(nextBit > UNITBITS) /* have to carry */
            {
			          /* step along one */
      	        ++ptr;
                basebits -= (short) UNITBITS;
                nextBit -= (short) UNITBITS;

                digit[ptr] |= ((data[i]&mask) >>>
                        (bitsUsed - nextBit));
            }
        }
        /* allow for empty top bits */
        normalise();
        return true;
    }

    /**
    * the converse operation - fails if datalen is too small
    */
    boolean unpack16_mpn(short[] data,  int [] datalen,
							byte bitsUsed, byte freeLowBits)
    {
	      int bitsValid = length_mpn() - freeLowBits;
        int needed = ((bitsValid + bitsUsed - 1)/bitsUsed);
        int i;
        short mask = (short)((1 << bitsUsed) - 1);
        int ptr;
        short basebits;

        if(needed > datalen[0]) return false;
        if(needed < datalen[0]) /* ensure unwanted stuff is false */
        {
   	        for(i=needed; i<datalen[0]; i++) data[i] = 0;
        }
        for(i=0, ptr = 0, basebits = freeLowBits;
            i<needed;
            i++, basebits += bitsUsed)
        {
            short nextBit = (short)(basebits + bitsUsed);
            data[i] = (short)(((digit[ptr])>>basebits) & mask);

            if(nextBit > UNITBITS)
            {
        		/* step along one */
                ++ptr;
                basebits -= (short)UNITBITS;
                nextBit -= (short)UNITBITS;
                data[i] |= (short)(((digit[ptr])&((1<<nextBit)-1))
            				<< (bitsUsed - nextBit));
            }
        }
        datalen[0] = needed;
        return true;
    }

    /* special case operation */
    public boolean triple_mpn (Bignum input)
    {
	    /* compute size needed for result */
        int wordlen = input.used;
        int i;
        int carry;

        if(input.digit[input.used - 1] >= (MAXUNIT/3) ) wordlen++;

        if(!setSize(wordlen, false)) return false;
        digit[used - 1] = 0;

        for(i=0, carry=0;i<input.used;i++)
        {
            /* probably overkill, but at least I'm sure it catches
                all cases of carry for all sizes of unit */
    	      long product = multUnitxUnit(3, input.digit[i]) + carry;
            digit[i] = (int)(product & MASK);
            carry = (int)((product>>>32) & MASK);
        }
        if(carry != 0) digit[i] = carry;

        normalise();
        return true;
    }

    private static final Bignum prime_order_value;
    static {
        Bignum p = new Bignum();
        int [] digit = {0x42bbcd31, 0x5e0d2584, 0x4bf72d8b,
                0x0547840e, 0xed9bbec3, 0x2314691c,
                0xd85081b8, 0x0001026d, 0x00000000};
        p.digit = digit;
        p.used = 8;
        prime_order_value = p;
    }

    public void getPrimeOrder()
    {
        copy_mpn(prime_order_value);
    }

    //private static final int FERMATLIMIT = 10;

    public static final byte mixedRandom(Random r)
    {
	      byte result = 0;
	      while(result == 0 || result == 0xFF) result = r.randombyte();
	      return result;
    }

    private final short randomShort(Random r)
    {
	      return (short)( ((mixedRandom(r)&0xFF)<<8) |  (mixedRandom(r)&0xFF) );
    }

    private boolean mutuallyPrime(Bignum right, boolean[] success)
    {
	      Bignum hcf = new Bignum(), one = new Bignum();
	      boolean result;

	      if(!hcf.HCF(this, right) || !one.set_mpn(1))
	      { success[0] = false; result = true; }
	      else result = !hcf.gt_mpn(one);
	      hcf.clear_mpn();
	      one.clear_mpn();
	      return result;
    }

    public boolean modularInverse(Bignum input, Bignum modulus, Monitor watcher)
    {
	    Bignum remainder = new Bignum(), target = new Bignum(),
            trial = new Bignum(),
            temp = new Bignum(), one = new Bignum();
        Bignum[] factor = new Bignum[1];
        factor[0] = new Bignum();

	    boolean[] success	= {false};

	    if(	one.set_mpn(1)			&&
		    copy_mpn(one)		&&
		    remainder.copy_mpn(input)	&&
		    target.copy_mpn(modulus)	&&
		    factor[0].copy_mpn(one)		&&
		    trial.copy_mpn(modulus))
	    {
            success[0] = true;
            do
            {
                do
                {
                    if(	!target.divide_mpn(factor, remainder)	||
					    !factor[0].add_mpn(one)							||
					    !trial.multiply_mpn(factor[0], remainder))
                    {
                        success[0] = false;
                    }
                    trial.remainder_mpn(modulus, false);
                    if(	!target.add_mpn(modulus))
                    {
                        success[0] = false;
                    }
                    if(watcher.user_break()) success[0] = false;
                }while (success[0] && (!remainder.gt_mpn(trial) ||
							   !trial.mutuallyPrime(modulus, success)));

                if(	!temp.multiply_mpn(factor[0], this)) success[0] = false;
                temp.remainder_mpn(modulus, false);
                if(	!this.copy_mpn(temp)				||
                    !remainder.copy_mpn(trial)			||
                    !target.copy_mpn(modulus)) success[0] = false;
            } while(success[0] && remainder.gt_mpn( one));
	    }
	    remainder.clear_mpn(); target.clear_mpn(); factor[0].clear_mpn();
	    trial.clear_mpn();	one.clear_mpn(); temp.clear_mpn();
	    return success[0];
    }

    public boolean longRandom(short length, short topBits, Random r)
    {
	      short Nbytes = (short)((length + 7) / 8); /* bytes including length */
	      short bits	= (short) ((length - 1) % 8); /* one less number of bits in top byte */
	      byte	mask	= (byte)(0xFF >>> (7 - bits)); /* mask for random data in third data byte */
	      short	offset	= 2;

	      if(topBits == 0) topBits = (short) (0x8000 | randomShort(r)); /* treat topBits==0 as "don't care" */
	      if(0==(topBits & 0x8000) || length < 24) return false;
	      byte[] buffer	= new byte[Nbytes];
	      if(null == buffer) return false;
	      buffer[0] = (byte)(topBits >>> (15 - bits));
	      buffer[1] = (byte)(( topBits >>> (7  - bits)) & 0xFF);
	      buffer[2] = (byte)(((topBits << (bits + 1)) & 0xFF) | (r.randombyte() & mask));
	      while(offset++ < Nbytes - 1) { buffer[offset] = r.randombyte(); }

        boolean ok = get_mpn(buffer);
	      for(int i=0; i<Nbytes; ++i) buffer[i]=0;
	      return ok;
    }

    private static boolean are_primes(Bignum[] candidates,
        boolean[] errCode, Monitor watcher)
    {
	      short	offset	= 0;
	      boolean		answer	= true;
	      Bignum		result	= new Bignum();
	      Bignum		factor	= new Bignum();
	      int   		number  = 0;
	      int[]     primes = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

	      while(number<candidates.length)
        {
            if(!candidates[number++].sieve()) return false;
        }
	      while(errCode[0] && answer && offset < primes.length)
	      {
		        if(!factor.set_mpn(primes[offset])) errCode[0] = false;
		        number = 0;
		        while(errCode[0] && answer && number<candidates.length)
		        {
			        /* Test p for primality by applying Fermat's theorem:
			          For any x, if ((x**(p-1)) mod p) != 1, then p is not prime.
			          We actually test (x**p) mod p against x
			        */
			        errCode[0] = result.mod_power_mpn(factor,
                candidates[number], candidates[number], watcher);
			        if(!result.eq_mpn(factor)) answer = false;
			        number++;
		        }
		        offset++;
	      }
	      result.clear_mpn();factor.clear_mpn();
	      return answer;
    }

    /* Strictly finds 2N+1 where N is a Sophie Germain prime */
    private boolean next_Sophie_Germain_prime(int increment_requested,
        Monitor watcher)
    {
	      long increment = increment_requested & MASK;
	      Bignum[]	candidates = { new Bignum(), new Bignum() };
	      Bignum	number	= candidates[0];
	      Bignum[]	half 	= {candidates[1]};

	      Bignum	temp	= new Bignum();
	      Bignum	incr	= new Bignum();
	      Bignum	halfincr = new Bignum();
	      Bignum	one		= new Bignum();
	      boolean[] errCode	= {true};

        /* As the result of this routine has to equal 11 modulo 12,
        ** the initial set-up establishes
        ** starting values with the following properties:-
        ** number = 11 [mod 12]
        ** half = (number - 1)/2
        ** increment = 0 [mod 12]
        ** halfincr  = increment / 2
        ** number & increment are mutually prime
        ** half & halfincr are mutually prime
        ** */

	      /* first set up number to be 11 modulo 12 by adding the necessary
	      ** smaller integer and set up a few simple values */
	      if(	!number.copy_mpn(this) ||
		      !temp.set_mpn((11 - number.mod_short((short)12))) ||
		      !number.add_mpn(temp) ||
		      !one.set_mpn(1) ||
		      !temp.set_mpn(2) ||
		      !number.divide_mpn(half, temp))
	      {
		        temp.clear_mpn(); one.clear_mpn(); half[0].clear_mpn();
		        return false;
	      }

	      /* adjust increment upwards to be the next multiple of 12 */
	      if(increment % 12 != 0)
        {
		      increment = ((increment / 12) + 1) * 12;
        }

	      /* Predecrement increment as we increment it at the start of the loop;
	      ** this is probably unimportant in most cases, but just in case the caller
	      ** had a particular reason for wanting the particular increment value
	      ** provided.  */
	      increment -= 12;

	      /* This nested loop tries potential values of increment until
        * one meeting all criteria is encountered. */
	      do
	      {
		        do
		        {
			          increment += 12;
			          if(increment > MASK) errCode[0] = false; /* Overflow check */
			          if(	!incr.set_mpn((int)increment) ||
				        !temp.HCF(incr, number)  ) errCode[0] = false;
		        } while(errCode[0] && temp.gt_mpn(one));
		        if(	!halfincr.set_mpn((int)(increment / 2))	||
			      !temp.HCF(halfincr, half[0])) errCode[0] = false;
	      } while(errCode[0] && temp.gt_mpn(one));
	      one.clear_mpn(); temp.clear_mpn();

	      /* ready to search for candidates */
	      while(errCode[0] && !are_primes(candidates, errCode, watcher))
	      {
                if(	watcher. user_break() ||
                !number.add_mpn(incr) ||
                !half[0].add_mpn( halfincr))
			          errCode[0] = false;
	      }
	      half[0].clear_mpn(); halfincr.clear_mpn(); incr.clear_mpn();

	      if(errCode[0] == true)
	      {
		        copy_mpn(number);
          }
	      number.clear_mpn();
	      return errCode[0];
    }

    private boolean next_prime(int increment_requested, Monitor watcher)
    {
        long increment = increment_requested&MASK;
	    Bignum[]	candidates = { new Bignum() };
	    Bignum	number	= candidates[0];
	    Bignum	temp	= new Bignum();
	    Bignum	incr	= new Bignum();
	    Bignum	one		= new Bignum();
        boolean[] errCode	= {true};;

        /* The initial set-up that follows establishes
        ** starting values with the following properties:-
        ** number is odd
        ** increment is even
        ** number & increment are mutually prime
        ** */

	    /* first set up number to be odd by adding one if necessary */
	    if(!number.copy_mpn(this) || !one.set_mpn(1)) return false;
	    if(number.mod_short((short)2) != 1) number.add_mpn(one);

	    /* adjust increment upwards to be the next multiple of 2 */
	    if(increment % 2 != 0) 	increment++;

	    /* Predecrement increment as we increment it at the start of the loop;
	    ** this is probably unimportant in most cases, but just in case the caller
	    ** had a particular reason for wanting the particular increment value
	    ** provided.  */
	    increment -= 2;

	    /* This nested loop tries potential values of increment until one meeting
	    ** all criteria is encountered. */
	    do
	    {
		    increment += 2;
            if(increment > MASK) errCode[0] = false; /* Overflow check */
            if(	!incr.set_mpn((int)increment) ||
			          !temp.HCF(incr, number)  ) errCode[0] = false;
        } while(errCode[0] && temp.gt_mpn(one));
        one.clear_mpn(); temp.clear_mpn();

        /* ready to search for candidates */
        while(errCode[0] && !are_primes(candidates, errCode, watcher))
        {
            if(	watcher.user_break()||!number.add_mpn(incr))
			        errCode[0] = false;
        }
        incr.clear_mpn();

        if(errCode[0] == true)
        {
            copy_mpn(number);
        }
        number.clear_mpn();
        return errCode[0];
    }

    private boolean mutuallyPrimeM1(Bignum right, boolean[] success)
    {
	      set0thBit_mpn(false);
	      boolean result = mutuallyPrime(right, success);
	      set0thBit_mpn(true);
	      return result;
    }

    public static final int SIMPLE_SCAN = 0;
    public static final int JUMP_SCAN = 1;
    public static final int SOPHIE_GERMAIN = 2;

    /* find a prime of length 'length' with most significant bits defined
    *  by topBits using method 'method' where N-1 is mutually prime with
    'mutual' */
    public boolean findPrime(short length, short topBits, int method,
        Bignum mutual, Random r, Monitor watcher)
    {
        boolean[] result	= {true};
        int increment;
        boolean[] success = {true};

        if(r.randload((short)(length + 32)) < 0) return false;

        increment =  (r.randombyte()&0xFF) +
				            ((r.randombyte()&0xFF) * 0x100) +
				            ((r.randombyte()&0xFF) * 0x10000) +
				            ((r.randombyte()&0x7F) * 0x1000000);
	    if(r.randload(length) > 0 &&
		      longRandom(length, topBits, r))
	    {
            switch(method)
            {
                case SIMPLE_SCAN:
				increment = 1;
				/*deliberate drop through to next case */
			    case JUMP_SCAN:
                {
                    Bignum two = new Bignum();
                    two.set_mpn(2);
                    do
                    {
                        while(!mutuallyPrimeM1(mutual, success)){add_mpn(two);}
                        result[0] = next_prime(increment, watcher);
                    } while(result[0] && !mutuallyPrimeM1(mutual, success));
                    two.clear_mpn();
                }
                if(!success[0]) result[0] = false;
                break;

                case SOPHIE_GERMAIN:
                result[0] = next_Sophie_Germain_prime(increment, watcher);
                break;

                default:
                result[0] = false;
            }
        }
        return result[0];
    }
}
