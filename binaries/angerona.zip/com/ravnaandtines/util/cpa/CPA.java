package com.ravnaandtines.util.cpa;
import com.ravnaandtines.util.io.*;
import java.io.*;

/**
*  Interface CPA - standard stripped down compander interface
*  <P>
*  Coded Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1999
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
* @author Mr. Tines
* @version 1.0 16-Jan-1999
*/

public interface CPA
{
    /**
    * Compress the data from the source
    * @param in the byte stream from which the raw data comes
    * @param out the byte stream to which the compressed result should be
    * @return false if the compression failed
    */
    public abstract boolean compress(Read in, Write out) throws IOException;

    /**
    * Expand the data from the source
    * @param in the byte stream from which the compressed data comes
    * @param out the byte stream to which the expanded result should be
    * @return false if the expansion failed
    */
    public abstract boolean decompress(RandomAccessRead in, Write out) throws IOException;
}
