package com.ravnaandtines.util.cpa;

import java.util.*;

/**
*  Class Compand - factory class for compression algorithms.
*  <P>
*  Coded Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  and released into the public domain
*  <P>
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
* BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*  <P>
* @author Mr. Tines
* @version 1.0 16-Jan-1999
*/

public class Compand
{
    /**
    * Algorithm class bundle
    */
    private static ResourceBundle res =
        ResourceBundle.getBundle("com.ravnaandtines.util.cpa.CPAClasses");
    /**
    * Algorithm tags bundle
    */
    private static ResourceBundle res1 =
        ResourceBundle.getBundle("com.ravnaandtines.util.cpa.CPATags");

    /**
    * Indicates my unofficial algorithm values
    */
    public static final byte FLEX_FLAG = (byte)0x80;
    /**
    * No compression
    */
    public static final byte NONE =           0;
    /**
    * Zip-based deflate compression algorithm
    */
    public static final byte DEFLATE =           1;
    private static Class cDEFLATE = null;
    /**
    * Splay tree compression
    */
    public static final byte SPLAY =	(byte)(1|FLEX_FLAG);
    private static Class cSPLAY = null;

    /**
    * Have we read the algorithm classes?
    */
    private static boolean loaded = false;

    /**
    * All static, so no sense instantiating
    */
    private Compand()
    {
    }

    /**
    * Serves up a descriptive string for the algorithm
    * @param alg the algorithm on which to report
    * @param full true if you want the long form
    * @return the description string
    */
    public static String getAlgName(byte mode, boolean full)
    {
        boolean brief = !full;
        switch(mode)
        {
            case NONE: return brief ? res1.getString("NONE") : 	res1.getString("no_compression");
            case DEFLATE: return brief ? res1.getString("DEFLATE") : res1.getString("Zip_based_deflate");
            case SPLAY: return brief ? res1.getString("SPLAY") : res1.getString("Splay_tree");
            default: return brief ? res1.getString("UNKNOWN") : res1.getString("Unknown_compression");
        }
    }

    /**
    * returns an instance of the desired compression
    * @param mda byte code indicating algorithm
    */
    public static CPA getInstance(byte cpa)
    {
        if(!loaded) load();

        switch (cpa)
        {
            case DEFLATE:
                return build(cDEFLATE);
            case SPLAY:
                return build(cSPLAY);
        }
        return null;
    }

    /**
    * returns an instance of the desired hash
    * @param c class indicating algorithm
    */
    private static CPA build(Class c)
    {
        if(null == c) return null;
        try {
            return (CPA) c.newInstance();
        } catch (IllegalAccessException iae) {}
        catch (InstantiationException ie) {}
        return null;
    }

    /**
    * Tells us if the indicated algorithm has been found
    * @param mda byte code indicating algorithm
    */
    public static boolean isAvailable(byte cpa)
    {
        if(!loaded) load();

        switch (cpa)
        {
            case DEFLATE:
                return cDEFLATE != null;
            case SPLAY:
                return cSPLAY != null;
        }
        return false;
    }

    /**
    * finds a Class for each of the algorithms of interest if possible
    */
    private static synchronized void load()
    {
        if(loaded) return;
        cDEFLATE = find("DEFLATE");
        cSPLAY = find("SPLAY");
        loaded = true;
    }

    /**
    * finds a Class for the named algorithm (the name is keyed
    * from a resource value), ensuring that it implements MDA
    */
    private static Class find(String name)
    {
        Class result = null;
        try {
            result = Class.forName(res.getString(name));
        } catch ( MissingResourceException mre) { return null;}
        catch ( ClassNotFoundException cnfe) { return null;}
        if(null == result) return null;

        Class [] ifs = result.getInterfaces();
        for(int i=0; i<ifs.length; ++i)
        {
            if(ifs[i] == CPA.class) return result;
        }
        return null;
    }
}
