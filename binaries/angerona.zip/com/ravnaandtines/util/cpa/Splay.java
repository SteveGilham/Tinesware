package com.ravnaandtines.util.cpa;

import com.ravnaandtines.util.io.*;
import com.ravnaandtines.util.cpa.CPA;
import java.io.*;

/**
*  Class Splay
*  -
*  Compression via splay tree using Markov processes.  Algorithm coded from
*  "Applications of Splay Trees to Data Compression", D.W. Jones, Comm of ACM
*  Aug 1988 pp 996-1007
*
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 16-Jan-1999
*/


public class Splay implements CPA
{
/* A number of constant values */
    /**
    * number of distinct values input
    */
    private static final int BYTEMAX = 256;
    /**
    * a value that is not a byte
    */
    private static final short OUTOFBAND = 256;
    /**
    * maximum number of states - actually 256 will also work
    */
    private static final int STATEMAX = 255;
    /**
    * twice BYTEMAX, plus 1
    */
    private static final int DOUBLEMAX = 513;
    /**
    * a good enough value for text and image
    */
    private static final int STATES = 32;
    private static final int BITSPERBYTE = 8;
    private static final int BUFFERLEN  = 1024;
    private static final int BUFFERBITS = BUFFERLEN*BITSPERBYTE;

    private short[][] sinister = new short[STATEMAX][];
    private short[][] dexter = new short[STATEMAX][];
    private short[][] trunk = new short[STATEMAX][];
    private boolean[] stack = new boolean[BYTEMAX+1];
    private byte[] buffer = null;
    private byte state;
    private byte statenumber;
    private static final byte[] bits =
              {(byte)0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
    private short bitnumber;
    private short bufferbytes;
    private long bufferbase;
    private boolean catastrophe;
    private int states;

/*-----------------------------------------------------------*/
/* Housekeeping routines */

    private void initSplay()
    {
        int i,j;

        catastrophe = false;

        statenumber = (byte) states;
        if(states < 1 || states > STATEMAX) statenumber = STATES;

        for(i=0; i<(0xFF&statenumber); i++)
        {
   	        sinister[i] = new short[BYTEMAX];
   	        dexter[i] = new short[BYTEMAX];
   	        trunk[i] = new short[DOUBLEMAX];
            buffer = new byte[BUFFERLEN];
        }
        for(i=0; i<DOUBLEMAX; i++)
        {
            for(j=0; j<(0xFF&statenumber); j++) trunk[j][i]=(short)((i-1)/2);
        }
        for(i=0; i<BYTEMAX; i++)
        {
            for(j=0; j<(0xFF&statenumber); j++)
      	        dexter[j][i] = (short) ((sinister[j][i] = (short)(2*i+1)) + 1 );
        }
        bufferbytes = bitnumber = state = 0;
        for(i=0; i<BYTEMAX+1;++i) stack[i] = false;
    }

    private void endSplay() /* Zap any storage allocated */
    {
	    int i;

        for(i=0; i<(0xFF&statenumber); i++)
        {
            int j;
            for(j=0; j<BYTEMAX; j++) sinister[i][j] = 0;
            sinister[i] = null;
            for(j=0; j<BYTEMAX; j++) dexter[i][j] = 0;
            dexter[i] = null;
            for(j=0; j<DOUBLEMAX; j++) trunk[i][j] = 0;
            trunk[i] = null;
        }
        for(i=0; i<BUFFERLEN; i++) buffer[i] = 0;
        buffer = null;
        state = statenumber = 0;
        System.gc();
    }

    /*-----------------------------------------------------------*/
    /* local utility routines*/

    private void splayCore(short byteval) /* 0-255 byte value or OUTOFBAND to end */
    {
	    short a,b,c,d;

	    short [] sin = sinister[state];
	    short [] dex = dexter[state];
	    short [] core = trunk[state];

        a = (short)(byteval+BYTEMAX);

	    do{ /* pair rotate down to the base of the tree */
   	        c=core[(0xFFFF&a)];
            if(c != 0)
            {
      	        d=core[(0xFFFF&c)];
      	        b=sin[(0xFFFF&d)];
                if(b == c)
                {
         	        b = dex[(0xFFFF&d)];
                    dex[(0xFFFF&d)] = a;
                }
                else sin[(0xFFFF&d)] = a;

                if(a == sin[(0xFFFF&c)]) sin[(0xFFFF&c)] = b;
                else dex[(0xFFFF&c)] = b;

                core[(0xFFFF&a)] = d;
                core[(0xFFFF&b)] = c;

                a = d;
            }
            else a = c;
        } while(a != 0);

        state = (byte)((byteval&0xFFFF) % (statenumber&0xFF));
    }

    private void pushBit(boolean bit, Write outfile) throws IOException
    {
	    byte bitindex = (byte)(bitnumber % BITSPERBYTE);
        if(bit) buffer[bitnumber/BITSPERBYTE] |= bits[bitindex];
        ++bitnumber;
        if(bitnumber >= BUFFERBITS)
        {
            outfile.write(buffer, 0, BUFFERLEN);
   	        for(int i=0; i<BUFFERLEN;++i) buffer[i] = 0;
            bitnumber = 0;
        }
    }

    private void flushBuffer(Write outfile) throws IOException
    {
	    if(bitnumber > 0)
        {
   	        while((bitnumber % BITSPERBYTE) != 0)
            { /* fill last byte with zeroes */
      	        pushBit(false, outfile);
            }
            outfile.write(buffer, 0, bitnumber/BITSPERBYTE);
        }
    }

    private void downSplay(short byteval, Write outfile) throws IOException
    {
	    short[] core = trunk[state];
	    short[] dex  = dexter[state];
        short index = 0;
	    short a = (short)(byteval+BYTEMAX);

	    do {  /* record info for this value on the stack */
   	        stack[index] = (dex[core[(0xFFFF&a)]]==a);
            ++index;
            a = core[(0xFFFF&a)];
        } while(a!=0);

        do {  /* and write it */
   	        pushBit(stack[--index], outfile);
        } while(index != 0);

        splayCore(byteval); /* step state on one */
    }

    private boolean pullBit(RandomAccessRead infile) throws IOException
    {
	    byte bitindex;
        if(bitnumber >= (bufferbytes*BITSPERBYTE))
        {
            bufferbase = infile.getFilePointer(); /* to allow backtracking */
   	        bufferbytes = (short) infile.read(buffer, 0, BUFFERLEN);
            if(bufferbytes <= 0) catastrophe=true;
            bitnumber=0;
        }

        bitindex = (byte)(bitnumber % BITSPERBYTE);
        /* macho C - index with ++ to avoid save, increment and resturn */
        return (buffer[(bitnumber++)/BITSPERBYTE] & bits[bitindex]) != 0;
    }

    private short upSplay(RandomAccessRead infile) throws IOException
    {
	    short []dex = dexter[state];
	    short []sin = sinister[state];
	    short a=0;

        do {
   	        if(pullBit(infile)) a = dex[(0xFFFF&a)];
            else a = sin[(0xFFFF&a)];
            if(catastrophe) return (short)(BYTEMAX+1);
        } while(a < BYTEMAX);

        a = (short)((0xFFFF&a) - BYTEMAX);
        splayCore(a);
        return a;
    }

/*-----------------------------------------------------------*/
/* external interface routines */

    /**
    * Compress the data from the source
    * @param input the byte stream from which the raw data comes
    * @param output the byte stream to which the compressed result should be
    * @return false if the compression failed
    */
    public boolean compress(Read input, Write output) throws IOException
    {
        byte[] raw = new byte[BUFFERLEN];
        short index, top;

        initSplay();
        output.write((0xFF&statenumber)); /*record states used */

	    while((top = (short) input.read(raw, 0, BUFFERLEN)) > 0)
        {
            for(index = 0; index < top; index++)
      	        downSplay( (short)(0xFF&raw[index]), output );
        }
        downSplay( OUTOFBAND, output );
        flushBuffer(output);

        endSplay();
        return !catastrophe;
    }

    /**
    * Expand the data from the source
    * @param input the byte stream from which the compressed data comes
    * @param output the byte stream to which the expanded result should be
    * @return false if the expansion failed
    */
    public boolean decompress(RandomAccessRead input, Write output) throws IOException
    {
	    byte[] result = new byte[BUFFERLEN];
        short index=0, value;

        int states = input.read();
        if(states < 0) throw new EOFException();
        initSplay();
        bitnumber = BUFFERBITS+1; /* buffer exhausted */

	    while((value=upSplay(input)) < BYTEMAX)
        {
   	        result[index++] = (byte) value;
            if(index >= BUFFERLEN)
            {
                output.write(result, 0, BUFFERLEN);
                index = 0;
            }
        }
        /* premature EOF - bail out and fail */
        if(!catastrophe)
        {
            /* have hit stop value - flush output, and rejig input */
            if(index!=0) output.write(result, 0, index);

            while((bitnumber % BITSPERBYTE)!=0) ++bitnumber;
            bufferbase += bitnumber/BITSPERBYTE;

            /* push back the data we grabbed too hastily */
            input.seek(bufferbase);

            endSplay();
        }
        return !catastrophe;
    }
/* End of file splay.c */


    public Splay()
    {
        this(STATES);
    }

    public Splay(int states)
    {
        this.states = states;
    }


}
