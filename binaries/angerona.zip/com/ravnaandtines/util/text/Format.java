package com.ravnaandtines.util.text;
import java.text.*;

/**
*  Class Format
*  <P>
*  Coded & copyright Mr. Tines &lt;tines@windsong.demon.co.uk&gt; 1998
*  All rights reserved.
*  <P>
*  This application is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public
*  License as published by the Free Software Foundation; either
*  version 2 of the License, or (at your option) any later version.
*  <P>
*  This application is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  General Public License for more details.
*  <P>
*  You should have received a copy of the GNU General Public
*  License along with this library (file "COPYING"); if not,
*  write to the Free Software Foundation, Inc.,
*  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*  <P>
* @author Mr. Tines
* @version 1.0 17-Nov-1998
*
*/


public class Format
{
    private Format()
    {
    }

    /**
    * Evaluates the local end of line once
    */
    private static String NL = System.getProperty("line.separator");
    /**
    * Given a string, safely word wrap it to a number of chars per line
    * lines being separated by the local line separator string.
    * Note that a word break iterator parses whitespace gaps as words.
    * @param in is the string to format
    * @param chars is the number of characters allowed per line
    * @return the processed string.
    */
    public static String wrapText(String in, int chars)
    {
        BreakIterator bi = BreakIterator.getWordInstance();
        bi.setText(in);
        StringBuffer wrap = new StringBuffer();
        StringBuffer line = new StringBuffer();
        int start = bi.first();
        for (int end = bi.next(); end != BreakIterator.DONE;
            start=end, end=bi.next())
        {
            String word = in.substring(start,end);
            int delta = word.length();
            int l = line.length();
            if(l>0)
            {
                // the line is occupied, 
                if(l+delta > chars)
                {
                    // and will be too long with the new word - so break it now
                    wrap.append(line.toString().trim()+NL);
                    l = 0;
                    line = new StringBuffer();
                }
                else
                {
                    line.append(word);
                }
            }
            if(l == 0) // need to start a new line for this word
            {
                // remove leading spaces in this simple wrap
                word = word.trim();
                delta = word.length();

                if(delta >= chars) // very long word
                {
                    wrap.append(word+NL);
                }
                else
                {
                    line.append(word);
                }
            }
        } // end of scan
        // post any last line
        if(line.length() > 0)
        {
            wrap.append(line.toString()+NL);
        }
        return wrap.toString();
    }

}