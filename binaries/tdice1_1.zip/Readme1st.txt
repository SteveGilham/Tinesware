This zip file contains

1) Tines' Dice files.zip - contains the files you're after:-
	dice.lua - source in MS-DOS text format
	dice_lua.pdb - source in Palm AportisDoc (DOC) format
	Readme.txt - license, install guide and user guide
	Tines'_Dice.PRC - the compiled Plua program 

2) Tines' Dice files.zip.asc - a PGP signature of the
above file, using 1024-bit RSA key ID 59EDD345
(keyprint BC01 5527 B493 7C9B 3C54 D1B7 248C 08BC)
so you can confirm it's what I wanted to distribute.

3) Readme1st.txt - this file of explanations

IMPORTANT If you have installed v1.0, you should first 
========= delete that from your PDA (either though the 
launcher, or a utility like Filez or Tom's Catalog).  
This is due to a problem to do with case sensitivity 
of file and program names - installing v1.1 with v1.0
present, the new version will just be masked by rather 
than replace the v1.0 executable.
