public interface SlideListener {
  public abstract void slideEvent(Slider s);
} 