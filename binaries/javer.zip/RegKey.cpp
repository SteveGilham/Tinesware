//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         regkey.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of RegKey (TButton).
//
//----------------------------------------------------------------------------
#include <owl/pch.h>

#include "regkey.h"


//{{RegKey Implementation}}
#define REGPATH "Software\\Ravna And Tines\\Javer"
#define CLASSPATH "Classpath"
#define MAINCLASS "Mainclass"
#define ARGUMENTS "Arguments"
#define JAVAHOME  "Javahome"
#define WORKDIR   "Working directory"

RegKey::RegKey(bool create)
{
  // INSERT>> Your constructor code here.
   valtype = REG_SZ;
	if(create)
   {
   	DWORD disp;
  		res = RegCreateKeyEx(HKEY_CURRENT_USER, REGPATH, 0, NULL,
   	REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &skey, &disp);
   }
   else
   {
     res = RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH,
  		0, KEY_ALL_ACCESS, &skey);
   }
}


RegKey::~RegKey()
{
  // INSERT>> Your destructor code here.
	if(ERROR_SUCCESS == res)
   {
   	RegCloseKey(skey);
   }
}
//==========================================================================

void RegKey::getClasspath(char * buffer, DWORD *size)
{
	if(isOK())
  {
  	LONG value = getKey(CLASSPATH, reinterpret_cast<LPBYTE>(buffer), size);
    if(ERROR_SUCCESS == value && buffer[0]) return;
  }
  char * path = getenv("windir");
  if(path)
  {
   	strcpy(buffer, path);
  }
  else buffer[0] = 0;

	path = getenv(CLASSPATH);
  if(path)
  {
   	if(buffer[0]) strcat(buffer, ";");
   	strcat(buffer, path);
  }
}

void RegKey::getMainclass(char * buffer, DWORD *size)
{
	if(isOK())
   {
   	LONG value = getKey(MAINCLASS, reinterpret_cast<LPBYTE>(buffer), size);
      if(ERROR_SUCCESS == value) return;
   }
   buffer[0] = 0;
}

void RegKey::getArguments(char * buffer, DWORD *size)
{
	if(isOK())
   {
   	LONG value = getKey(ARGUMENTS, reinterpret_cast<LPBYTE>(buffer), size);
      if(ERROR_SUCCESS == value) return;
   }
   buffer[0] = 0;
}

void RegKey::getJavahome(char * buffer, DWORD *size)
{
	if(isOK())
   {
   	LONG value = getKey(JAVAHOME, reinterpret_cast<LPBYTE>(buffer), size);
      if(ERROR_SUCCESS == value) return;
   }
   buffer[0] = 0;
}

void RegKey::getWorkdir(char * buffer, DWORD *size)
{
	if(isOK())
   {
   	LONG value = getKey(WORKDIR, reinterpret_cast<LPBYTE>(buffer), size);
      if(ERROR_SUCCESS == value && buffer[0]) return;
   }
   char * path = getenv("TEMP");
   if(path && path[0])
   {
   	strcpy(buffer, path);
    return;
   }
   path = getenv("TMP");
   if(path && path[0])
   {
   	strcpy(buffer, path);
    return;
   }
   buffer[0] = 0;
}
//==========================================================================

void RegKey::setClasspath(const char * buffer, DWORD size)
{
	if(isOK())
   {
  		RegSetValueEx(skey, CLASSPATH, 0, valtype, (LPBYTE)buffer, size);
   }
}

void RegKey::setMainclass(const char * buffer, DWORD size)
{
	if(isOK())
   {
  		RegSetValueEx(skey, MAINCLASS, 0, valtype, (LPBYTE)buffer, size);
   }
}

void RegKey::setArguments(const char * buffer, DWORD size)
{
	if(isOK())
   {
  		RegSetValueEx(skey, ARGUMENTS, 0, valtype, (LPBYTE)buffer, size);
   }
}

void RegKey::setJavahome(const char * buffer, DWORD size)
{
	if(isOK())
   {
  		RegSetValueEx(skey, JAVAHOME, 0, valtype, (LPBYTE)buffer, size);
   }
}

void RegKey::setWorkdir(const char * buffer, DWORD size)
{
	if(isOK())
   {
  		RegSetValueEx(skey, WORKDIR, 0, valtype, (LPBYTE)buffer, size);
   }
}



//==========================================================================

LONG RegKey::getKey(const char * tag, LPBYTE buffer, DWORD *size)
{
	buffer[0] = 0;

	if(ERROR_SUCCESS != res) { *size = 0; return res;}
   LONG xres = RegQueryValueEx(skey, tag, 0, &valtype, (LPBYTE)buffer, size);
  	if(xres != ERROR_SUCCESS)
  	{
  	 	buffer[0] = 0;
  	}
   return xres;
}


