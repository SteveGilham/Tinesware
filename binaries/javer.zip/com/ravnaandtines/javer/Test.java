
//Title:        Javer - Java saver
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Mr. Tines
//Company:      RavnaAndTines.Com
//Description:  Java screen saver


package com.ravnaandtines.javer;
import java.io.*;

public class Test
{

  private Test()
  {
  }

  public static void main(String[] args)
  {
    try{
      FileOutputStream f = new FileOutputStream("F:\\c++\\javer\\jtest.log");
      PrintStream out = new PrintStream(f);
      if(null == args) out.println("args = "+args);
      else
      {
        out.println("args length = "+args.length);
        for(int i =0; i<args.length; ++i)
          out.println("["+i+"] = \""+args[i]+"\"");
      }
      java.util.Properties prop = System.getProperties();
      for(java.util.Enumeration names = prop.propertyNames();
        names.hasMoreElements();)
      {
        String name = (String)names.nextElement();
        String value = (String)prop.get(name);
        out.println(name+"="+value);
      }
    } catch(Exception x) {}
  }
}
