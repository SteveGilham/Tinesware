
//Title:        Javer - Java saver
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Mr. Tines
//Company:      RavnaAndTines.Com
//Description:  Java screen saver


package com.ravnaandtines;
import java.lang.reflect.*;
import java.awt.*;
import java.io.*;

public class Javer
{
  private static String workdir = System.getProperty("javer.workdir","");
  private static File work = null;
  private static class Policy extends SecurityManager
  {
    // promiscuous net access
    public void checkAccept(String host, int port) {}
    public void checkAccess(Thread g) {}
    public void checkAccess(ThreadGroup g){}
    public void checkAwtEventQueueAccess() {}
    public void checkConnect(String host, int port) {}
    public void checkConnect(String host, int port, Object context) {}
    public void checkExit(int status) {}
    public void checkListen(int port) {}
    public void checkMemberAccess(Class clazz, int which) {}
    public void checkPackageAccess(String pkg) {}
    public void checkPropertyAccess(String key){}
    public void checkPropertiesAccess(String key){}

    // Sockets, or stdio, AFAIK
    public void checkWrite(FileDescriptor fd) {}
    public void checkRead(FileDescriptor fd) {}
    public boolean checkTopLevelWindow(Object window) {return true;}
    public void checkLink(String lib){}

    // restricted
    public void checkPackageDefinition(String pkg)
    {
      if(pkg.startsWith("java.")||pkg.startsWith("sun."))
        super.checkPackageDefinition(pkg);
    }

    // filing system within work directory only
    public void checkDelete(String file)
      {inWorkDir(new File(file));}
    public void checkRead(String file)
      {inWorkDir(new File(file));}
    public void checkRead(String file, Object context)
      {inWorkDir(new File(file));}
    public void checkWrite(String file)
      {inWorkDir(new File(file));}

    // check by looking at parent until it matches, or vanishes.
    private void inWorkDir(File fd)
    {
      // no temporary directory => abort now
      if(null == work) super.checkRead(fd.getAbsolutePath());
      for(;;)
      {
        String p = fd.getParent();
        if(null == p) super.checkRead(fd.getAbsolutePath());
        if(p.length() < workdir.length()) super.checkRead(p);
        fd = new File(p);
        if(fd.equals(work)) return;
      }
    }
  }


  private static class JaverW extends Window
  {
    java.util.Random r = new java.util.Random(1066);

    public JaverW()
    {
      super(new Frame());
      Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
      d.width /= 4;
      d.height /= 4;
      setSize(d);
      setBackground(Color.black);
      setForeground(Color.white);
    }

    public void replace()
    {
      Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension d2 = getSize();
      int x = Math.round((d.width-d2.width) * r.nextFloat());
      int y = Math.round((d.height-d2.height) * r.nextFloat());
      setLocation(x,y);
      byte [] col = new byte[3];
      r.nextBytes(col);
      setForeground(new Color(col[0]&0xff, col[1]&0xff, col[2]&0xff));
    }

    public void paint(Graphics g)
    {
      FontMetrics f = getFontMetrics(getFont());
      g.setColor(getForeground());
      g.drawString("Javer", 0, getSize().height/2);
      Dimension d = new Dimension(
      f.stringWidth("Javer"), 2*f.getMaxAscent());
      setSize(d);
    }
  }

  private Javer()
  {
  }

  public static void main(String[] args)
  {
    //Try to get working directory
    if(null != workdir && workdir.length() != 0) work = new File(workdir);

    // clean up properties
    java.util.Properties prop = System.getProperties();
    prop.remove("user.dir");
    prop.remove("user.name");
    prop.remove("user.home");
    prop.remove("java.class.path");

    //Apply security policy
    System.setSecurityManager(new Policy());

    // process arguments and launch process
    if(args != null && args.length > 0)
    {
      String[] subargs = null;
      if(args.length > 1)
      {
        subargs = new String[args.length-1];
        System.arraycopy(args, 1, subargs, 0, subargs.length);
      }
      Class target = null;
      try {
        target = Class.forName(args[0]);
      } catch (ClassNotFoundException e) {target = null;}

      if(target != null)
      {
        try {
          Class[] parms = {args.getClass()};
          final Object[] arg = {subargs};
          final Method mainMethod = target.getDeclaredMethod("main", parms);
          Runnable r = new Runnable() {
            public void run() {
              try {
                mainMethod.invoke(null, arg);
              } catch (Exception e) {}
            }};
          Thread t = new Thread(r);
          t.start();
        } catch (Exception e2) {}
      }
    }

    // twiddle our thumbs, look for end of saving
    JaverW w = new JaverW();

    try{
      w.setVisible(true);
    } catch (ExceptionInInitializerError bang)
    {
      System.out.println("+++++++++++++++++");
      bang.getException().printStackTrace(System.out);
      System.out.println("-----------------");
    }
    for(;;)
    {
      if(mustEnd())
      {
        System.exit(0);
      }
      try {
        Thread.sleep(1000L);
      } catch (InterruptedException e) {}
      w.replace();
    }
  }
  private static native boolean isStopped();
  private static boolean freestanding = false;
  static int n = 25;
  private static boolean mustEnd()
  {
    if(!freestanding)
    {
      try {
        return isStopped();
      } catch (UnsatisfiedLinkError ex) {}
    }
    freestanding = true;
    return --n < 0;
  }
}
