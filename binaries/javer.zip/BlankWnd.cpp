//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         blankwnd.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TBlankWnd (TFrameWindow).
//
//----------------------------------------------------------------------------
#include <owl/pch.h>
#include <stdio.h>

#include "blankwnd.h"
#define THRESHOLD 3

//
// Build a response table for all messages/commands handled by the application.
//
DEFINE_RESPONSE_TABLE1(TBlankWnd, TFrameWindow)
//{{TBlankWndRSP_TBL_BEGIN}}
//{{TBlankWndRSP_TBL_END}}
END_RESPONSE_TABLE;


//{{TBlankWnd Implementation}}


TBlankWnd::TBlankWnd(TWindow* parent, const char far* title, TWindow*, bool shrinkToClient, TModule* module)
:
    TFrameWindow(0/*parent*/, title, 0, shrinkToClient, module)
{
  // INSERT>> Your constructor code here.
  Attr.Style = WS_POPUP|WS_VISIBLE;
  Attr.ExStyle = 0;//WS_EX_TOPMOST;
  if(!parent)
  {
  		Attr.X = Attr.Y = 0;
		Attr.W = ::GetSystemMetrics(SM_CXSCREEN);
		Attr.H = ::GetSystemMetrics(SM_CYSCREEN);
  }
  else
  {
  		TRect t;
      parent->GetWindowRect(t);
      Attr.X = t.X();
      Attr.Y = t.Y();
      Attr.W = t.Width();
      Attr.H = t.Height();
  }
}


TBlankWnd::~TBlankWnd()
{
  Destroy(IDCANCEL);

  // INSERT>> Your destructor code here.
}

TResult TBlankWnd::WindowProc(uint message, TParam1 wParam, TParam2 lParam)
{
  // INSERT>> Your code here.
	static BOOL		fHere = FALSE;
	static TPoint	ptLast;
	TPoint ptCursor, ptCheck;
 	SetCursor(GetModule(), IDC_NULLCURSOR);

	switch(message)
	{
	case WM_SYSCOMMAND:
		if((SC_SCREENSAVE == wParam) || (SC_CLOSE == wParam))
		{
			return FALSE;
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_SETCURSOR:
   	SetCursor(GetModule(), IDC_NULLCURSOR);
		break;;
	case WM_NCACTIVATE:
		if(!wParam)
		{
			return FALSE;
		}
		break;
	case WM_ACTIVATE:
	case WM_ACTIVATEAPP:
		if(!wParam) break;
		// drop thro' on loss of focus
	case WM_MOUSEMOVE:
		if(!fHere)
		{
			GetCursorPos(ptLast);
			fHere = TRUE;
		} else {
			GetCursorPos(ptCheck);
			ptCursor.x = abs(ptCheck.x - ptLast.x);
			ptCursor.y = abs(ptCheck.y - ptLast.y);
			if(ptCursor.x + ptCursor.y > THRESHOLD)
			{
				PostMessage(WM_CLOSE, 0, 0L);
			}
		}
		break;
	case WM_LBUTTONDOWN:
	case WM_MBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_KEYDOWN:
	case WM_SYSKEYDOWN:
		PostMessage(WM_CLOSE, 0, 0L);
		break;
	}

  return TFrameWindow::WindowProc(message, wParam, lParam);

}


void TBlankWnd::Paint(TDC& dc, bool erase, TRect& rect)
{
  TFrameWindow::Paint(dc, erase, rect);

  // INSERT>> Your code here.
	TBrush black(TColor::Black);
   dc.FillRect(rect, black);
}

