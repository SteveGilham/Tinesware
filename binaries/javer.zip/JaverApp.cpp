//----------------------------------------------------------------------------
//  Project Javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    Javer Application
//  FILE:         javerapp.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TJaverApp (TApplication).
//
//----------------------------------------------------------------------------

#include <owl/pch.h>

#include <stdio.h>
#include <deque>

#include "javerapp.h"
#include "blankwnd.h"
#include "hiddnwnd.h"
#include "preview.h"
#include "sttngsdl.h"
#include "regkey.h"

#include "com_ravnaandtines_javer.h"

class JMonitor
{
   bool stopped;
   CRITICAL_SECTION lock;

	public:
   	JMonitor() : stopped(false)
      {
		  InitializeCriticalSection(&lock);
      }
      bool getStopped()
      {
      	 EnterCriticalSection(&lock);
          bool res = stopped;
          LeaveCriticalSection(&lock);
          return res;
      }
      void setStopped(bool state)
      {
      	 EnterCriticalSection(&lock);
          stopped = state;
          LeaveCriticalSection(&lock);
      }
      virtual ~JMonitor()
      {
      	DeleteCriticalSection(&lock);
      }
};
static JMonitor  monitor;
DWORD WINAPI ThreadFunc( LPVOID );

//{{TJaverApp Implementation}}


//
// Build a response table for all messages/commands handled
// by the application.
//
DEFINE_RESPONSE_TABLE1(TJaverApp, TApplication)
//{{TJaverAppRSP_TBL_BEGIN}}
//{{TJaverAppRSP_TBL_END}}
END_RESPONSE_TABLE;


//--------------------------------------------------------
// TJaverApp
//
TJaverApp::TJaverApp() : TApplication("Javer"), prev(NULL)
{
  // INSERT>> Your constructor code here.
}


TJaverApp::~TJaverApp()
{
  // INSERT>> Your destructor code here.
  monitor.setStopped(true);
  if(prev) delete prev;
}


//--------------------------------------------------------
// TJaverApp
// ~~~~~
// Application intialization.
//
TJaverApp * theApp;
int OwlMain(int , char* [])
{
  TJaverApp   app;
  theApp = &app;
  return app.Run();
}

void TJaverApp::doConfig(const HWND hwnd)
{
    //TODO: Add your source code here
    TWindow * tmp = hwnd ? new TWindow(hwnd) : NULL;
    if(IDOK==TSettingsDlg(tmp).Execute())
    {
    }
    if(tmp) delete tmp;
    // End the application
    GetMainWindow()->PostMessage(WM_QUIT, 0, 0L);
}


void TJaverApp::doPassword(const HWND hwnd)
{
    //TODO: Add your source code here
    // Win9x only
    HINSTANCE hmpr = ::LoadLibrary("MPR.DLL");
    if(!hmpr) return;
    typedef VOID (WINAPI *PWDCHANGEPASSWORD)
        (LPCSTR lpcRegkeyName, HWND hwnd, UINT uiReserved,
        UINT uiRes2);
    PWDCHANGEPASSWORD change = (PWDCHANGEPASSWORD)
        ::GetProcAddress(hmpr, "PwdChangePassword");
    if(change)
    {
        change("SCRSAVE", hwnd, 0, 0);
    }
    ::FreeLibrary(hmpr);
    GetMainWindow()->PostMessage(WM_QUIT, 0, 0L);
}


void TJaverApp::InitMainWindow()
{
  // INSERT>> Your code here.
  	string commandLine = GetCmdLine();
  	const char * ptr = commandLine.c_str();
  	if(!ptr || !*ptr)
  	{
   	commandLine = "/c";
      ptr = commandLine.c_str();
   }
   if('-' == *ptr || '/' == *ptr) ++ptr;

   HWND hwnd;

   switch (*ptr)
   {
   	case 'p':
      case 'P':
      case 'l':
      case 'L':
      	++ptr;
         while(*ptr &&(' '==*ptr||':'==*ptr)) ++ptr;
         hwnd = (HWND) atoi(ptr);
         {
         	TWindow * tmp = hwnd ? new TWindow(hwnd) : NULL;
            prev = new TPreview(tmp);
            prev->Create();
            prev->ShowWindow(SW_SHOW);
            SetMainWindow(new THiddenWnd);
         }
         return;
      case 's':
      case 'S':
         {
  				thread = CreateThread(
    			NULL,	// pointer to thread security attributes
    			0,	// initial thread stack size, in bytes
    			ThreadFunc,	// pointer to thread function
    			NULL,	// argument for new thread
    			0,	// creation flags
    			&threadId 	// pointer to returned thread identifier
   			);
         	TBlankWnd * pWnd = new TBlankWnd();
            pWnd->Create();
            pWnd->SetCursor(this, IDC_NULLCURSOR);
	         SetMainWindow(pWnd);
            pWnd->BringWindowToTop();
         }
         return;
      case 'c':
      case 'C':
         SetMainWindow(new THiddenWnd);
      	++ptr;
         while(*ptr&&(' '==*ptr||':'==*ptr))++ptr;
         hwnd = (HWND) atoi(ptr);
         doConfig(hwnd?hwnd:TWindow::GetActiveWindow());
         return;
      case 'a':
      case 'A':
         SetMainWindow(new THiddenWnd);
      	++ptr;
         while(*ptr&&(' '==*ptr||':'==*ptr))++ptr;
         hwnd = (HWND) atoi(ptr);
         doPassword(hwnd?hwnd:TWindow::GetActiveWindow());
         return;
      default:
         SetMainWindow(new THiddenWnd);
      	doConfig(NULL);
         return;
    }
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_ravnaandtines_Javer_isStopped
  (JNIEnv *, jclass)
{
	return (jboolean) monitor.getStopped();
}


class LibraryProxy {
  private:
   HMODULE module;
  public:
    LibraryProxy() : module(NULL) {}
  	void setProxy(const char * path)
    {
    	 char buffer[MAX_PATH+10];
       strcpy(buffer, path);
    	 module = LoadLibrary(buffer);
    }
    bool isOK() const {return (module != NULL);}
    void wipe()
    {
       if(isOK()) FreeLibrary(module);
       module = NULL;
    }
    ~LibraryProxy()
    {
    	wipe();
    }
    HMODULE lib() const {return module;}
};

static std::deque<LibraryProxy> * pLibs = NULL;

class Watcher{
	public:
  	Watcher(){};
    ~Watcher(){if (pLibs) delete pLibs; pLibs = NULL;}
};


void __stdcall exitFn(jint)
{
	delete pLibs;
  pLibs = NULL;
}

typedef jint (JNICALL *J1PROC)(void *);

typedef jint (JNICALL *J2PROC)(JavaVM **, JNIEnv **, void *);


DWORD WINAPI ThreadFunc( LPVOID )
{
  RegKey key(false);
  Watcher w;

	JDK1_1InitArgs vm_args;
  vm_args.version = 0x00010001;

  pLibs = new std::deque<LibraryProxy>;
  J1PROC pJNI_GetDefaultJavaVMInitArgs = NULL;
  J2PROC pJNI_CreateJavaVM = NULL;


  // Let's try to load the Java libraries
	{
  		char java[512];
  		DWORD size = sizeof java;
  		key.getJavahome(java, &size);
   	strcat(java, "\\");
   	string j(java);
   	strcat(java, "*.dll");

    	WIN32_FIND_DATA f;

      //1.1 or 1.2?
      string j2 = j + "java.dll";
    	HANDLE h = FindFirstFile(j2.c_str(), &f);
      bool j11 = INVALID_HANDLE_VALUE==h;

      if(!j11)
      {
    		j2 = j + "*";
			h = FindFirstFile(j2.c_str(), &f);
    		if(h!=INVALID_HANDLE_VALUE) do {
    			if(f.dwFileAttributes != FILE_ATTRIBUTE_DIRECTORY) continue;
            if(!strcmp(f.cFileName,".")) continue;
            if(!strcmp(f.cFileName,"..")) continue;
    			string name = j+f.cFileName+"\\jvm.dll";

    			WIN32_FIND_DATA f2;
    			HANDLE h2 = FindFirstFile(name.c_str(), &f2);
         	if(INVALID_HANDLE_VALUE == h2) continue;

         	// found a jvm
        		LibraryProxy lib;
        		pLibs->push_back(lib);
        		int i = pLibs->size();
         	(*pLibs)[i].setProxy(name.c_str());

        		pJNI_GetDefaultJavaVMInitArgs = (J1PROC)
        			GetProcAddress((*pLibs)[i].lib(), "JNI_GetDefaultJavaVMInitArgs");
        		pJNI_CreateJavaVM = (J2PROC)
        			GetProcAddress((*pLibs)[i].lib(), "JNI_CreateJavaVM");
          	break;
    		} while (FindNextFile(h, &f));

      	j2 = j + "java.dll";
         LibraryProxy lib;
         pLibs->push_back(lib);
         int i = pLibs->size();
         (*pLibs)[i].setProxy(j2.c_str());
   	}  // j1.2+ jvm loaded

    	h = FindFirstFile(java, &f);

    	if(h!=INVALID_HANDLE_VALUE) do {
    		if(strstr(f.cFileName, "_g.dll")) continue;
    		if(strstr(f.cFileName, "npjava")) continue;
    		if(!j11 && strstr(f.cFileName, "java.dll")) continue;
      	string name = j+f.cFileName;
      	LibraryProxy lib;
      	pLibs->push_back(lib);
      	int i = pLibs->size();
      	(*pLibs)[i].setProxy(name.c_str());

      	if(!j11 || stricmp("javai.dll", f.cFileName)) continue;

      	// Load entrypoints
      	pJNI_GetDefaultJavaVMInitArgs = (J1PROC)
        		GetProcAddress((*pLibs)[i].lib(), "JNI_GetDefaultJavaVMInitArgs");
      	pJNI_CreateJavaVM = (J2PROC)
        		GetProcAddress((*pLibs)[i].lib(), "JNI_CreateJavaVM");
    	} while (FindNextFile(h, &f));
   }

  if(!pJNI_GetDefaultJavaVMInitArgs ||
     !pJNI_CreateJavaVM)
  {
     return 100;
  }

  (pJNI_GetDefaultJavaVMInitArgs)(&vm_args);
  vm_args.exit = exitFn;

  // Set working directory
  char buffer[2048];
  DWORD size = sizeof buffer;
  key.getWorkdir(buffer, &size);
  if(!SetCurrentDirectory(buffer)) buffer[0] = 0;
  else GetCurrentDirectory(sizeof buffer, buffer);
  string work("javer.workdir=");
  work+=buffer;

  // Set classpath
  size = sizeof buffer;
  key.getClasspath(buffer, &size);
  vm_args.classpath = buffer;

  // Set current directory property
  const char * prop[2];
  prop[1] = NULL;
  prop[0] = work.c_str();
  vm_args.properties = const_cast<char**>(prop);

  JNIEnv *env;
  JavaVM *jvm;
  if((pJNI_CreateJavaVM)(&jvm, &env, &vm_args) < 0)
  {
   return 1;
  }
  size = sizeof buffer;
  key.getMainclass(buffer, &size);
  jobjectArray args;

  if(key.isOK() && buffer[0])
  {
	  jstring jstr1 = env->NewStringUTF(buffer);
	  size = sizeof buffer;
     key.getArguments(buffer, &size);
     if(buffer[0])
     {
   		// how many parts?
         int num = 1;
         char *ptr = buffer;
         while(*ptr)
         {
         	while(isspace(*ptr)) ++ptr;
            if(!ptr) break;
            // now at non-space
            ++num;
            bool inquote = *ptr == '"';

            if(inquote)
            {
            	++ptr; // first enquoted;
               while('"' != *ptr && *ptr) ++ptr;
               if(!ptr) break; // off the end
               ++ptr; // first after quote
            }
            else
            {
               while(!isspace(*ptr) && *ptr) ++ptr;
               if(!ptr) break; // off the end
            }
         }
			args = env->NewObjectArray(num, env->FindClass("java/lang/String"), jstr1);
         ptr = buffer;
         num = 0;
         char * start;
         while(*ptr)
         {
         	while(isspace(*ptr)) ++ptr;
            if(!ptr) break;
            // now at non-space
            ++num;
            bool inquote = *ptr == '"';

            if(inquote)
            {
            	++ptr; // first enquoted;
               start = ptr;
               while('"' != *ptr && *ptr) ++ptr;
               bool quote = *ptr != 0;
               *ptr = 0;
               jstr1 = env->NewStringUTF(start);
               env->SetObjectArrayElement(args, num, jstr1);
               if(quote) ++ptr; // first after quote

            }
            else
            {
            	start = ptr;
               while(!isspace(*ptr) && *ptr) ++ptr;
               bool space = *ptr != 0;
               char save = *ptr;
               *ptr = 0;
               jstr1 = env->NewStringUTF(start);
               env->SetObjectArrayElement(args, num, jstr1);
               if(space)*ptr = save;
            }
            if(!ptr) break;
         }



     }
     else
     {
			args = env->NewObjectArray(1, env->FindClass("java/lang/String"), jstr1);
     }
  }
  else
  {
  	args = NULL;
  }
  jclass boot = env->FindClass("com/ravnaandtines/Javer");
  if(!boot)
  {
   jvm->DestroyJavaVM();
   return 2;
  }

  JNINativeMethod native[1];
  native[0].name = "isStopped";
  native[0].signature = "()Z";
  native[0].fnPtr = Java_com_ravnaandtines_Javer_isStopped;

  env->RegisterNatives(boot, native, 1);
  jmethodID mid = env->GetStaticMethodID(boot, "main",
  	"([Ljava/lang/String;)V");

   if(!mid)
  {
   jvm->DestroyJavaVM();
   return 3;
  }

  env->CallStaticVoidMethod(boot, mid, args);
  jvm->DestroyJavaVM();
  return 0;
}
