//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         sttngsdl.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TSettingsDlg (TDialog).
//
//----------------------------------------------------------------------------
#if !defined(sttngsdl_h)              // Sentry, use file only if it's not already included.
#define sttngsdl_h

#include <owl/dialog.h>
#include <owl/edit.h>

#include <owl/commctrl.h>

#include <owl/button.h>
#include "javerapp.rh"            // Definition of all resources.


//{{TDialog = TSettingsDlg}}

class TSettingsDlg : public TDialog {
  private:
  	TEdit * classpath;
   TEdit * mainclass;
   TEdit * args;
   TEdit * javahome;
   TEdit * workdir;
  public:
    TSettingsDlg(TWindow* parent, TResId resId = IDD_SETTINGS, TModule* module = 0);
    virtual ~TSettingsDlg();

//{{TSettingsDlgVIRTUAL_BEGIN}}
  public:
    virtual void SetupWindow();
//{{TSettingsDlgVIRTUAL_END}}

//{{TSettingsDlgRSP_TBL_BEGIN}}
  protected:
    void OKBNClicked();
    void JavaBNClicked();
    void WorkBNClicked();
//{{TSettingsDlgRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TSettingsDlg);
};    //{{TSettingsDlg}}


#endif  // sttngsdl_h sentry.

