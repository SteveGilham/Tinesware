//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         hiddnwnd.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for THiddenWnd (TFrameWindow).
//
//----------------------------------------------------------------------------
#if !defined(hiddnwnd_h)              // Sentry, use file only if it's not already included.
#define hiddnwnd_h

#include <owl/framewin.h>
#include <owl/animctrl.h>

#include "javerapp.rh"            // Definition of all resources.


//{{TFrameWindow = THiddenWnd}}
class THiddenWnd : public TFrameWindow {
  public:
    THiddenWnd(TWindow* parent = NULL, const char far* title = 0, TWindow* clientWnd = 0, bool shrinkToClient = false, TModule* module = 0);
    virtual ~THiddenWnd();

//{{THiddenWndVIRTUAL_BEGIN}}
  public:
    virtual bool ShowWindow(int cmdShow);
//{{THiddenWndVIRTUAL_END}}
};    //{{THiddenWnd}}


#endif  // hiddnwnd_h sentry.

