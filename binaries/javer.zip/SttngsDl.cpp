//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         sttngsdl.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TSettingsDlg (TDialog).
//
//----------------------------------------------------------------------------
#include <owl/pch.h>
#include <shlobj.h>

#include "javerapp.h"
#include "RegKey.h"
#include "sttngsdl.h"

//
// Build a response table for all messages/commands handled by the application.
//
DEFINE_RESPONSE_TABLE1(TSettingsDlg, TDialog)
//{{TSettingsDlgRSP_TBL_BEGIN}}
  EV_BN_CLICKED(IDOK, OKBNClicked),
  EV_BN_CLICKED(IDC_GETJAVAHOME, JavaBNClicked),
  EV_BN_CLICKED(IDC_GETWORKDIR, WorkBNClicked),
//{{TSettingsDlgRSP_TBL_END}}
END_RESPONSE_TABLE;


//{{TSettingsDlg Implementation}}


TSettingsDlg::TSettingsDlg(TWindow* parent, TResId resId, TModule* module)
:
    TDialog(parent, resId, module)
{

  // INSERT>> Your constructor code here.
  	classpath = new TEdit(this, IDC_CLASSPATH);
   mainclass = new TEdit(this, IDC_MAINCLASS);
   args = new TEdit(this, IDC_ARGUMENTS);
   javahome = new TEdit(this, IDC_JAVAHOME);
   workdir = new TEdit(this, IDC_WORKDIR);
}


TSettingsDlg::~TSettingsDlg()
{
  Destroy(IDCANCEL);

  // INSERT>> Your destructor code here.
  delete classpath;
  delete mainclass;
  delete args;
  delete javahome;
  delete workdir;
}


void TSettingsDlg::SetupWindow()
{
  TDialog::SetupWindow();

  // INSERT>> Your code here.
  RegKey key(false);
  char buffer[512];
  DWORD size = sizeof buffer;

  key.getClasspath(buffer, &size);
  classpath->SetWindowText(buffer);

  size = sizeof buffer;
  key.getMainclass(buffer, &size);
  mainclass->SetWindowText(buffer);

  size = sizeof buffer;
  key.getArguments(buffer, &size);
  args->SetWindowText(buffer);

  size = sizeof buffer;
  key.getJavahome(buffer, &size);
  javahome->SetWindowText(buffer);
  javahome->SetReadOnly(true);

  size = sizeof buffer;
  key.getWorkdir(buffer, &size);
  workdir->SetWindowText(buffer);
  workdir->SetReadOnly(true);
}


void TSettingsDlg::OKBNClicked()
{
  // INSERT>> Your code here.
  RegKey key(true);
  char buffer[512];
  DWORD size = sizeof buffer;

  classpath->GetWindowText(buffer, size);
  key.setClasspath(buffer,size);

  mainclass->GetWindowText(buffer, size);
  key.setMainclass(buffer,size);

  args->GetWindowText(buffer, size);
  key.setArguments(buffer,size);

  javahome->GetWindowText(buffer, size);
  key.setJavahome(buffer,size);

  workdir->GetWindowText(buffer, size);
  key.setWorkdir(buffer,size);

  CmOk();
}


int CALLBACK BrowseCallbackProc(
	HWND hwnd, UINT uMsg,
  LPARAM /*lParam*/, long wParam)
{
	switch(uMsg)
  {
  	case BFFM_INITIALIZED:
    DWORD style = GetWindowLong(hwnd, GWL_EXSTYLE);
    SetWindowLong(hwnd, GWL_EXSTYLE, style &~WS_EX_CONTEXTHELP);
    SendMessage(hwnd, BFFM_SETSELECTION, TRUE, wParam);
    break;
  }
  return 0;
}


void TSettingsDlg::JavaBNClicked()
{
  // INSERT>> Your code here.
  LPITEMIDLIST root;
	SHGetSpecialFolderLocation(
    HWindow,
    CSIDL_DRIVES,
    &root
   );
  char buffer[512];
  DWORD size = sizeof buffer;
  javahome->GetWindowText(buffer, size);

  char displayName[MAX_PATH];
  char caption[512];
  theApp->LoadString(IDS_JAVAHOME, caption, sizeof caption);
  BROWSEINFO base =
  {
    HWindow,
    root,
    displayName,
    caption,
    BIF_RETURNONLYFSDIRS,
    BrowseCallbackProc,
    (LPARAM)buffer,
    0
  };
  LPITEMIDLIST arg = SHBrowseForFolder(&base);
  if(!arg) return;
  if(SHGetPathFromIDList(
    arg,
    displayName
   ))javahome->SetWindowText(displayName);
}


void TSettingsDlg::WorkBNClicked()
{
  // INSERT>> Your code here.
  LPITEMIDLIST root;
	SHGetSpecialFolderLocation(
    HWindow,
    CSIDL_DRIVES,
    &root
   );
  char buffer[512];
  DWORD size = sizeof buffer;
  workdir->GetWindowText(buffer, size);

  char displayName[MAX_PATH];
  char caption[512];
  theApp->LoadString(IDS_WORKDIR, caption, sizeof caption);
  BROWSEINFO base =
  {
    HWindow,
    root,
    displayName,
    caption,
    BIF_RETURNONLYFSDIRS,
    BrowseCallbackProc,
    (LPARAM)buffer,
    0
  };
  LPITEMIDLIST arg = SHBrowseForFolder(&base);
  if(!arg) return;
  if(SHGetPathFromIDList(
    arg,
    displayName
   ))workdir->SetWindowText(displayName);
}

