//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         preview.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of TPreview (TWindow).
//
//----------------------------------------------------------------------------
#include <owl/pch.h>

#include <stdio.h>

#include "preview.h"


//
// Build a response table for all messages/commands handled by the application.
//
DEFINE_RESPONSE_TABLE1(TPreview, TWindow)
//{{TPreviewRSP_TBL_BEGIN}}
  EV_WM_DESTROY,
//{{TPreviewRSP_TBL_END}}
END_RESPONSE_TABLE;


//{{TPreview Implementation}}


TPreview::TPreview(TWindow* parent, const char far* title, TModule* module)
:
    TWindow(parent, title, module)
{
  // INSERT>> Your constructor code here.
  Attr.Style = WS_CHILDWINDOW|WS_VISIBLE;
//  Attr.ExStyle = WS_EX_TOPMOST;
  if(!parent)
  {
  		Attr.X = Attr.Y = 0;
		Attr.W = ::GetSystemMetrics(SM_CXSCREEN);
		Attr.H = ::GetSystemMetrics(SM_CYSCREEN);
  }
  else
  {
  		TRect t;
      parent->GetWindowRect(t);
      //Attr.X = t.X();
      //Attr.Y = t.Y();
      Attr.W = t.Width();
      Attr.H = t.Height();
  }

}


TPreview::~TPreview()
{
  Destroy(IDCANCEL);

  // INSERT>> Your destructor code here.

}


void TPreview::Paint(TDC& dc, bool erase, TRect& rect)
{
  TWindow::Paint(dc, erase, rect);

  // INSERT>> Your code here.
	TBrush blue(TColor::LtBlue);
   dc.FillRect(rect, blue);

   dc.SelectStockObject(SYSTEM_FONT);
   dc.SetTextAlign(TA_CENTER|VTA_CENTER);
   dc.SetBkColor(TColor::LtBlue);
   TRect t = GetClientRect();
   dc.SetTextColor(TColor::LtRed);

   // all this malarkey manages to centre the text
   // the obvious things didn't!

   int x = t.TopLeft().x+t.Width()/2;
   int y = t.TopLeft().y+t.Height()/2;
   char * text = "Javer\nScreen Saver";
   TSize ext = dc.GetTextExtent(text, strlen(text));
   TRect outline(x,y - ext.cy,x+t.Width(), y+t.Height());
   uint16 format = DT_LEFT|DT_NOCLIP;
   dc.SetTextAlign(TA_CENTER|VTA_CENTER);
	dc.DrawText(text,-1, outline,format);
}



void TPreview::EvDestroy()
{
    TWindow::EvDestroy();

  // INSERT>> Your code here.
	PostQuitMessage(0);
}

