//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         blankwnd.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TBlankWnd (TFrameWindow).
//
//----------------------------------------------------------------------------
#if !defined(blankwnd_h)              // Sentry, use file only if it's not already included.
#define blankwnd_h

#include <owl/framewin.h>
#include <owl/window.h>

#include "javerapp.rh"            // Definition of all resources.


//{{TFrameWindow = TBlankWnd}}
class TBlankWnd : public TFrameWindow {
  public:
    TBlankWnd(TWindow* parent = 0, const char far* title = 0, TWindow* clientWnd = 0, bool shrinkToClient = false, TModule* module = 0);
    virtual ~TBlankWnd();

//{{TBlankWndVIRTUAL_BEGIN}}
  public:
    virtual TResult WindowProc(uint msg, TParam1 p1, TParam2 p2);
    virtual void Paint(TDC& dc, bool erase, TRect& rect);
//{{TBlankWndVIRTUAL_END}}

//{{TBlankWndRSP_TBL_BEGIN}}
  protected:
    void EvNCDestroy();
    void EvPaint();
//{{TBlankWndRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TBlankWnd);
};    //{{TBlankWnd}}


#endif  // blankwnd_h sentry.

