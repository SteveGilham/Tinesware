//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         preview.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPreview (TWindow).
//
//----------------------------------------------------------------------------
#if !defined(preview_h)              // Sentry, use file only if it's not already included.
#define preview_h

#include <owl/window.h>

#include "javerapp.rh"            // Definition of all resources.


//{{TWindow = TPreview}}
class TPreview : public TWindow {
  public:
    TPreview(TWindow* parent, const char far* title = 0, TModule* module = 0);
    virtual ~TPreview();

//{{TPreviewVIRTUAL_BEGIN}}
  public:
    virtual void Paint(TDC& dc, bool erase, TRect& rect);
//{{TPreviewVIRTUAL_END}}

//{{TPreviewRSP_TBL_BEGIN}}
  protected:
    void EvClose();
    void EvDestroy();
//{{TPreviewRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TPreview);
};    //{{TPreview}}


#endif  // preview_h sentry.

