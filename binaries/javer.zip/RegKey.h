//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         regkey.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for RegKey
//
//----------------------------------------------------------------------------
#if !defined(regkey_h)              // Sentry, use file only if it's not already included.
#define regkey_h
#include <winreg.h>

class RegKey  {
  public:
    RegKey(bool create);
    virtual ~RegKey();

    bool isOK() const {return (ERROR_SUCCESS == res);}

    void getClasspath(char * buffer, DWORD *size);
    void getMainclass(char * buffer, DWORD *size);
    void getArguments(char * buffer, DWORD *size);
    void getJavahome(char * buffer, DWORD *size);
    void getWorkdir(char * buffer, DWORD *size);

    void setClasspath(const char * buffer, DWORD size);
    void setMainclass(const char * buffer, DWORD size);
    void setArguments(const char * buffer, DWORD size);
    void setJavahome(const char * buffer, DWORD size);
    void setWorkdir(const char * buffer, DWORD size);

  private:
    HKEY skey;
    LONG res;
    DWORD valtype;

    LONG getKey(const char * tag, LPBYTE buffer, DWORD *size);
};


#endif  // regkey_h sentry.

