//----------------------------------------------------------------------------
//  Project Javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    Javer Application
//  FILE:         javerapp.h
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TJaverApp (TApplication).
//
//----------------------------------------------------------------------------
#if !defined(javerapp_h)              // Sentry, use file only if it's not already included.
#define javerapp_h

#include <owl/opensave.h>


#include "javerapp.rh"            // Definition of all resources.


//
// FrameWindow must be derived to override Paint for Preview and Print.
//
class TPreview;
//{{TApplication = TJaverApp}}
class TJaverApp : public TApplication {
  private:
    void doConfig(const HWND);
    void doPassword(const HWND);
    HANDLE thread;
    DWORD  threadId;
    TPreview * prev;

  public:
    TJaverApp();
    virtual ~TJaverApp();

//{{TJaverAppVIRTUAL_BEGIN}}
  public:
    virtual void InitMainWindow();
//{{TJaverAppVIRTUAL_END}}

//{{TJaverAppRSP_TBL_BEGIN}}
  protected:
//{{TJaverAppRSP_TBL_END}}
DECLARE_RESPONSE_TABLE(TJaverApp);
};    //{{TJaverApp}}


extern TJaverApp* theApp;

#endif  // javerapp_h sentry.
