//----------------------------------------------------------------------------
//  Project javer
//  
//  Copyright � 1997. All Rights Reserved.
//
//  SUBSYSTEM:    javer.apx Application
//  FILE:         hiddnwnd.cpp
//  AUTHOR:       
//
//  OVERVIEW
//  ~~~~~~~~
//  Source file for implementation of THiddenWnd (TFrameWindow).
//
//----------------------------------------------------------------------------
#include <owl/pch.h>

#include "hiddnwnd.h"


//{{THiddenWnd Implementation}}


THiddenWnd::THiddenWnd(TWindow* parent, const char far* title, TWindow* clientWnd, bool shrinkToClient, TModule* module)
:
    TFrameWindow(parent, title, clientWnd == 0 ? new TAnimateCtrl(0, 100, 0, 0, 0, 0) : clientWnd, shrinkToClient, module)
{
  // INSERT>> Your constructor code here.

}


THiddenWnd::~THiddenWnd()
{
  Destroy(IDCANCEL);

  // INSERT>> Your destructor code here.

}


bool THiddenWnd::ShowWindow(int/* cmdShow*/)
{
//  bool result;

//  result = TFrameWindow::ShowWindow(cmdShow);

  // INSERT>> Your code here.

//  return result;
	return TFrameWindow::ShowWindow(SW_HIDE);
}

