
//Title:        CTC2.0 for Java
//Version:      
//Copyright:    Copyright (c) 1997
//Author:       Mr. TInes
//Company:      Ravna & Tines
//Description:  Free World Freeware

// TODO: - fix the decrypt/read/dearmour action
// TODO: - refactor dtai.gwt.CJTextAreaGadget; in C++ too

package com.ravnaandtines.ctcjava;

import java.awt.*;

import java.awt.event.WindowEvent;
import java.io.*;
import java.text.*;
import java.util.Date;
import javax.swing.*;

public class Document implements javax.swing.tree.TreeNode
{    
    private JFrame shell = new JFrame();
    private JMenuBar menuBar = new JMenuBar();
    private JToolBar toolBar = new JToolBar();
    private JPanel clientArea = new JPanel();
    
    private JTextArea fileText = new JTextArea(20,80); // called by cjcb_act.cpp getSplitPanel 
    private JTextArea sigText = null;

    private JLabel echoArea = new JLabel("  ");
    public void setEchoText(String s) {echoArea.setText(s);}
    
    private JPopupMenu popup = new JPopupMenu();

    private FileDialog saveDialog = null;
    
    private boolean isText = true; // called by cjcb_act.cpp cb_result_file
    private long modified = -2;
    private String fn = null, dr = null;

    private CJTempfile binary = null;
    private String hardCaption = null;

    // called by
    // - cjcb_act.cpp cb_result_file
    // - cjcb_act.cpp getSplitPanel    
    public Document() {
        saveDialog = new FileDialog(shell,GlobalData.getResourceString("Save_text"), FileDialog.SAVE);
        hardCaption = GlobalData.getResourceString("Save_changes");
        try {
            jbInit();
            shell.pack();
            
            DocumentRoot.instance().append(this);
            modified = 0;

            Point parentAt = Application.instance().getFrame().getLocation();
            Dimension d = Application.instance().getFrame().getSize();
            Dimension d2 = shell.getSize();

            // our centre over parent centre
            Point to = new Point(
            parentAt.x+(d.width-d2.width)/2,
            parentAt.y+(d.height-d2.height)/2);

            //random displacement nearby
            to.x +=(int)((d.width+d2.width)*(Math.random()-0.5));
            to.y +=(int)((d.height+d2.height)*(Math.random()-0.5));

            // ensure on screen
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            if (to.x + d2.width > screen.width)
            {
                to.x -= screen.width-d2.width;
            }
            if(to.x < 0) to.x = 0;
            if (to.y + d2.height > screen.height)
            {
                to.y -= screen.height-d2.height;
            }
            if(to.y < 0) to.y = 0;
            shell.setLocation(to.x, to.y);
            shell.setVisible(true);            
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

        Action fileSave = new AbstractAction(
                GlobalData.getResourceString("Save_file"),
                new ImageIcon(IconSelection.FILESAVE.getImage()))
        {
                public void actionPerformed(java.awt.event.ActionEvent e)
                {
                    menuFileSave_actionPerformed();
                }            
        };
        Action fileSaveAs = new AbstractAction(
                GlobalData.getResourceString("Save_as"),
                new ImageIcon(IconSelection.FILESAVEAS.getImage()))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuFileSaveAs_actionPerformed();
            }
        };
        
        Action fileSend = new AbstractAction(
                GlobalData.getResourceString("SMTP_"),
                new ImageIcon(IconSelection.MAILOUT.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuFileSend_actionPerformed();
            }
        };
        
        Action filePrint = new AbstractAction(
                GlobalData.getResourceString("Print"),
                new ImageIcon(IconSelection.PRINT.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuFilePrint_actionPerformed();
            }
        };
        Action fileClose = new AbstractAction(
                GlobalData.getResourceString("Close_Window"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuFileClose_actionPerformed();
            }
        };

        Action editCut = new AbstractAction(
                GlobalData.getResourceString("Cut"),
                new ImageIcon(IconSelection.CUT.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuEditCut_actionPerformed();
            }
        };
        Action editCopy = new AbstractAction(
                GlobalData.getResourceString("Copy"),
                new ImageIcon(IconSelection.COPY.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuEditCopy_actionPerformed();
            }
        };
        Action editPaste = new AbstractAction(
                GlobalData.getResourceString("Paste"),
                new ImageIcon(IconSelection.PASTE.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuEditPaste_actionPerformed();
            }
        };
        
        Action editROT13 = new AbstractAction(
                GlobalData.getResourceString("ROT13"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuEditROT13_actionPerformed();
            }
        };
        Action editEnquote = new AbstractAction(
                GlobalData.getResourceString("Quote_text"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuEditEnquote_actionPerformed();
            }
        };
        
        Action cryptoDecrypt = new AbstractAction(
                GlobalData.getResourceString("Decrypt"),
                new ImageIcon(IconSelection.UNLOCK.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoDecrypt_actionPerformed();
            }
        };
        
        Action cryptoDuress = new AbstractAction(
                GlobalData.getResourceString("Extract_session_key"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoDuress_actionPerformed();
            }
        };
        Action cryptoEncrypt = new AbstractAction(
                GlobalData.getResourceString("Encrypt"),
                new ImageIcon(IconSelection.LOCK.getImage())
                )
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoEncrypt_actionPerformed();
            }
        };
        Action cryptoClearsign = new AbstractAction(
                GlobalData.getResourceString("Clearsign"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoClearsign_actionPerformed();
            }
        };
        Action cryptoSplitsign = new AbstractAction(
                GlobalData.getResourceString("Detached_signature"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoSplitsign_actionPerformed();
            }
        };
        Action cryptoSignonly = new AbstractAction(
                GlobalData.getResourceString("Sign_only"))
        {
            public void actionPerformed(java.awt.event.ActionEvent e)
            {
                menuCryptoSignonly_actionPerformed();
            }
        };

        JMenu fileMenu = new JMenu(GlobalData.getResourceString("File"));
        JMenu editMenu = new JMenu(GlobalData.getResourceString("Edit"));
        JMenu cryptoMenu = new JMenu(GlobalData.getResourceString("Crypto"));        
        
    private void jbInit() throws Exception
    {
        shell.setIconImage(IconSelection.ICON.getImage());
       
        Container baseplane = shell.getContentPane();
        shell.setJMenuBar(menuBar);
        baseplane.setLayout(new BorderLayout());
        baseplane.add(toolBar, BorderLayout.NORTH);
        baseplane.add(clientArea, BorderLayout.CENTER);
        clientArea.setLayout(new BorderLayout());
 
        toolBar.add(fileSave).setToolTipText(GlobalData.getResourceString("Save_file"));
        toolBar.add(fileSend).setToolTipText(GlobalData.getResourceString("SMTP_"));
        toolBar.addSeparator();
        toolBar.add(filePrint).setToolTipText(GlobalData.getResourceString("Print"));
        toolBar.addSeparator();
        toolBar.add(editCut).setToolTipText(GlobalData.getResourceString("Cut"));
        toolBar.add(editCopy).setToolTipText(GlobalData.getResourceString("Copy"));
        toolBar.add(editPaste).setToolTipText(GlobalData.getResourceString("Paste"));
        toolBar.addSeparator();
        toolBar.add(cryptoDecrypt).setToolTipText(GlobalData.getResourceString("Decrypt"));
        toolBar.add(cryptoEncrypt).setToolTipText(GlobalData.getResourceString("Encrypt"));
        
        // Key event I18N???
        menuBar.add(fileMenu).setMnemonic(java.awt.event.KeyEvent.VK_F);
        fileMenu.add(fileSave).setMnemonic(java.awt.event.KeyEvent.VK_S);
        fileMenu.add(fileSaveAs).setMnemonic(java.awt.event.KeyEvent.VK_A);
        fileMenu.addSeparator();
        fileMenu.add(fileSend).setMnemonic(java.awt.event.KeyEvent.VK_N);
        fileMenu.add(filePrint).setMnemonic(java.awt.event.KeyEvent.VK_P);
        fileMenu.addSeparator();
        fileMenu.add(fileClose).setMnemonic(java.awt.event.KeyEvent.VK_C);
        
        menuBar.add(editMenu).setMnemonic(java.awt.event.KeyEvent.VK_E);
        editMenu.add(editCut).setMnemonic(java.awt.event.KeyEvent.VK_X);
        editMenu.add(editCopy).setMnemonic(java.awt.event.KeyEvent.VK_C);
        editMenu.add(editPaste).setMnemonic(java.awt.event.KeyEvent.VK_P);
        editMenu.addSeparator();
        editMenu.add(editROT13).setMnemonic(java.awt.event.KeyEvent.VK_R);
        editMenu.add(editEnquote).setMnemonic(java.awt.event.KeyEvent.VK_Q);
       
        menuBar.add(cryptoMenu).setMnemonic(java.awt.event.KeyEvent.VK_C);
        cryptoMenu.add(cryptoDecrypt).setMnemonic(java.awt.event.KeyEvent.VK_D);
        cryptoMenu.add(cryptoDuress).setMnemonic(java.awt.event.KeyEvent.VK_U);
        cryptoMenu.addSeparator();
        cryptoMenu.add(cryptoEncrypt).setMnemonic(java.awt.event.KeyEvent.VK_E);
        cryptoMenu.add(cryptoClearsign).setMnemonic(java.awt.event.KeyEvent.VK_C);
        cryptoMenu.add(cryptoSplitsign).setMnemonic(java.awt.event.KeyEvent.VK_P);
        cryptoMenu.add(cryptoSignonly).setMnemonic(java.awt.event.KeyEvent.VK_S);

        popup.add(editROT13).setMnemonic(java.awt.event.KeyEvent.VK_R);
        popup.add(editEnquote).setMnemonic(java.awt.event.KeyEvent.VK_Q);

        clientArea.add(echoArea, BorderLayout.NORTH);        
        clientArea.add(new JScrollPane(fileText), BorderLayout.CENTER);
        
        // TODO: needs ^Z undo
        fileText.setFont(new Font("Monospaced", Font.PLAIN, 14));
        fileText.setColumns(73);
        fileText.setWrapStyleWord(true);
        
        fileText.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e)
            {
                fileText_textValueChanged();
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e)
            {
                fileText_textValueChanged();
            }
            public void removeUpdate(javax.swing.event.DocumentEvent e)
            {
                fileText_textValueChanged();
            }        
        });
        
        fileText.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mousePressed(java.awt.event.MouseEvent e)
            {
                if (e.isMetaDown() && null == binary)
                {
                    popup.setBackground(SystemColor.control);
                    popup.setFont(new Font("Dialog", 0, 12));
                    popup.show((Component)e.getSource(),
                            e.getX(),e.getY());
                }
            }
        }
        );
                
        shell.addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent e)
            {
                closeWindow(shell);
                return;
            }
        } );
        shell.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    }

    void commonSave()
    {
        if(isText)
        {
            try{
                FileOutputStream f = new FileOutputStream(dr+fn);
                Writer w = null;
                if(null != GlobalData.encoding) try {
                    w =  new OutputStreamWriter(f, GlobalData.encoding);
                } 
                catch ( UnsupportedEncodingException ex ) {
                }
                if(null == w) w =  new OutputStreamWriter(f);
                StringReader r = new StringReader(
                fileText.getText());
                BufferedReader get = new BufferedReader(r);
                String line = null;
                // write each line with local line separator
                for(line = get.readLine(); line != null; line = get.readLine())
                {
                    w.write(line+System.getProperty("line.separator"));
                }
                w.flush();
                w.close();
            } 
            catch(Exception ex) {
                return;
            }
        }
        else
        {
            try{
                FileOutputStream f = new FileOutputStream(dr+fn);
                // push binary out
                binary.saveToStream(f);
                f.flush();
                f.close();
            } 
            catch(Exception ex) {
                return;
            }
        }
        modified = 0;
    }

    void menuFileSave_actionPerformed()
    {
        System.gc();
        if(modified <= 0) return;
        else if(null == fn || null == dr ||
            0==fn.length() || 0==dr.length())
        {
            menuFileSaveAs_actionPerformed();
            return;
        }
        commonSave();
    }

    void menuFileSaveAs_actionPerformed()
    {
        System.gc();
        saveDialog.setVisible(true);
        fn = saveDialog.getFile();
        dr = saveDialog.getDirectory();
        if(null == fn)
        {
            return;
        }
        shell.setTitle(dr+fn);
        commonSave();
    }

    void menuFileSend_actionPerformed()
    {
        SMTPTransmitter send = new SMTPTransmitter(shell, fileText.getText());
        send.show();
    }


    void menuFilePrint_actionPerformed()
    {     
       java.awt.PrintJob pj = null;
        try {
            pj = Toolkit.getDefaultToolkit().getPrintJob(shell,
            "CTCjava", null);
        }
        catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        shell,
                        ex.getMessage(),
                        GlobalData.getResourceString("Print_Error"),
                        JOptionPane.ERROR_MESSAGE);
           return;
        }

        if(null != pj)
        {
            try {

                fileText.print(pj.getGraphics());
            }
            catch (Exception pex) {
            }
            pj.end();
        }
    }

    void menuFileClose_actionPerformed()
    {
        closeWindow(shell);
        System.gc();
    }

    void menuEditCut_actionPerformed()
    {
        fileText.cut();
        ++modified;
        System.gc();
    }

    void menuEditCopy_actionPerformed()
    {
        fileText.copy();
        System.gc();
    }

    void menuEditPaste_actionPerformed()
    {
        fileText.paste();
        ++modified;
        System.gc();
    }

    void menuEditROT13_actionPerformed() // hopelessly 7-bit ASCII
    {
        String s = fileText.getSelectedText();
        if(null == s || s.length() == 0)
            return;
        
        StringBuffer buf = new StringBuffer();
        for(int i=0; i<s.length();++i)
        {
            char c = s.charAt(i);
            if(c >= 'a' && c <= 'z')
            {
                int num = ((c-'a')+13)%26;
                buf.append((char)('a'+num));
            }
            else if(c >= 'A' && c <= 'Z')
            {
                int num = ((c-'A')+13)%26;
                buf.append((char)('A'+num));
            }
            else buf.append(c);
        }
        
        fileText.replaceSelection(buf.toString());
        ++modified;
        System.gc();
    }

    void menuEditEnquote_actionPerformed()
    {
        String s = fileText.getSelectedText();
        if(null == s || s.length() == 0)
            return;
        
        String token = Root.instance().getQuoteString();
        
        StringBuffer buf = new StringBuffer();
        for(int i=0; i<s.length();++i)
        {
            char c = s.charAt(i);
            buf.append(c);
            if(c == '\n')
            buf.append(token);
        }
        
        fileText.replaceSelection(buf.toString());
        ++modified;
        System.gc();
    }


    public boolean closeWindow(Frame f)
    {
        if(modified <= 0)
        {
            Application.instance().pull(this);
            return true;
        }
        
        // need to block
        switch(JOptionPane.showOptionDialog(f, // argument used here
                GlobalData.getResourceString("This_file_has_been"),
                shell.getTitle()+" "+hardCaption,
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, null, null
                )
                )
        {
        case JOptionPane.YES_OPTION:
            menuFileSave_actionPerformed();
            if(modified > 0) return false;
            //drop through
        case JOptionPane.NO_OPTION:
            Application.instance().pull(this);
            saveDialog.dispose();
            saveDialog = null;
            shell.dispose();
            System.gc();
            return true;
            // don't need to catch cancel
        }
        return false;
    }

    public void load(POP3RetrievedMessage mail)
    {
        setASCII(mail.getBuffer());
        modified = 0;
    }

    private void load(Reader loader)
    {
        StringBuffer transit= new StringBuffer(1024);
        BufferedReader lines = new BufferedReader(loader);
        String bucket = null;
        do
        {
            bucket = null;
            try{
                bucket = lines.readLine();
            }
            catch(IOException ioe){
                break;
            }
            if(bucket != null)
            {
                transit.append(bucket+System.getProperty("line.separator"));
            }
        } 
        while (bucket != null);
        setASCII(transit);
        modified = 0;
    }

    // called by
    // - cjcb_act.cpp cb_result_file
    void setASCII(StringBuffer text)
    {
        fileText.setText(text.toString());
        int shown = fileText.getText().length();
        fileText.setCaretPosition(0);
        //    bigString = null;
        modified = 1;
    }

    void setMessage(CJTempfile tmp)
    {
        Reader loader = tmp.getReader();
        load(loader);
        if(fileText.getText() != null &&
            fileText.getText().length() > 0) modified = 1;
    }

    public void loadFile(String directory, String filename)
    {
        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        try {
            dr = directory;
            fn = filename;
            shell.setTitle(dr+fn);
            saveDialog.setFile(filename);
            saveDialog.setDirectory(directory);
            if(isText = GlobalData.isTextFile(directory+filename))
            {
                FileInputStream f;
                try {
                    f = new FileInputStream(directory+filename);
                }
                catch(FileNotFoundException fnfe){
                    return;
                }
                Reader loader = null;
                if(null != GlobalData.encoding) try {
                    loader =  new InputStreamReader(f, GlobalData.encoding);
                } 
                catch ( UnsupportedEncodingException ex ) {
                }
                if(null == loader) loader =  new InputStreamReader(f);
                load(loader);
            }
            else
            {
                InputStream loader;
                try {
                    loader = new FileInputStream(directory+filename);
                }
                catch(FileNotFoundException fnfe){
                    return;
                }
                setBinary ( new CJTempfile(loader) );
                modified = 0;
            }
        }
        finally{
            shell.setCursor(Cursor.getDefaultCursor());
            System.gc();
        }
    }

    // called by
    // - cjcb_act.cpp cb_result_file
    void setBinary(CJTempfile bin)
    {
        binary = bin;
        fileText.setText(GlobalData.getResourceString("Binary_file"));
        fileText.setEditable(false);
        modified = 1;

        // no clearsigning and no mailing for binary
        cryptoClearsign.setEnabled(false);
        fileSend.setEnabled(false);
        filePrint.setEnabled(false);
        fileSave.setEnabled(false);
        editCut.setEnabled(false);
        editCopy.setEnabled(false);
        editPaste.setEnabled(false);
        editMenu.setEnabled(false);
    }



    void fileText_textValueChanged()
    {
        //Debug System.out.println("text event!");
        ++modified;
    }

    private CJTempfile getFile()
    {
        if(isText)
        {
            return new CJTempfile(fileText.getText());
        }
        else
        {
            return binary;
        }
    }

    void doDecryption(boolean split)
    {
        if(!PublicKeyRoot.instance().isValid())
            PublicKeyRoot.instance().loadKeys();
        if(!SecretKeyRoot.instance().isValid())
            SecretKeyRoot.instance().loadKeys();

        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        GlobalData.userbreak = false;
        SecretKeyRoot.instance().loadKeys();

        String failure = null;
        if(!PublicKeyRoot.instance().isValid())
            failure = GlobalData.getResourceString("noPubring");
        else if(!SecretKeyRoot.instance().isValid())
            failure = GlobalData.getResourceString("noSecring");

        if(failure != null)
        {
            // Fix this
                JOptionPane.showMessageDialog(
                        Application.instance().getFrame(),
                        failure,
                        "CTCJava",
                        JOptionPane.ERROR_MESSAGE);
        }

        Examiner t = new Examiner(getFile(), split, isText);
        t.start();
    }

    private class Examiner extends Thread
    {
        CJTempfile f;
        boolean split;
        boolean isText;

        public Examiner(CJTempfile f, boolean split, boolean isText)
        {
            this.f = f;
            this.split = split;
            this.isText = isText;
        }

        public void run()
        {
            try {
                int state = isText?
                CJctclib.examine_text(f, split):
                CJctclib.examine(f, split);
            }
            finally {
                Document.this.shell.setCursor(Cursor.getDefaultCursor());
                System.gc();
            }
        }
    }

    void menuCryptoDecrypt_actionPerformed()
    {
        doDecryption(false);
    }

    void menuCryptoDuress_actionPerformed()
    {
        doDecryption(true);
    }

    private void prepareFile()
    {
        if(!PublicKeyRoot.instance().isValid())
            PublicKeyRoot.instance().loadKeys();
        if(!SecretKeyRoot.instance().isValid())
            SecretKeyRoot.instance().loadKeys();

        String failure = null;
        boolean canSign = true;
        if(!PublicKeyRoot.instance().isValid())
            failure = GlobalData.getResourceString("noPubring");
        else if(!SecretKeyRoot.instance().isValid())
        {
            failure = GlobalData.getResourceString("noSecring");
            canSign = false;
        }

        if(failure != null)
        {
                JOptionPane.showMessageDialog(
                        Application.instance().getFrame(),
                        failure,
                        "CTCJava",
                        JOptionPane.ERROR_MESSAGE);
        }

        CJencryptInsts.reset();
        Root.instance().setAlgs();
        CJencryptInsts.setFile(shell.getTitle(), (null == binary) ? 't': 'b');


        SecretKey s = null;
        if(canSign)
        {
          s = CJencryptInsts.getSignatory();
          if(CJencryptInsts.isCancelled())
          {
            return;
          }
        }
        if(null != s) CJencryptInsts.setSignatory(s.cHandle());
    }

    private void spawn(CJTempfile load, boolean clearsigned)
    {
        // create and register a new window
        Document result = new Document();
        result.dr = dr;

        if(clearsigned || Root.instance().isArmoured())
        {
            result.load(load.getReader());
            result.fn = fn+".asc";
            result.isText = true;
        }
        else
        {
            result.setBinary(load);
            result.fn = fn+".pgp";
            result.isText = false;
        }
        result.shell.setTitle(result.dr+result.fn);
        result.modified = 10;
    }

    void menuCryptoEncrypt_actionPerformed()
    {
        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        prepareFile();
        if(CJencryptInsts.isCancelled())
        {
            return;
        }
        PublicKey[] s = CJencryptInsts.getRecipients();
        if(CJencryptInsts.isCancelled())
        {
            return;
        }
        for(int i=0; s != null && i<s.length; ++i)
        {
            
            CJencryptInsts.addRecipient(s[i].cHandle());
        }

        Encrypter t = new Encrypter(getFile());
        t.start();
    }

    private class Encrypter extends Thread
    {
        CJTempfile f;

        public Encrypter(CJTempfile f)
        {
            this.f = f;
        }

        public void run()
        {
            try {
                CJTempfile output = new CJTempfile();
                boolean ok = CJctclib.encrypt(f, output);
                if(ok)
                {
                    spawn(output, false);
                }
            }
            finally {
                Document.this.shell.setCursor(Cursor.getDefaultCursor());
                System.gc();
            }
        }
    }

    void menuCryptoClearsign_actionPerformed()
    {
        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        prepareFile();
        if(CJencryptInsts.isCancelled())
        {
            return;
        }
        Root.instance().setAlgs(Root.Operation.CLEARSIGN);

        Signer t = new Signer(getFile());
        t.start();
    }

    private class Signer extends Thread
    {
        CJTempfile f;

        public Signer(CJTempfile f)
        {
            this.f = f;
        }

        public void run()
        {
            try {
                CJTempfile output = new CJTempfile();
                boolean ok = CJctclib.signOnly(f, output);
                if(ok)
                {
                    spawn(output, false);
                }
            }
            finally {
                Document.this.shell.setCursor(Cursor.getDefaultCursor());
                System.gc();
            }
        }
    }

    void menuCryptoSplitsign_actionPerformed()
    {
        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        prepareFile();
        if(CJencryptInsts.isCancelled())
        {
            return;
        }
        Root.instance().setAlgs(Root.Operation.SPLITSIGN);

        Signer t = new Signer(getFile());
        t.start();
    }

    void menuCryptoSignonly_actionPerformed()
    {
        shell.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        prepareFile();
        if(CJencryptInsts.isCancelled())
        {
            return;
        }
        Root.instance().setAlgs(Root.Operation.SIGNONLY);

        Encrypter t = new Encrypter(getFile());
        t.start();
    }

    private void setSigTextArea()
    {
        if(null == sigText)
        {
            sigText = new JTextArea();
            clientArea.add(sigText, BorderLayout.SOUTH);
            sigText.setEditable(false);
        }
    }

    // called by
    // - cjcb_act.cpp cb_result_file
    void showSig(String name, int time, boolean ok)
    {
        long t = ((long)time)&0x00000000FFFFFFFFL;
        Date when = new Date(1000L*t);
        DateFormat fmt = DateFormat.getDateTimeInstance();
        setSigTextArea();
        sigText.append(
        "File from: "+name+"\n" +
            (ok ? GlobalData.getResourceString("with_good_signature") :
        GlobalData.getResourceString("with_bad_signature") )
            +fmt.format(when)+"\n");
        shell.pack();
    }
    
    // called by
    // - cjcb_act.cpp cb_result_file
    void setPath(String dir, String file)
    {
        dr = dir;
        fn = file;
        shell.setTitle(dr+fn);
    }

    // called by
    // - cjcb_act.cpp cb_result_file
    void setText(boolean text)
    {
        setSigTextArea();
        if(text) sigText.append(GlobalData.getResourceString("Text_file"));
        else     sigText.append(GlobalData.getResourceString("Binary_file"));
        shell.pack();
    }
    
    public boolean isTextDocument()
    {
        return isText;
    }
    public String getFileName()
    {
        if(null == fn)
            return GlobalData.getResourceString("Untitled");
        return fn;
    }
    
    public void repaint(long tm) 
    {
        shell.repaint(tm);
    }
    
    public void setTitle(String s) {shell.setTitle(s);}
    public void dispose() {shell.dispose();}
    public void setVisible(boolean b) {shell.setVisible(b);}
    
    // TreeNode
    public java.util.Enumeration children()
    {
        return null;
    }
    public boolean getAllowsChildren()
    {
        return false;
    }
    public javax.swing.tree.TreeNode getChildAt(int childIndex)
    {
        return null;
    }
    public int getChildCount()
    {
        return 0;
    }
    public int getIndex(javax.swing.tree.TreeNode node)
    {
        return -1;
    }
    public javax.swing.tree.TreeNode getParent()
    {
        return DocumentRoot.instance();
    }
    public boolean isLeaf()
    {
        return true;
    }    
    
}

