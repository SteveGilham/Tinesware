
//Title:        CTC2.0 for Java
//Version:      
//Copyright:    Copyright (c) 1997
//Author:       Mr. TInes
//Company:      Ravna & Tines
//Description:  Free World Freeware


package com.ravnaandtines.ctcjava;
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.Dimension;
import java.util.Vector;
import javax.swing.*;

public class CJencryptInsts {

    private CJencryptInsts() {
    }

    // direct poking to the structure
    public static native void reset();
    public static native void setFile(String name, char type);
    public static native void setVersion(int v);
    public static native boolean addRecipient(long to);
    public static native void setSignatory(long from);
    public static native void setAlgs(int cea, int cem, int mda, 
    int cpa, int arm);

    static boolean cancelled;

    public static boolean isCancelled()
    {
        return cancelled;
    }
    
    
    // helpful enquiries

    public static  PublicKey[] getRecipients()
    {
        cancelled = false;
        JList nameList = PublicKeyRoot.instance().getRecipientList();
        if(null == nameList)
            return null;
        
        
        nameList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JPanel sub = new JPanel();
        sub.setLayout(new BorderLayout());
        sub.add(new JScrollPane(nameList), BorderLayout.CENTER);
        sub.add(new JLabel(GlobalData.getResourceString("If_none_selected")), BorderLayout.SOUTH);
        
        int mode = JOptionPane.showOptionDialog(
                Application.instance().getFrame(),
                sub,
                GlobalData.getResourceString("Select_recipients"),
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null, null, null
                );
        cancelled = (JOptionPane.CANCEL_OPTION == mode);
        if(cancelled || nameList.getSelectedValues().length == 0)
            return null;
        PublicKey[] result = new PublicKey[nameList.getSelectedValues().length];
        for(int i=0; i<result.length; ++i) {
            result[i] = (PublicKey) nameList.getSelectedValues()[i];
        }
        return result;
  }

    public static SecretKey getSignatory()
    {
        cancelled = false;
        JList nameList = SecretKeyRoot.instance().getSignatoryList();
        if(null == nameList)
            return null;
        
        int mode = JOptionPane.showOptionDialog(
                Application.instance().getFrame(),
                new JScrollPane(nameList),
                GlobalData.getResourceString("Select_signing_key"),
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null, null, null
                );
        
        cancelled = (JOptionPane.CANCEL_OPTION == mode);
        Object o = nameList.getSelectedValue();
        if(null == o || cancelled)
            return null;
        return (SecretKey) o;
        
    }
}
