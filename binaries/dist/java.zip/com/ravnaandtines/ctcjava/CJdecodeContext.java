
//Title:        CTC2.0 for Java
//Version:      
//Copyright:    Copyright (c) 1997
//Author:       Mr. TInes
//Company:      Ravna & Tines
//Description:  Free World Freeware


package com.ravnaandtines.ctcjava;

public class CJdecodeContext {

    private long pointer;

    private CJdecodeContext() {
    }

    private CJdecodeContext(long handle)
    {
        pointer = handle;
    }

    public NativePublicKey firstPubKey()
    {
        return getFirstPubkey(pointer);
    }
    private native NativePublicKey getFirstPubkey(long ptr);

    public NativeSecretKey firstSecKey()
    {
        return getFirstSeckey(pointer);
    }
    private native NativeSecretKey getFirstSeckey(long ptr);

}
