/* licences.h
**
** Copyright (C)  Heimdall <heimdall@bifroest.demon.co.uk> 1997
** All rights reserved.  For full licence details see file licences.c
**  DLL support Mr. Tines 14-Sep-1997
**  Namespace CTClib Mr. Tines 5-5-98
**  Trimmed for FTP 1.1 14-Aug-02
**
*/
#ifndef _licences_h
#define _licences_h
#ifdef __cplusplus
extern "C" {
#endif

char * licence_text(void);

#ifdef __cplusplus
}
#endif
#endif

/* end of file licences.h */
