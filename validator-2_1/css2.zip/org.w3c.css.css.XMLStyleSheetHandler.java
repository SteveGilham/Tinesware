/*
 * Copyright (c) 2001 World Wide Web Consortium,
 * (Massachusetts Institute of Technology, Institut National de
 * Recherche en Informatique et en Automatique, Keio University). All
 * Rights Reserved. This program is distributed under the W3C's Software
 * Intellectual Property License. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.
 * See W3C License http://www.w3.org/Consortium/Legal/ for more details.
 *
 * $Id: org.w3c.css.css.XMLStyleSheetHandler.java,v 1.1 2003/05/17 20:39:06 Steve Exp $
 */
package org.w3c.css.css;

import java.net.URL;
import java.net.MalformedURLException;
import java.io.StringBufferInputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.util.Hashtable;

import org.w3c.css.util.Util;
import org.w3c.css.util.HTTPURL;
import org.w3c.css.util.ApplContext;
import org.w3c.css.parser.CssError;
import org.w3c.css.parser.Errors;
import org.w3c.css.util.InvalidParamException;

import System.Xml.*;

//import org.w3c.css.util.xml.XMLCatalog;

/**
 * @version $Revision: 1.1 $
 * @author  Philippe Le Hegaret
 */
public class XMLStyleSheetHandler //implements ContentHandler, 
    //LexicalHandler, ErrorHandler, EntityResolver 
{

    static String XHTML_NS = "http://www.w3.org/1999/xhtml";

    private static long autoIdCount;

    String namespaceURI;
    boolean isRoot = true;

    ApplContext    ac;
    URL documentURI = null;
    URL baseURI = null;

    //  StyleSheet styleSheet = new StyleSheet(); 
    StyleSheetParser styleSheetParser = new StyleSheetParser(); 

    boolean inStyle = false;
    String media  = null;
    String type  = null;
    String title = null;
    StringBuffer text = new StringBuffer(255);
	XmlTextReader reader = null;

    /**
     * Creates a new XMLStyleSheetHandler
     */
	public XMLStyleSheetHandler(XmlTextReader tr, URL baseURI, ApplContext ac) 
	{
		this.documentURI = baseURI;
		this.baseURI     = baseURI;
		this.ac = ac;
		this.reader = tr;
	}
    
	public void processingInstruction (String target, String data)
		//throws SAXException 
	{
		Hashtable atts = getValues(data);

		if ("xml-stylesheet".equals(target)) 
		{
			String rel  = (String) atts.get("alternate");
			String type  = (String) atts.get("type");
			String href = (String) atts.get("href");
	    
			if (Util.onDebug) 
			{
				System.out.println("<?xml-stylesheet alternate=\"" + rel 
					+ "\" type=\"" + type
					+ "\"" + "   href=\"" + href + "\"?>");
			}

			if ("yes".equals(rel)) 
			{
				rel = "alternate stylesheet";
			} 
			else 
			{
				rel = "stylesheet";
			}
			if ((type == null) || (href == null)) 
			{
				int line = ((IXmlLineInfo)reader).get_LineNumber();
				CssError er =
					new CssError(baseURI.toString(), line,
					new InvalidParamException("unrecognized.link", ac));
				Errors ers = new Errors();
				ers.addError(er);
				styleSheetParser.notifyErrors(ers);
			}

			if (type.equals("text/css")) 
			{
				// we're dealing with a stylesheet...
				URL url;
		
				try 
				{ 
					if (baseURI != null) 
					{
						if(baseURI.getProtocol().equals("file"))
						{
							String documentFile = baseURI.getFile();
							java.io.File doc = new java.io.File(documentFile);
							java.io.File css = new java.io.File(doc.getParent(), href);
							url = new URL("file","",-1,css.getCanonicalPath());
						}
						else
							url = new URL(baseURI, href); 
					} 
					else 
					{
						url = new URL(href); 
					}
				} 
				catch (MalformedURLException e) 
				{
					return; // Ignore errors
				}
				catch (java.io.IOException x)
				{
					return;
				}
		
				if (Util.onDebug) 
				{
					System.out.println("[XMLStyleSheetHandler::initialize(): "
						+ "should parse CSS url: " 
						+ url.toString() + "]");
				}
				String media = (String) atts.get("media");
				if (media == null) 
				{
					media="all";
				}
				styleSheetParser.parseURL(ac,
					url, 
					(String) atts.get("title"),
					rel,
					media,
					StyleSheetOrigin.AUTHOR);
				if (Util.onDebug) 
				{
					System.out.println("[parsed!]");
				}
			}
		}
	}

	public void startElement(String namespaceURI,
		String localName)
	{
		if (isRoot) 
		{
			this.namespaceURI = namespaceURI;
			isRoot = false;
		}
		if (XHTML_NS.equals(namespaceURI)) 
		{
			if ("base".equals(localName)) 
			{
				String href = reader.GetAttribute("href");//atts.getValue("href");
	
				if (Util.onDebug) 
				{
					System.out.println("BASE href=\"" + href + "\"");
				}
	
				if (href != null) 
				{
					try 
					{
							if(documentURI.getProtocol().equals("file"))
							{
								String documentFile = baseURI.getFile();
								java.io.File doc = new java.io.File(documentFile);
								java.io.File css = new java.io.File(doc.getParent(), href);
								baseURI = new URL("file","",-1,css.getCanonicalPath());
							}
							else
								baseURI = new URL(documentURI, href); 
					} 
					catch (MalformedURLException e) 
					{
						return; // Ignore errors
					}
					catch (java.io.IOException e) 
					{
						return; // Ignore errors
					}
				}
		
			} 
			else if ("link".equals(localName)) 
			{

				String rel  = reader.GetAttribute("rel");//atts.getValue("rel");
				String type  = reader.GetAttribute("type");//atts.getValue("type");
				String href = reader.GetAttribute("href");//atts.getValue("href");
		
				if (Util.onDebug) 
				{
					System.out.println("link rel=\"" + rel 
						+ "\" type=\"" + type
						+ "\"" + "   href=\"" + href + "\"");
				}
				if (type == null || !type.equals("text/css")) 
				{		    
					return;
				}
				if (href == null) 
				{
					int line = ((IXmlLineInfo)reader).get_LineNumber();
					CssError er =
						new CssError(baseURI.toString(), line,
						new InvalidParamException("unrecognized.link", ac));
					Errors ers = new Errors();
					ers.addError(er);
					styleSheetParser.notifyErrors(ers);
					return;
				}
	
				if ((rel != null) && rel.toLowerCase().indexOf("stylesheet") != -1) 
				{
					// we're dealing with a stylesheet...
					// @@TODO alternate stylesheet
					URL url = null;
		    
					try 
					{
						if (baseURI != null) 
						{
							if(baseURI.getProtocol().equals("file"))
							{
								String documentFile = baseURI.getFile();
								java.io.File doc = new java.io.File(documentFile);
								java.io.File css = new java.io.File(doc.getParent(), href);
								url = new URL("file","",-1,css.getCanonicalPath());
							}
							else
								url = new URL(baseURI, href); 
						} 
						else 
						{
							url = new URL(href); 
						}
					} 
					catch (MalformedURLException e) 
					{
						return; // Ignore errors
					}
					catch (java.io.IOException e) 
					{
						return; // Ignore errors
					}
		    
					if (Util.onDebug) 
					{
						System.out.println("[XMLStyleSheetHandler::initialize(): "
							+ "should parse CSS url: " 
							+ url.toString() + "]");
					}
					String media = reader.GetAttribute(null, "media");//atts.getValue(null, "media");
					if (media == null) 
					{
						media="all";
					}
					styleSheetParser.parseURL(ac,
						url, 
						reader.GetAttribute(null, "title"),//atts.getValue(null, "title"),
						rel,
						media,
						StyleSheetOrigin.AUTHOR);
					if (Util.onDebug) 
					{
						System.out.println("[parsed!]");
					}
				}
			} 
			else if ("style".equals(localName)) 
			{
				media  = reader.GetAttribute("media");//atts.getValue("media");
				type  = reader.GetAttribute("type");//atts.getValue("type");
				title = reader.GetAttribute("title");//atts.getValue("title");
		
				if (media == null) 
				{
					media = "all";
				}
				if (Util.onDebug) 
				{
					System.out.println("style media=\"" + media
						+ "\" type=\"" + type
						+ "\"" + "   title=\"" + title + "\"");
				}
	
				if (type == null) 
				{
					int line = ((IXmlLineInfo)reader).get_LineNumber();
					CssError er =
						new CssError(baseURI.toString(), line,
						new InvalidParamException("unrecognized.link", ac));
					Errors ers = new Errors();
					ers.addError(er);
					styleSheetParser.notifyErrors(ers);
				} 
				else if (type.equals("text/css")) 
				{		
					text.setLength(0);
					inStyle = true;
				}
			} 
			else if (reader.GetAttribute(null, "style")/*atts.getValue(null, "style")*/ != null) 
			{
				String value = reader.GetAttribute("style");//atts.getValue("style");

				if (value != null) 
				{ // here we have a style attribute
					String id = reader.GetAttribute("id");//atts.getValue("id");
					handleStyleAttribute(value, id);
				}		
			}
			else if (reader.GetAttribute("style")!= null) 
			{
				String value = reader.GetAttribute("style");//atts.getValue("style");

				if (value != null) 
				{ // here we have a style attribute
					String id = reader.GetAttribute("id");
					handleStyleAttribute(value, id);
				}		
			}
		} 
		else 
		{
			// the style attribute, recommended by UI Tech TF
			String value = reader.GetAttribute(XHTML_NS, "style");//atts.getValue(XHTML_NS, "style");
	    
			if (value != null) 
			{ // here we have a style attribute
				String id = reader.GetAttribute(XHTML_NS, "id");//atts.getValue(XHTML_NS, "id");
				handleStyleAttribute(value, id);
			}		
		}
	}
    
	public void endElement (String namespaceURI, String localName)
	{
		int line = ((IXmlLineInfo)reader).get_LineNumber();
		if (XHTML_NS.equals(namespaceURI)) 
		{
			if ("style".equals(localName)) 
			{
				if (inStyle) 
				{
					inStyle = false;
					if (text.length() != 0) 
					{
						if (Util.onDebug) 
						{
							System.err.println( "PARSE [" + text.toString() + "]" );
						}
						styleSheetParser
							.parseStyleElement(ac,
							new StringBufferInputStream(text.toString()), 
							title, media, 
							documentURI, line);
					}
				}
		
			}
		}
	}

	public void handleStyleAttribute(String value, String id) 
	{
		if (id == null) 
		{ // but we have no id: create one.
			// a normal id should NOT contain a "#" character.
			id = "#autoXML" + autoIdCount; 
			// workaround a java hashcode bug.
			id += "" + autoIdCount++;   
		}
		int line = ((IXmlLineInfo)reader).get_LineNumber();
		// parse the style attribute.
		styleSheetParser
			.parseStyleAttribute(ac,
			new ByteArrayInputStream(value.getBytes()), 
			id, documentURI, line);
	}

	public StyleSheet getStyleSheet() 
	{
		return styleSheetParser.getStyleSheet();
	}        
	
    void parse() throws Exception {

		// read each node in the tree
		while (reader.Read())
		{
			// serialize node out to console according to XML 1.0 + Names
			switch ((int)reader.get_NodeType())
			{
				case (int)XmlNodeType.Element:
					/*
					Console.Write("<" + reader.Name);
					while (reader.MoveToNextAttribute())
						Console.Write(" " + reader.Name + "='" + reader.Value + "'");
					Console.Write(">");
					*/
					startElement (reader.get_NamespaceURI(),
						reader.get_LocalName());
					break;
				case (int)XmlNodeType.Text:
					//Console.Write(reader.Value);
					if (inStyle) 
					{
						text.append(reader.get_Value());
					}
					break;
				case (int)XmlNodeType.CDATA:
					//Console.Write(reader.Value);
					if (inStyle) 
					{
						text.append(reader.get_Value());
					}
					break;
				case (int)XmlNodeType.ProcessingInstruction:
					//Console.Write("<?" + reader.Name + " " + reader.Value + "?>");
					processingInstruction(reader.get_Name(), reader.get_Value());
					break;
				case (int)XmlNodeType.Comment:
					//Console.Write("<!--" + reader.Value + "-->");
					if (inStyle) 
					{
						text.append(reader.get_Value());
					}
					break;
				case (int)XmlNodeType.Document:
					//Console.Write("<?xml version='1.0'?>");
					break;
				case (int)XmlNodeType.Whitespace:
					//Console.Write(reader.Value);
					break;
				case (int)XmlNodeType.SignificantWhitespace:
					//Console.Write(reader.Value);
					break;
				case (int)XmlNodeType.EndElement:
					//Console.Write("</" + reader.Name + ">");
					endElement (reader.get_NamespaceURI(),
						        reader.get_LocalName());
					break;
			}
		}
   }
    
	Hashtable getValues(String data) 
	{
		int length = data.length();
		int current = 0;
		char c;
		StringBuffer name = new StringBuffer(10);
		StringBuffer value = new StringBuffer(128);
		StringBuffer entity_name = new StringBuffer(16);
		int state = 0;
		Hashtable table = new Hashtable();

		while (current < length) 
		{
			c = data.charAt(current);

			switch (state) 
			{
				case 0:
				switch (c) 
				{
					case ' ': case '\t': case '\n': // \r are normalized per XML spec
						// nothing
						break;
					case '"': case '\'':
						return table;
					case 'h': case 't': case 'm': case 'c': case 'a':
					case 'r':
						name.setLength(0); // reset the name
						value.setLength(0); // reset the value
						name.append(c); // start to build the name
						state = 1;
						break;
					default:
						// anything else is invalid
						return table;
				}
					break;
				case 1: // in the "attribute" name inside the PI
					if ((c >= 'a') && (c <= 'z')) 
					{
						name.append(c);
					} 
					else if ((c == ' ') || (c == '\t') || (c == '\n')) 
					{
						state = 2;
					} 
					else if (c == '=') 
					{
						state = 3;
					} 
					else 
					{
						// anything else is invalid
						state = 0;
					}
					break;
				case 2: // waiting for =
				switch (c) 
				{
					case ' ': case '\t': case '\n':
						// nothing
						break;
					case '=':
						state = 3;
					default:
						// anything else is invalid
						return table;
				}
					break;
				case 3: // waiting for ' or "
				switch (c) 
				{
					case ' ': case '\t': case '\n':
						// nothing
						break;
					case '"':
						state = 4;
						break;
					case '\'':
						state = 5;
						break;
					default:
						// anything else is invalid
						return table;
				}
					break;
				case 4: case 5: // in the "attribute" value inside the PI
				switch (c) 
				{
					case '&':
						// predefined entities amp, lt, gt, quot, apos
						entity_name.setLength(0);
						state += 10;
						break;
					case '<':
						return table;
					case '"':
						if (state == 4) 
						{
							state = 6;
						} 
						else 
						{
							value.append(c);
						}
						break;
					case '\'':
						if (state == 5) 
						{
							state = 6;
						} 
						else 
						{
							value.append(c);
						}
						break;
					default:
						value.append(c);
				}
					break;
				case 6: // waiting a white space
					table.put(name.toString(), value.toString());
					name.setLength(0); // reset the name
					value.setLength(0); // reset the value
				switch (c) 
				{
					case ' ': case '\n': case '\t':
						state = 0;
						break;
					default:
						return table;
				}
					break;
				case 14: case 15: // in the entity
				switch (c) 
				{
					case 'a': case 'm': case 'p':
					case 'l': case 't': case 'g':
					case 'q': case 'u': case 'o':
					case 's': 
						entity_name.append(c);
						break;
					case ';':
						String entity = entity_name.toString();
						if ("amp".equals(entity)) 
						{
							value.append('&');
						} 
						else if ("lt".equals(entity)) 
						{
							value.append('<');
						} 
						else if ("gt".equals(entity)) 
						{
							value.append('>');
						} 
						else if ("quote".equals(entity)) 
						{
							value.append('"');
						} 
						else if ("apos".equals(entity)) 
						{
							value.append('\'');
						} 
						else 
						{
							return table;
						}
						state -= 10;
						break;
					default:
						return table;
				}
			}
			current ++;
		}
		if (name.length() != 0 && value.length() != 0) 
		{
			table.put(name.toString(), value.toString());
		}
		return table;
	}
}
