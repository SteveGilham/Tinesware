using System;
using System.IO;
using System.Collections;

namespace toJSharp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			if(args.Length != 1)
			{
				Console.WriteLine("usage toJSharp source-base-folder");
				return;
			}

			baseDir = args[0];
			ProcessDirectory(args[0], null);

			Directory.SetCurrentDirectory(args[0]);
			IEnumerator i = mapping.GetEnumerator();

			while(i.MoveNext())
			{
				DictionaryEntry file = (DictionaryEntry)i.Current;
				File.Move((string)file.Key, (string)file.Value);
			}

			return;
		}

		static string baseDir = "";
		static Hashtable mapping = new Hashtable();

		// Process all files in the directory passed in, and recurse on any directories 
		// that are found to process the files they contain
		public static void ProcessDirectory(string targetDirectory, Stack chain) 
		{
			bool root = (chain == null);
			if(!root)
			{
				FileInfo dir = new FileInfo(targetDirectory);
				chain.Push(dir.Name);
			}
			else
				chain = new Stack();

			// Process the list of files found in the directory
			string [] fileEntries = Directory.GetFiles(targetDirectory);
			foreach(string fileName in fileEntries)
				ProcessFile(fileName, chain);

			// Recurse into subdirectories of this directory
			string [] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
			foreach(string subdirectory in subdirectoryEntries)
				ProcessDirectory(subdirectory, chain);
			
			if(!root)
				chain.Pop();
		}
		// Real logic for processing found files would go here.
		public static void ProcessFile(string path, Stack chain) 
		{
			if(!path.EndsWith(".java"))
				return;

			string key = path;
			FileInfo file = new FileInfo(path);
			string val = file.Name;

			IEnumerator i = chain.GetEnumerator();
			while(i.MoveNext())
			{
				val = (string)i.Current+"."+val;
			}

			mapping.Add(key, val);
		}

	}
}
