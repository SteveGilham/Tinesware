How to build css2.dll from the 05-19-cssvalidator.zip archive on the W3C site

0) Download and unzip 05-19-cssvalidator.zip (or extract a current build 
from CVS) 

1) use toJsharp.exe with argument being the Java sourcepath root to move
all the Java files into the root, qualifying them with their package name.
Source is provided for this utility

2) At a DOS prompt with the current directory being the Java sourcepath 
root, run

 vjsresgen /out:css2.resx /recurse:*prop*
 vjsresgen /out:css2dtd4.resx /recurse:*.dtd4


to generate the J# resources.  This utility is one of the J# samples,
so you should be able to find the sources at Microsoft if you want
to rebuild it yourself.

3) Unpack the java, jsl and vjsproj files into the Java sourcepath root

4) Now open the vjsproj file in Visual Studio and build.

5) Correct the obvious errors involving java.util.Vector methods introduced
at JDK 1.2 or later - apart from the copy constructor, which you have to
do by adding each element into the new Vector, all the rest are simple 
and obvious renamings.