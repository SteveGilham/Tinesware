//
// $Id: org.w3c.css.css.StyleSheetCom.java,v 1.1 2003/05/17 20:39:07 Steve Exp $
// From Philippe Le Hegaret (Philippe.Le_Hegaret@sophia.inria.fr)
//
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html
/*
 * $Log: org.w3c.css.css.StyleSheetCom.java,v $
 * Revision 1.1  2003/05/17 20:39:07  Steve
 * CSS level 2 support in J#
 *
 * Revision 1.1  1998/01/07 13:32:20  plehegar
 * Initial revision
 *
 */
package org.w3c.css.css;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

import org.w3c.css.parser.CssSelectors;
import org.w3c.css.parser.CssFouffa;
import org.w3c.css.parser.CssStyle;
import org.w3c.css.properties.CssProperty;
import org.w3c.css.util.HTTPURL;
import org.w3c.css.util.Util;
import org.w3c.css.util.ApplContext;

/**
 * @version $Revision: 1.1 $import javax.servlet.http.HttpServletResponse;
 */
public class StyleSheetCom //implements HtmlParserListener 
{
    
    ApplContext ac;
    String lang;
    String documentBase = "text";
    URL htmlURL;
    String file;
    int warningLevel = 2;
    PrintWriter out;
	StringWriter result;
    String defaultmedium;
    String cssversion;
    String profile;
    String contenttype;
    
    // @@ HACK
    static boolean showCSS = false;

    private Exception exception;
        
	public String xmlRequest(System.Xml.XmlTextReader tr) throws Exception 
	{
		StyleSheet style = null;
	
		XMLStyleSheetHandler handler = new XMLStyleSheetHandler(tr, htmlURL, ac);
		handler.parse();
		style = handler.getStyleSheet();
		if (style != null) 
		{
			style.setType("text/xml");
		}
		if (style != null) 
		{
			style.findConflicts(ac);
			if (documentBase.startsWith("html")) 
			{
				StyleSheetGeneratorHTML2 output = 
					new StyleSheetGeneratorHTML2(ac, file, 
					style,
					documentBase,
					warningLevel);
				output.print(out);
			} 
			else 
			{
				StyleSheetGenerator2 style2 = new StyleSheetGenerator2(file, 
					style, 
					documentBase,
					warningLevel);
				style2.print(out);
			}
		} 
		else 
		{
			System.err.println("No style sheet found in your HTML document");
		}
		ac.setInput("text/xml");

		return this.result.toString();
	}
    
	public StyleSheetCom(String filename)
	{
		this.ac = new ApplContext(this.lang);
		this.ac.setCssVersion("css2");
		this.result = new StringWriter();
		this.out = new PrintWriter(this.result, true);
		File f = new File(filename);
		this.file = f.getAbsolutePath();

		try 
		{
			this.htmlURL = new URL("file", "", -1, this.file);
		}  
		catch (Exception e) 
		{
			e.printStackTrace(this.out);
		}
	}
    
    /**
     * Notifies root creation.
     *
     * Sent when the parser builds the root of the HTML tree.
     *
     * @param url the URL being parsed.
     * @param root the new root Tag for this parser.
     */    
    //public void notifyCreateRoot(URL url, HtmlTag root) {
    //}
    
    public void notifyActivity(int lines, long bytes) {
    }
    
    public void notifyConnection(URLConnection cnx) {
    }
    
    /**
     * Notifies successful termination.
     *
     * @param root the root of the current Tree.
     */    
	public void notifyEnd(/*HtmlTag*/Object root, String contentType) 
	{
	
		StyleSheet style = null;
	
		/*
		 if (root != null) {
		 style = ((HtmlTree) root).getStyleSheet();
		 }
		 */

		if (style != null) 
		{
			style.findConflicts(ac);
			if (documentBase.startsWith("html")) 
			{
				StyleSheetGeneratorHTML2 output = 
					new StyleSheetGeneratorHTML2(ac, file, 
					style,
					contenttype,
					warningLevel);
				output.print(out);
			} 
			else 
			{
				StyleSheetGenerator2 style2 = new StyleSheetGenerator2(file, 
					style, 
					contenttype,
					warningLevel);
				style2.print(out);
			}
		} 
		else 
		{
			System.err.println("No style sheet found in your HTML document");
		}
		ac.setInput(contentType);
	}
    
    /**
     * Notifies a fatal error.
     *
     * This notification is sent when the parser need to stop during or before
     * parsing, due to an unexpected exception.
     *
     * @param root the root of the current Tree, if any.
     * @param x the exception that cause the Parser stop
     * @param msg an error message information
     */
	public void notifyFatalError(/*HtmlTag root,*/ Exception x, String s) 
	{
		exception = x;
	}
    
	private static CssSelectors createSelectors(String s) 
	{
		try 
		{
			CssFouffa fouffa = 
				new CssFouffa(null, new java.io.StringBufferInputStream(s),
				new URL("file://nofile"));
			return fouffa.parseSelector();
		} 
		catch (Exception e) 
		{
			System.err.println(e);
			return null;
		}
	}
    
}
